import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Almacenamiento local persistente de perfiles de acceso a NDR.
 * NO es un core bancario ni una solución de identidad certificada para producción.
 * Nunca almacena fondos, cuentas bancarias ni operaciones financieras.
 */
public final class Usuarios {
    public record Perfil(String id, String nombre, String correo, String telefono, String cci) {}
    public record Sesion(Perfil perfil, String csrf, long venceEn) {}
    public record Acceso(Sesion sesion, String tokenCookie) {}
    private record Credencial(Perfil perfil, String sal, String resumen) {}
    private record SesionInterna(Sesion sesion) {}
    private static final int ITERACIONES = 310_000;
    private static final long VIDA = 30 * 60_000L;
    private static final SecureRandom ALEATORIO = new SecureRandom();
    private final Path archivo;
    private final Map<String, Credencial> porCorreo = new HashMap<>();
    private final Map<String, Credencial> porTelefono = new HashMap<>();
    private final Set<String> ccis = new HashSet<>();
    private final ConcurrentHashMap<String, SesionInterna> sesiones = new ConcurrentHashMap<>();

    public Usuarios(Path directorio) throws IOException {
        Files.createDirectories(directorio);
        limitarPermisos(directorio, true);
        archivo = directorio.resolve("usuarios.ndr");
        if (Files.exists(archivo)) cargar();
    }

    private void cargar() throws IOException {
        List<String> lineas = Files.readAllLines(archivo, StandardCharsets.UTF_8);
        if (lineas.isEmpty()) throw new IOException("Archivo de perfiles vacío.");
        String cabecera = lineas.get(0);
        boolean v1 = "NDR-USUARIOS-1".equals(cabecera);
        boolean v2 = "NDR-USUARIOS-2".equals(cabecera);
        if (!v1 && !v2) throw new IOException("Formato de perfiles desconocido. No se iniciará el servidor.");
        boolean migrado = false;
        for (int i = 1; i < lineas.size(); i++) {
            String[] partes = lineas.get(i).split("\\|", -1);
            if ((v1 && partes.length != 6) || (v2 && partes.length != 7))
                throw new IOException("Archivo de perfiles dañado en línea " + (i + 1));
            try {
                String id = dec(partes[0]);
                String nombre = dec(partes[1]);
                String correo = dec(partes[2]);
                String telefono = dec(partes[3]);
                String cci = v2 ? dec(partes[4]) : generarCciUnico();
                if (!cci.matches("\\d{20}")) throw new IOException("CCI inválido en archivo de usuarios");
                Perfil p = new Perfil(id, nombre, correo, telefono, cci);
                Credencial c = new Credencial(p, partes[v2 ? 5 : 4], partes[v2 ? 6 : 5]);
                if (porCorreo.putIfAbsent(p.correo(), c) != null || porTelefono.putIfAbsent(p.telefono(), c) != null)
                    throw new IOException("Identidad duplicada en el archivo de usuarios");
                if (!ccis.add(cci)) throw new IOException("CCI duplicado en el archivo de usuarios");
                if (v1) migrado = true;
            } catch (IllegalArgumentException e) { throw new IOException("Archivo de perfiles inválido", e); }
        }
        if (migrado) guardar();
    }

    public synchronized Perfil registro(String nombre, String correo, String telefono, String clave) throws Exception {
        nombre = nombre.trim().replaceAll("\\s+", " ");
        correo = correo.trim().toLowerCase(Locale.ROOT);
        telefono = normalizarTelefono(telefono);
        validar(nombre, correo, telefono, clave);
        if (porCorreo.containsKey(correo) || porTelefono.containsKey(telefono))
            throw new Falta(409, "El correo o el teléfono ya está registrado.");
        byte[] salt = nuevoAleatorio(16);
        String hash = Base64.getUrlEncoder().withoutPadding().encodeToString(hash(clave.toCharArray(), salt));
        String cci = generarCciUnico();
        Credencial nuevo = new Credencial(new Perfil(UUID.randomUUID().toString(), nombre, correo, telefono, cci),
                Base64.getUrlEncoder().withoutPadding().encodeToString(salt), hash);
        porCorreo.put(correo, nuevo);
        porTelefono.put(telefono, nuevo);
        ccis.add(cci);
        try { guardar(); } catch (IOException e) {
            porCorreo.remove(correo); porTelefono.remove(telefono); ccis.remove(cci); throw e;
        }
        return nuevo.perfil();
    }

    public synchronized Acceso ingresar(String identificador, String clave) throws Exception {
        String entrada = identificador.trim().toLowerCase(Locale.ROOT);
        Credencial c = entrada.contains("@") ? porCorreo.get(entrada) : porTelefono.get(normalizarTelefono(entrada));
        if (clave.length() > 256) throw new Falta(401,"Datos de acceso incorrectos.");
        byte[] sal = c == null ? new byte[16] : Base64.getUrlDecoder().decode(c.sal());
        byte[] esperado = c == null ? new byte[32] : Base64.getUrlDecoder().decode(c.resumen());
        boolean ok = MessageDigest.isEqual(hash(clave.toCharArray(), sal), esperado);
        if (!ok || c == null) throw new Falta(401, "Correo/teléfono o contraseña incorrectos.");
        return abrirSesion(c.perfil());
    }

    public synchronized Perfil perfilPorId(String id) {
        for (Credencial c : porCorreo.values()) if (c.perfil().id().equals(id)) return c.perfil();
        return null;
    }

    public synchronized Perfil perfilPorCci(String cci) {
        for (Credencial c : porCorreo.values()) if (c.perfil().cci().equals(cci)) return c.perfil();
        return null;
    }

    private Acceso abrirSesion(Perfil perfil) {
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(nuevoAleatorio(32));
        String csrf = Base64.getUrlEncoder().withoutPadding().encodeToString(nuevoAleatorio(24));
        long vence = Instant.now().toEpochMilli() + VIDA;
        Sesion sesion = new Sesion(perfil, csrf, vence);
        sesiones.put(digest(token), new SesionInterna(sesion));
        if (sesiones.size() > 4096) sesiones.entrySet().removeIf(e -> e.getValue().sesion().venceEn() < System.currentTimeMillis());
        return new Acceso(sesion, token);
    }

    public Sesion sesion(String token) {
        if (token == null || token.length() > 128 || token.isBlank()) return null;
        SesionInterna s = sesiones.get(digest(token));
        if (s == null) return null;
        if (s.sesion().venceEn() <= System.currentTimeMillis()) {
            sesiones.remove(digest(token));
            return null;
        }
        return s.sesion();
    }

    public void cerrar(String token) {
        if (token != null && token.length() <= 128) sesiones.remove(digest(token));
    }

    private void guardar() throws IOException {
        StringBuilder b = new StringBuilder("NDR-USUARIOS-2\n");
        for (Credencial c : porCorreo.values()) {
            Perfil p = c.perfil();
            b.append(enc(p.id())).append('|').append(enc(p.nombre())).append('|')
             .append(enc(p.correo())).append('|').append(enc(p.telefono())).append('|')
             .append(enc(p.cci())).append('|').append(c.sal()).append('|').append(c.resumen()).append('\n');
        }
        Path temporal = Files.createTempFile(archivo.getParent(), "ndr-", ".tmp");
        try {
            limitarPermisos(temporal, false);
            Files.writeString(temporal, b.toString(), StandardCharsets.UTF_8, StandardOpenOption.TRUNCATE_EXISTING);
            try {
                Files.move(temporal, archivo, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException noAtomico) {
                Files.move(temporal, archivo, StandardCopyOption.REPLACE_EXISTING);
            }
            limitarPermisos(archivo, false);
        } finally { Files.deleteIfExists(temporal); }
    }

    private static void validar(String nombre, String correo, String telefono, String clave) {
        if (nombre.length() < 3 || nombre.length() > 100 || nombre.chars().anyMatch(ch -> ch < 32))
            throw new Falta(400, "Introduce tu nombre completo (3 a 100 caracteres).");
        if (correo.length() > 254 || !correo.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$"))
            throw new Falta(400, "Introduce un correo electrónico válido.");
        if (!telefono.matches("\\+519[0-9]{8}"))
            throw new Falta(400, "Introduce un celular peruano válido: +51 9XXXXXXXX.");
        if (clave.length() < 12 || clave.length() > 128 || clave.chars().anyMatch(ch -> ch < 32))
            throw new Falta(400, "La contraseña debe tener entre 12 y 128 caracteres.");
    }

    public static String normalizarTelefono(String tel) {
        String limpio = tel.replaceAll("[ ()-]", "");
        if (limpio.matches("9[0-9]{8}")) limpio = "+51" + limpio;
        if (limpio.matches("519[0-9]{8}")) limpio = "+" + limpio;
        return limpio;
    }

    private String generarCciUnico() {
        String cci;
        do {
            StringBuilder b = new StringBuilder("002");
            for (int i = 0; i < 17; i++) b.append(ALEATORIO.nextInt(10));
            cci = b.toString();
        } while (!ccis.add(cci));
        ccis.remove(cci);
        return cci;
    }

    private static byte[] hash(char[] clave, byte[] sal) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(clave, sal, ITERACIONES, 256);
        try { return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(); }
        finally { spec.clearPassword(); Arrays.fill(clave, '\0'); }
    }
    private static byte[] nuevoAleatorio(int cantidad) { byte[] a = new byte[cantidad]; ALEATORIO.nextBytes(a); return a; }
    private static String digest(String s) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.US_ASCII));
            return HexFormat.of().formatHex(d);
        } catch (Exception e) { throw new IllegalStateException(e); }
    }
    private static String enc(String s) { return Base64.getUrlEncoder().withoutPadding().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }
    private static String dec(String s) { return new String(Base64.getUrlDecoder().decode(s), StandardCharsets.UTF_8); }
    private static void limitarPermisos(Path p, boolean dir) {
        try { Files.setPosixFilePermissions(p, java.nio.file.attribute.PosixFilePermissions.fromString(dir ? "rwx------" : "rw-------")); }
        catch (UnsupportedOperationException | IOException ignored) { }
    }
    public static final class Falta extends RuntimeException {
        public final int codigo;
        public Falta(int codigo, String mensaje) { super(mensaje); this.codigo = codigo; }
    }
}
