Write-Host 'DIAGNOSTICO LOCAL: cierres de Chrome, Edge o Java en las ultimas 24 horas.'
Write-Host 'No compartas datos privados ni contrasenas.'
try {
  Get-WinEvent -FilterHashtable @{LogName='Application';Id=1000,1001;StartTime=(Get-Date).AddHours(-24)} -ErrorAction Stop |
    Where-Object { $_.Message -match '(?i)chrome.exe|msedge.exe|java.exe|javaw.exe' } |
    Select-Object -First 12 TimeCreated,Id,ProviderName,@{Name='Aplicacion';Expression={
      if ($_.Message -match '(?i)(chrome.exe|msedge.exe|javaw?.exe)') { $Matches[1] } else { 'Desconocida' }
    }} | Format-Table -AutoSize
} catch {
  Write-Host 'No se pudo leer el registro de fallos; utiliza el Historial de confiabilidad de Windows (perfmon /rel).'
}
Write-Host 'Si no hay eventos, revisa tambien extensiones y el controlador grafico.'
