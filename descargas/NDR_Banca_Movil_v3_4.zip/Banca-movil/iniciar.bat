@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title NDR v3.4 - NAVIDAD SALDO (NO CERRAR)
set "NDR_PUERTO=18083"
if defined PORT set "NDR_PUERTO=%PORT%"
echo ===============================================
echo  NDR 3.4 - NAVIDAD SALDO (PUERTO %NDR_PUERTO%)
echo ===============================================
where java >nul 2>nul
if errorlevel 1 (
 echo ERROR: Instala Java 17 o superior.
 pause
 exit /b 1
)
if not exist "target\banca-movil.jar" (
 echo ERROR: Falta target\banca-movil.jar. Ejecuta compilar.bat.
 pause
 exit /b 1
)
rem Comprobamos la VERSION; el servidor viejo en 8080 ya no puede interceptar esta entrega.
powershell -NoProfile -Command "try { $r=Invoke-RestMethod -Uri 'http://127.0.0.1:%NDR_PUERTO%/api/salud' -TimeoutSec 2; if ($r.servicio -eq 'NDR' -and $r.version -eq '3.4-navidad-saldo') { exit 0 } else { exit 2 } } catch { exit 1 }"
set "COMPROBAR=%ERRORLEVEL%"
if "%COMPROBAR%"=="0" (
 echo Ya hay un servidor NDR 3.4 abierto en este puerto.
 echo Abre ABRIR_NDR.bat en esta carpeta.
 pause
 exit /b 0
)
if "%COMPROBAR%"=="2" (
 echo ERROR: Ya existe OTRO servidor en %NDR_PUERTO%.
 echo Cierra ese proceso o asigna PORT distinto en ambos archivos de apertura.
 pause
 exit /b 2
)
echo Servidor local: http://127.0.0.1:%NDR_PUERTO%/
echo No cierres esta ventana: si Java falla, aqui veras el motivo.
echo.
java -jar "target\banca-movil.jar"
set "CODIGO=%ERRORLEVEL%"
echo.
echo Servidor detenido, codigo %CODIGO%. Guarda este mensaje para diagnosticar.
pause
exit /b %CODIGO%
