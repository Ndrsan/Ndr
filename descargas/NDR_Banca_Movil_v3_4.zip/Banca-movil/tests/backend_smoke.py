#!/usr/bin/env python3
"""Integration checks against the rebuilt JAR using disposable local profiles.

Run after compilar.sh / compilar.bat:
    python3 tests/backend_smoke.py
Requires Python 3 and Java 17+. Does not contact a bank or external service.
"""

from contextlib import contextmanager
from http.cookiejar import CookieJar
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import tempfile
import time
import unittest
import uuid
from urllib.error import HTTPError, URLError
from urllib.request import HTTPCookieProcessor, ProxyHandler, Request, build_opener


PROJECT = Path(__file__).resolve().parents[1]
JAR = PROJECT / "target" / "banca-movil.jar"
# Exactly twelve characters, including both significant boundary spaces.
PASSWORD = " abc1234567 "
PROFILE = {
    "nombre": "Prueba Local",
    "correo": "prueba@example.invalid",
    "telefono": "900000001",
    "password": PASSWORD,
}


class BackendSmoke(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not JAR.is_file():
            raise RuntimeError("Build target/banca-movil.jar before running these checks.")
        if not shutil.which("java"):
            raise RuntimeError("Java 17+ must be available in PATH.")

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="ndr-backend-test-")
        self.addCleanup(self.temp.cleanup)
        self.data_dir = Path(self.temp.name) / "data"
        self.cookies = CookieJar()
        # Only these local requests bypass the inherited external HTTP proxy.
        self.http = build_opener(ProxyHandler({}), HTTPCookieProcessor(self.cookies))
        self.base = None

    @contextmanager
    def server(self, provider=None):
        with socket.socket() as available:
            available.bind(("127.0.0.1", 0))
            port = available.getsockname()[1]
        environment = os.environ.copy()
        environment["PORT"] = str(port)
        environment["NDR_DATA_DIR"] = str(self.data_dir)
        # Exercise the shipped local mode, regardless of caller integration settings.
        environment.pop("NDR_PROVIDER_CLASS", None)
        if provider is not None:
            environment["NDR_PROVIDER_CLASS"] = provider
        environment.pop("NDR_PUBLIC_ORIGIN", None)
        self.base = f"http://127.0.0.1:{port}"
        with tempfile.TemporaryFile(mode="w+b") as log:
            process = subprocess.Popen(
                ["java", "-jar", str(JAR)],
                cwd=PROJECT,
                env=environment,
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
            )
            try:
                deadline = time.monotonic() + 20
                while time.monotonic() < deadline:
                    if process.poll() is not None:
                        self.fail(f"Local server exited during startup ({process.returncode}).")
                    try:
                        status, response = self.request("/api/salud")
                        if status == 200 and response.get("servicio") == "NDR":
                            break
                    except (OSError, URLError):
                        pass
                    time.sleep(0.05)
                else:
                    self.fail("Local server did not become ready within 20 seconds.")
                yield
            finally:
                if process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait(timeout=5)

    def request(self, path, data=None, csrf=None):
        headers = {}
        if data is not None:
            headers.update({
                "Origin": self.base,
                "Content-Type": "application/json",
                "X-NDR-Request": "1",
            })
        if csrf is not None:
            headers["X-NDR-CSRF"] = csrf
        payload = None if data is None else json.dumps(data).encode("utf-8")
        request = Request(self.base + path, data=payload, headers=headers)
        try:
            response = self.http.open(request, timeout=5)
        except HTTPError as error:
            response = error
        with response:
            return response.status, json.load(response)

    def register(self, profile=PROFILE):
        status, response = self.request("/api/auth/registro", profile)
        self.assertEqual(status, 201)
        self.assertTrue(response["ok"])
        self.assertNotIn("csrf", response)

    def login(self, password=PASSWORD, identifier=PROFILE["correo"]):
        return self.request("/api/auth/login", {
            "identificador": identifier,
            "password": password,
        })

    def test_registration_stays_logged_out_and_rejects_duplicates(self):
        with self.server():
            self.register()
            self.assertEqual(self.request("/api/auth/sesion")[0], 401)
            self.assertEqual(self.request("/api/cuenta")[0], 401)
            self.assertFalse(any(c.name == "NDR_SESION" for c in self.cookies))
            self.assertEqual(self.request("/api/auth/registro", PROFILE)[0], 409)

    def test_login_preserves_exact_password_including_spaces(self):
        self.assertEqual(len(PASSWORD), 12)
        with self.server():
            self.register()
            self.assertEqual(self.login(password=PASSWORD.strip())[0], 401)
            self.assertEqual(self.login(password="wrong-password")[0], 401)
            status, session = self.login()
            self.assertEqual(status, 200)
            self.assertTrue(session["ok"])
            self.assertEqual(session["usuario"]["correo"], PROFILE["correo"])
            self.assertEqual(self.request("/api/auth/sesion")[0], 200)
            # The supported phone login uses the same literal credential.
            self.assertEqual(self.login(identifier="+51 900000001")[0], 200)

    def test_logout_invalidates_session(self):
        with self.server():
            self.register()
            status, session = self.login()
            self.assertEqual(status, 200)
            self.assertEqual(self.request("/api/auth/logout", {})[0], 403)
            self.assertEqual(self.request("/api/auth/sesion")[0], 200)
            self.assertEqual(self.request("/api/auth/logout", {}, session["csrf"])[0], 200)
            self.assertEqual(self.request("/api/auth/sesion")[0], 401)

    def test_profiles_persist_and_sessions_expire_on_restart(self):
        with self.server():
            self.register()
            status, first_session = self.login()
            self.assertEqual(status, 200)
            user_id = first_session["usuario"]["id"]
        self.assertTrue((self.data_dir / "usuarios.ndr").is_file())
        with self.server():
            self.assertEqual(self.request("/api/auth/sesion")[0], 401)
            status, session = self.login()
            self.assertEqual(status, 200)
            self.assertEqual(session["usuario"]["id"], user_id)
            self.assertEqual(self.request("/api/auth/registro", PROFILE)[0], 409)

    def transfer(self, **changes):
        payload = {
            "beneficiario": "Destino Local",
            "cci": "00999999999999999999",
            "monto": "20.00",
            "concepto": "Prueba de transferencia",
            "claveIdempotencia": str(uuid.uuid4()),
        }
        payload.update(changes)
        return payload

    def account(self):
        status, response = self.request("/api/cuenta")
        self.assertEqual(status, 200)
        return response["cuenta"]

    def movements(self):
        status, response = self.request("/api/movimientos")
        self.assertEqual(status, 200)
        return response["movimientos"]

    def test_default_account_starts_with_200_once(self):
        with self.server():
            self.register()
            status, session = self.login()
            self.assertEqual(status, 200)
            status, bank = self.request("/api/estado")
            self.assertEqual(status, 200)
            self.assertEqual(bank["modo"], "local")
            self.assertEqual(bank["proveedor"], "NDR")
            self.assertTrue(bank["conectado"])
            self.assertTrue(bank["autenticado"])
            account = self.account()
            self.assertEqual(account["saldo"], "200.00")
            self.assertEqual(account["numero"], session["usuario"]["cci"])
            self.assertEqual(account["moneda"], "PEN")
            self.assertTrue((self.data_dir / "cuentas-locales.ndr").is_file())
            self.assertEqual(self.account()["saldo"], "200.00")
            self.assertEqual(self.movements(), [])
        with self.server():
            self.assertEqual(self.login()[0], 200)
            self.assertEqual(self.account()["saldo"], "200.00")

    def test_transfer_debits_once_and_rejects_changed_idempotent_payload(self):
        with self.server():
            self.register()
            status, session = self.login()
            self.assertEqual(status, 200)
            transfer = self.transfer(monto="25.75")
            status, receipt = self.request("/api/transferencias", transfer, session["csrf"])
            self.assertEqual(status, 202)
            self.assertEqual(receipt["transferencia"]["estado"], "Registrada")
            self.assertEqual(self.account()["saldo"], "174.25")
            status, repeat = self.request("/api/transferencias", transfer, session["csrf"])
            self.assertEqual(status, 202)
            self.assertEqual(repeat, receipt)
            self.assertEqual(self.account()["saldo"], "174.25")
            status, error = self.request("/api/transferencias", {**transfer, "monto": "1.00"}, session["csrf"])
            self.assertEqual(status, 409)
            self.assertFalse(error["ok"])
            self.assertEqual(self.account()["saldo"], "174.25")
            movements = self.movements()
            self.assertEqual(len(movements), 1)
            self.assertEqual(movements[0]["monto"], "-25.75")
            self.assertIn(transfer["beneficiario"], movements[0]["descripcion"])

    def test_invalid_transfers_and_insufficient_funds_leave_balance_unchanged(self):
        with self.server():
            self.register()
            status, session = self.login()
            self.assertEqual(status, 200)
            self.assertEqual(self.request("/api/transferencias", self.transfer())[0], 403)
            for amount in ["0", "-1", "1.001", "50000.01"]:
                self.assertEqual(self.request("/api/transferencias", self.transfer(monto=amount), session["csrf"])[0], 400)
            self.assertEqual(self.request("/api/transferencias", self.transfer(cci="123"), session["csrf"])[0], 400)
            self.assertEqual(self.request("/api/transferencias", self.transfer(cci=session["usuario"]["cci"]), session["csrf"])[0], 400)
            self.assertEqual(self.request("/api/transferencias", self.transfer(monto="200.01"), session["csrf"])[0], 422)
            self.assertEqual(self.account()["saldo"], "200.00")
            self.assertEqual(self.movements(), [])

    def test_cent_precision_and_idempotency_survive_restart(self):
        first = self.transfer(monto="0.01")
        with self.server():
            self.register()
            status, session = self.login()
            self.assertEqual(status, 200)
            status, first_receipt = self.request("/api/transferencias", first, session["csrf"])
            self.assertEqual(status, 202)
            self.assertEqual(self.request("/api/transferencias", self.transfer(monto="0.02"), session["csrf"])[0], 202)
            self.assertEqual(self.account()["saldo"], "199.97")
        with self.server():
            status, session = self.login()
            self.assertEqual(status, 200)
            self.assertEqual(self.account()["saldo"], "199.97")
            status, replay = self.request("/api/transferencias", first, session["csrf"])
            self.assertEqual(status, 202)
            self.assertEqual(replay, first_receipt)
            self.assertEqual(self.account()["saldo"], "199.97")
            self.assertEqual(len(self.movements()), 2)

    def test_registered_recipient_is_credited_and_history_is_scoped(self):
        second = {**PROFILE, "nombre": "Segunda Persona", "correo": "segunda@example.invalid", "telefono": "900000002"}
        third = {**PROFILE, "nombre": "Tercera Persona", "correo": "tercera@example.invalid", "telefono": "900000003"}
        with self.server():
            self.register()
            self.register(second)
            self.register(third)
            status, recipient = self.login(identifier=second["correo"])
            self.assertEqual(status, 200)
            # No prior account consultation: receiving must initialize exactly once.
            recipient_cci = recipient["usuario"]["cci"]
            status, sender = self.login()
            self.assertEqual(status, 200)
            transfer = self.transfer(cci=recipient_cci, monto="12.34")
            self.assertEqual(self.request("/api/transferencias", transfer, sender["csrf"])[0], 202)
            self.assertEqual(self.account()["saldo"], "187.66")
            self.assertEqual(self.login(identifier=second["correo"])[0], 200)
            self.assertEqual(self.account()["saldo"], "212.34")
            self.assertEqual(len(self.movements()), 1)
            self.assertEqual(self.movements()[0]["monto"], "+12.34")
            self.assertEqual(self.login(identifier=third["correo"])[0], 200)
            self.assertEqual(self.account()["saldo"], "200.00")
            self.assertEqual(self.movements(), [])
        with self.server():
            self.assertEqual(self.login(identifier=second["correo"])[0], 200)
            self.assertEqual(self.account()["saldo"], "212.34")
            self.assertEqual(len(self.movements()), 1)

    def test_explicit_broken_provider_stays_blocked(self):
        with self.server(provider="ProveedorQueNoExiste"):
            self.register()
            status, session = self.login()
            self.assertEqual(status, 200)
            status, bank = self.request("/api/estado")
            self.assertEqual(status, 200)
            self.assertEqual(bank["modo"], "desconectado")
            self.assertFalse(bank["conectado"])
            self.assertEqual(self.request("/api/cuenta")[0], 503)
            self.assertEqual(self.request("/api/transferencias", self.transfer(), session["csrf"])[0], 503)

    def test_corrupt_ledger_is_preserved_without_reset(self):
        with self.server():
            self.register()
            self.assertEqual(self.login()[0], 200)
            self.assertEqual(self.account()["saldo"], "200.00")
        ledger = self.data_dir / "cuentas-locales.ndr"
        invalid = b"NDR-CUENTAS-1\ninvalid-record\n"
        ledger.write_bytes(invalid)
        environment = os.environ.copy()
        environment.update({"PORT": "18083", "NDR_DATA_DIR": str(self.data_dir)})
        environment.pop("NDR_PROVIDER_CLASS", None)
        environment.pop("NDR_PUBLIC_ORIGIN", None)
        result = subprocess.run(["java", "-jar", str(JAR)], cwd=PROJECT, env=environment,
                                stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn(b"Archivo de cuentas", result.stdout)
        self.assertEqual(ledger.read_bytes(), invalid)

    def test_second_process_cannot_open_the_same_ledger(self):
        with self.server():
            self.register()
            self.assertEqual(self.login()[0], 200)
            self.assertEqual(self.account()["saldo"], "200.00")
            environment = os.environ.copy()
            environment.update({"PORT": "18084", "NDR_DATA_DIR": str(self.data_dir)})
            environment.pop("NDR_PROVIDER_CLASS", None)
            environment.pop("NDR_PUBLIC_ORIGIN", None)
            result = subprocess.run(["java", "-jar", str(JAR)], cwd=PROJECT, env=environment,
                                    stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn(b"otra instancia", result.stdout)
            self.assertEqual(self.account()["saldo"], "200.00")


if __name__ == "__main__":
    unittest.main(verbosity=2)
