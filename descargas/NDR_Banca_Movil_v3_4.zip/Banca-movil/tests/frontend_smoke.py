"""Pruebas de interfaz con API aislada dentro de Chromium.

Ejecutar: python3 tests/frontend_smoke.py
Requiere Playwright para Python y Chromium; NDR_BROWSER_PATH permite elegirlo.
No usa cuentas ni servicios externos.
"""

from decimal import Decimal
import json
import os
from pathlib import Path
import shutil
import unittest
from urllib.parse import urlsplit

from playwright.sync_api import expect, sync_playwright

ROOT = Path(__file__).resolve().parents[1]
ORIGIN = "http://127.0.0.1:18083"
USER = {"id": "usuario-1", "nombre": "Persona de Prueba", "correo": "prueba@example.test",
        "telefono": "+51900000001", "cci": "00200000000000000001"}


class FrontendSmoke(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.playwright = sync_playwright().start()
        options = {"headless": True, "args": ["--no-sandbox"]}
        executable = os.environ.get("NDR_BROWSER_PATH") or shutil.which("chromium")
        if executable:
            options["executable_path"] = executable
        cls.browser = cls.playwright.chromium.launch(**options)

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.playwright.stop()

    def setup_page(self, width=1280, height=720, storage_denied=False):
        context = self.browser.new_context(viewport={"width": width, "height": height}, reduced_motion="reduce")
        self.addCleanup(context.close)
        if storage_denied:
            context.add_init_script("Object.defineProperty(window, 'localStorage', {get() { throw new DOMException('Denied', 'SecurityError'); }});")
        state = {"authenticated": False, "connected": True, "mode": "local", "user": USER.copy(),
                 "balance": Decimal("200.00"), "posts": [], "movements": [], "errors": [], "held": []}

        def respond(route, status, body):
            route.fulfill(status=status, content_type="application/json", body=json.dumps(body))

        def handle(route):
            request = route.request
            path = urlsplit(request.url).path
            if path.startswith("/api/"):
                if request.method == "POST":
                    state["posts"].append((path, request.post_data_json))
                session = {"ok": True, "usuario": state["user"], "csrf": "token-solo-para-pruebas"}
                if path == "/api/auth/sesion":
                    respond(route, 200 if state["authenticated"] else 401,
                            session if state["authenticated"] else {"ok": False, "mensaje": "Inicia sesión."})
                elif path == "/api/auth/registro":
                    respond(route, 201, {"ok": True, "mensaje": "Cuenta NDR creada correctamente."})
                elif path == "/api/auth/login":
                    state["authenticated"] = True
                    respond(route, 200, session)
                elif path == "/api/auth/logout":
                    state["authenticated"] = False
                    respond(route, 200, {"ok": True})
                elif path == "/api/estado":
                    respond(route, 200, {"ok": True, "proveedor": "NDR", "modo": state["mode"],
                                        "conectado": state["connected"], "autenticado": state["connected"]})
                elif path == "/api/cuenta":
                    body = {"ok": True, "cuenta": {"numero": state["user"]["cci"], "moneda": "PEN",
                            "saldo": str(state["balance"]), "actualizadoEn": "2026-11-03T12:00:00Z"}}
                    if state.get("hold_account"):
                        state["held"].append((route, body))
                    else:
                        respond(route, 200, body)
                elif path == "/api/movimientos":
                    respond(route, 200, {"ok": True, "movimientos": state["movements"]})
                elif path == "/api/transferencias":
                    data = request.post_data_json
                    amount = Decimal(data["monto"])
                    if amount > state["balance"]:
                        respond(route, 422, {"ok": False, "mensaje": "Saldo insuficiente para esta transferencia."})
                    else:
                        state["balance"] -= amount
                        state["movements"].insert(0, {"id": "operacion-1", "fecha": "2026-11-03T12:00:00Z",
                            "descripcion": data["beneficiario"] + " · " + data["concepto"],
                            "monto": "-" + str(amount), "moneda": "PEN", "estado": "Registrada"})
                        respond(route, 202, {"ok": True, "transferencia": {"id": "operacion-1",
                            "estado": "Registrada", "referencia": "NDR-PRUEBA-1"}})
                else:
                    respond(route, 404, {"ok": False, "mensaje": "API no disponible en esta prueba."})
                return
            files = {"/": ("index.html", "text/html"), "/style.css": ("style.css", "text/css"),
                     "/app.js": ("app.js", "text/javascript"), "/assets/banca-movil.png": ("assets/banca-movil.png", "image/png")}
            if path in files:
                filename, mime = files[path]
                route.fulfill(status=200, content_type=mime, body=(ROOT / filename).read_bytes())
            else:
                route.fulfill(status=404, body="Not found")

        context.route(ORIGIN + "/**", handle)
        page = context.new_page()
        page.on("pageerror", lambda error: state["errors"].append(str(error)))
        page.goto(ORIGIN, wait_until="networkidle")
        return page, state

    def login(self, page):
        page.locator("#loginId").fill(USER["correo"])
        page.locator("#loginPassword").fill("Clave-de-prueba-123")
        page.locator("#loginSubmit").click()
        expect(page.locator("#authView")).to_be_hidden()
        expect(page.locator("#bankApp")).to_be_visible()
        expect(page.locator("#toggleBalance")).to_be_enabled()

    def fill_transfer(self, page, amount="25.50"):
        if not page.locator("#inicio").is_visible():
            page.locator('[data-view="inicio"]:visible').first.click()
        page.locator('[data-view="transferencias"]').first.click()
        page.locator("#beneficiary").fill("Destino de Prueba")
        page.locator("#cci").fill("00200000000000000002")
        page.locator("#transferAmount").fill(amount)
        page.locator("#concept").fill("Prueba de operación")

    def test_registration_login_logout_visibility(self):
        for width, height in [(1280, 720), (390, 844)]:
            with self.subTest(viewport=f"{width}x{height}"):
                page, state = self.setup_page(width, height)
                expect(page.locator("#loginForm")).to_be_visible()
                expect(page.locator("#registerForm")).to_be_hidden()
                page.locator("#showRegister").click()
                expect(page.locator("#loginForm")).to_be_hidden()
                page.locator("#showLogin").click()
                expect(page.locator("#registerForm")).to_be_hidden()
                page.locator("#showRegister").click()
                for id, value in {"registerName": USER["nombre"], "registerEmail": USER["correo"],
                    "registerPhone": "900000001", "registerPassword": "Clave-de-prueba-123", "registerRepeat": "Clave-de-prueba-123"}.items():
                    page.locator("#" + id).fill(value)
                page.locator("#registerSubmit").click()
                expect(page.locator("#authMessage")).to_have_text("Cuenta NDR creada correctamente.")
                expect(page.locator("#registerForm")).to_be_hidden()
                expect(page.locator("#loginForm")).to_be_visible()
                expect(page.locator("#bankApp")).to_be_hidden()
                self.login(page)
                self.assertEqual(page.evaluate("window.scrollY"), 0, "El ingreso debe abrir el inicio desde arriba")
                expect(page.locator("#connectionText")).to_have_text("Cuenta activa")
                expect(page.locator("#balanceValue")).to_have_text("S/ 200.00")
                expect(page.locator("#bankNotice")).to_be_hidden()
                expect(page.locator("#balanceNote")).to_contain_text("7:00:00")
                page.locator("#logoutButton").click()
                expect(page.locator("#bankApp")).to_be_hidden()
                expect(page.locator("#loginForm")).to_be_visible()
                expect(page.locator("#registerForm")).to_be_hidden()
                expect(page.locator("#balanceValue")).to_have_text("—")
                expect(page.locator("#profileName")).to_have_text("—")
                self.assertEqual([path for path, _ in state["posts"]], ["/api/auth/registro", "/api/auth/login", "/api/auth/logout"])
                self.assertEqual(state["errors"], [])

    def test_balance_preference_is_persistent_and_scoped_to_user(self):
        page, state = self.setup_page()
        self.login(page)
        page.locator("#toggleBalance").focus()
        page.keyboard.press("Enter")
        expect(page.locator("#balanceValue")).to_have_text("••••••")
        expect(page.locator("#toggleBalance")).to_have_attribute("aria-label", "Mostrar saldo")
        expect(page.locator("#toggleBalance")).to_have_attribute("aria-pressed", "true")
        expect(page.locator("#balanceEye")).to_be_hidden()
        expect(page.locator("#balanceEyeOff")).to_be_visible()
        page.locator("#refreshAccount").click()
        expect(page.locator("#toggleBalance")).to_be_enabled()
        expect(page.locator("#balanceValue")).to_have_text("••••••")
        page.reload(wait_until="networkidle")
        expect(page.locator("#balanceValue")).to_have_text("••••••")
        page.locator("#logoutButton").click()
        expect(page.locator("#bankApp")).to_be_hidden()
        state["user"]["id"] = "usuario-2"
        state["user"]["correo"] = "otra@example.test"
        self.login(page)
        expect(page.locator("#balanceValue")).to_have_text("S/ 200.00")
        page.locator("#logoutButton").click()
        expect(page.locator("#bankApp")).to_be_hidden()
        state["user"] = USER.copy()
        self.login(page)
        expect(page.locator("#balanceValue")).to_have_text("••••••")
        self.assertEqual(state["errors"], [])

    def test_transfer_confirmation_cancel_success_history_and_insufficient_balance(self):
        for width, height in [(1280, 720), (390, 844)]:
            with self.subTest(viewport=f"{width}x{height}"):
                page, state = self.setup_page(width, height)
                self.login(page)
                page.locator("#toggleBalance").click()
                self.fill_transfer(page)
                page.locator("#transferSubmit").click()
                expect(page.locator("#confirmDialog")).to_be_visible()
                expect(page.locator("#confirmAmount")).to_have_text("S/ 25.50")
                page.locator("#cancelTransfer").click()
                expect(page.locator("#confirmDialog")).to_be_hidden()
                self.assertEqual(state["balance"], Decimal("200.00"))
                self.assertFalse(any(p == "/api/transferencias" for p, _ in state["posts"]))
                page.locator("#transferSubmit").click()
                page.locator("#confirmTransfer").evaluate("e => { e.click(); e.click(); }")
                expect(page.locator("#transferResult")).to_be_visible()
                expect(page.locator("#resultBeneficiary")).to_have_text("Destino de Prueba")
                expect(page.locator("#resultAmount")).to_have_text("S/ 25.50")
                expect(page.locator("#resultState")).to_have_text("Registrada")
                expect(page.locator("#resultReference")).to_have_text("NDR-PRUEBA-1")
                expect(page.locator("#transferSubmit")).to_be_enabled()
                expect(page.locator("#balanceValue")).to_have_text("••••••")
                transfers = [data for path, data in state["posts"] if path == "/api/transferencias"]
                self.assertEqual(len(transfers), 1)
                self.assertTrue(transfers[0]["claveIdempotencia"])
                page.locator('[data-view="inicio"]').first.click()
                page.locator("#toggleBalance").click()
                expect(page.locator("#balanceValue")).to_have_text("S/ 174.50")
                page.locator('[data-view="historial"]').click()
                expect(page.locator("#movementRows")).to_contain_text("Destino de Prueba")
                self.fill_transfer(page, "175.00")
                page.locator("#transferSubmit").click()
                page.locator("#confirmTransfer").click()
                expect(page.locator("#transferMessage")).to_have_text("Saldo insuficiente para esta transferencia.")
                expect(page.locator("#transferResult")).to_be_hidden()
                expect(page.locator("#transferSubmit")).to_be_enabled()
                expect(page.locator("#balanceValue")).to_have_text("S/ 174.50")
                self.assertEqual(state["balance"], Decimal("174.50"))
                self.assertEqual(state["errors"], [])

    def test_storage_denied_keeps_balance_toggle_functional(self):
        page, state = self.setup_page(storage_denied=True)
        self.login(page)
        page.locator("#toggleBalance").click()
        expect(page.locator("#balanceValue")).to_have_text("••••••")
        page.locator("#refreshAccount").click()
        expect(page.locator("#toggleBalance")).to_be_enabled()
        expect(page.locator("#balanceValue")).to_have_text("••••••")
        page.locator("#toggleBalance").click()
        expect(page.locator("#balanceValue")).to_have_text("S/ 200.00")
        self.assertEqual(state["errors"], [])

    def test_unavailable_provider_disables_transfer_and_external_mode_remains_supported(self):
        page, state = self.setup_page()
        state["connected"] = False
        page.locator("#loginId").fill(USER["correo"])
        page.locator("#loginPassword").fill("Clave-de-prueba-123")
        page.locator("#loginSubmit").click()
        expect(page.locator("#bankApp")).to_be_visible()
        expect(page.locator("#bankNotice")).to_be_visible()
        expect(page.locator("#balanceValue")).to_have_text("No disponible")
        expect(page.locator("#transferSubmit")).to_be_disabled()
        state["connected"] = True
        state["mode"] = "externo"
        page.locator("#refreshAccount").click()
        expect(page.locator("#connectionText")).to_have_text("Banco verificado")
        expect(page.locator("#bankNotice")).to_be_hidden()
        expect(page.locator("#balanceValue")).to_have_text("S/ 200.00")
        self.assertEqual(state["errors"], [])

    def test_late_account_response_does_not_restore_logged_out_data(self):
        page, state = self.setup_page()
        self.login(page)
        state["hold_account"] = True
        page.locator("#refreshAccount").click()
        page.wait_for_function("document.querySelector('#balanceValue').textContent === 'Consultando…'")
        page.locator("#logoutButton").click()
        expect(page.locator("#bankApp")).to_be_hidden()
        self.assertEqual(len(state["held"]), 1)
        route, body = state["held"].pop()
        route.fulfill(status=200, content_type="application/json", body=json.dumps(body))
        page.wait_for_load_state("networkidle")
        expect(page.locator("#balanceValue")).to_have_text("—")
        expect(page.locator("#profileName")).to_have_text("—")
        self.assertEqual(state["errors"], [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
