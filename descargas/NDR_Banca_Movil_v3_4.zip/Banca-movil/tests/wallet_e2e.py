#!/usr/bin/env python3
"""Pruebas de extremo a extremo con Chromium y el servidor Java del JAR.

Ejecutar después de compilar: python3 tests/wallet_e2e.py
Requiere Java 17+, Playwright para Python y Chromium. NDR_BROWSER_PATH permite
seleccionar el navegador. Usa perfiles y archivos temporales; no contacta bancos.
NDR_SCREENSHOT_DIR activa capturas opcionales del panel con saldo inicial.
"""

from contextlib import contextmanager
from decimal import Decimal
import json
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import tempfile
import time
import unittest
from urllib.error import URLError
from urllib.parse import urljoin
from urllib.request import ProxyHandler, build_opener

from playwright.sync_api import expect, sync_playwright


ROOT = Path(__file__).resolve().parents[1]
JAR = ROOT / "target" / "banca-movil.jar"
PASSWORD = " Acceso-12345 "
EMAIL = "navegador@example.invalid"
DESTINATION = "99900000000000000001"


@contextmanager
def server(data_dir):
    """Arranca una instancia aislada y la detiene incluso si falla la prueba."""
    with socket.socket() as available:
        available.bind(("127.0.0.1", 0))
        port = available.getsockname()[1]
    base = f"http://127.0.0.1:{port}"
    environment = os.environ.copy()
    environment.update(PORT=str(port), NDR_DATA_DIR=str(data_dir))
    environment.pop("NDR_PROVIDER_CLASS", None)
    environment.pop("NDR_PUBLIC_ORIGIN", None)
    http = build_opener(ProxyHandler({}))
    with tempfile.TemporaryFile(mode="w+b") as log:
        process = subprocess.Popen(
            ["java", "-jar", str(JAR)], cwd=ROOT, env=environment,
            stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
        )
        try:
            deadline = time.monotonic() + 20
            while time.monotonic() < deadline:
                if process.poll() is not None:
                    raise RuntimeError("El servidor Java terminó durante el arranque.")
                try:
                    with http.open(base + "/api/salud", timeout=1) as response:
                        health = json.load(response)
                        if response.status == 200 and health.get("servicio") == "NDR":
                            break
                except (OSError, URLError):
                    pass
                time.sleep(0.05)
            else:
                raise RuntimeError("El servidor Java no estuvo disponible en 20 segundos.")
            yield base
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=5)


class WalletE2E(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not JAR.is_file() or not shutil.which("java"):
            raise RuntimeError("Compila el JAR y comprueba que Java 17+ esté disponible.")
        cls.playwright = sync_playwright().start()
        executable = os.environ.get("NDR_BROWSER_PATH") or shutil.which("chromium")
        options = {"headless": True, "args": ["--no-sandbox"]}
        if executable:
            options["executable_path"] = executable
        cls.browser = cls.playwright.chromium.launch(**options)

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.playwright.stop()

    def test_desktop_wallet(self):
        self.check_wallet(1280, 720)

    def test_mobile_wallet(self):
        self.check_wallet(390, 844)

    def account(self, page):
        response = page.request.get(urljoin(page.url, "/api/cuenta"))
        self.assertEqual(response.status, 200)
        return response.json()["cuenta"]

    def movements(self, page):
        response = page.request.get(urljoin(page.url, "/api/movimientos"))
        self.assertEqual(response.status, 200)
        return response.json()["movimientos"]

    def assert_balance(self, page, amount):
        expect(page.locator("#balanceValue")).to_have_text(
            re.compile(r"S/\s*" + re.escape(amount)), timeout=10000,
        )
        self.assertEqual(Decimal(self.account(page)["saldo"]), Decimal(amount))

    def login(self, page):
        page.locator("#loginId").fill(EMAIL)
        page.locator("#loginPassword").fill(PASSWORD)
        page.locator("#loginSubmit").click()
        expect(page.locator("#authView")).to_be_hidden(timeout=10000)
        expect(page.locator("#bankApp")).to_be_visible()

    def fill_transfer(self, page, amount):
        page.locator("#beneficiary").fill("Destinatario de Prueba")
        page.locator("#cci").fill(DESTINATION)
        page.locator("#transferAmount").fill(amount)
        page.locator("#concept").fill("Operación de prueba local")

    def check_wallet(self, width, height):
        with tempfile.TemporaryDirectory(prefix="ndr-wallet-e2e-") as temporary:
            data_dir = Path(temporary) / "data"
            context = self.browser.new_context(
                viewport={"width": width, "height": height},
                reduced_motion="reduce",
            )
            errors = []
            try:
                with server(data_dir) as base:
                    page = context.new_page()
                    page.on("pageerror", lambda error: errors.append(str(error)))
                    page.goto(base, wait_until="networkidle")
                    expect(page.locator("#registerForm")).to_be_hidden()
                    page.locator("#showRegister").click()
                    for name, value in {
                        "registerName": "Prueba Navegador",
                        "registerEmail": EMAIL,
                        "registerPhone": "900000001",
                        "registerPassword": PASSWORD,
                        "registerRepeat": PASSWORD,
                    }.items():
                        page.locator("#" + name).fill(value)
                    page.locator("#registerSubmit").click()
                    expect(page.locator("#authMessage")).to_contain_text(
                        "Cuenta NDR creada correctamente", timeout=10000,
                    )
                    expect(page.locator("#bankApp")).to_be_hidden()
                    self.login(page)
                    self.assert_balance(page, "200.00")
                    expect(page.locator("#connectionText")).to_have_text("Cuenta activa")
                    expect(page.locator("#transferSubmit")).to_be_enabled()
                    screenshot_dir = os.environ.get("NDR_SCREENSHOT_DIR")
                    if screenshot_dir:
                        destination = Path(screenshot_dir)
                        destination.mkdir(parents=True, exist_ok=True)
                        label = "desktop" if width >= 760 else "mobile"
                        page.screenshot(
                            path=str(destination / f"ndr-wallet-{label}.png"),
                            full_page=True,
                        )

                    # Ocultar/mostrar y recargar no debe revelar ni reiniciar el saldo.
                    toggle = page.locator("#toggleBalance")
                    toggle.click()
                    expect(page.locator("#balanceValue")).to_have_text("••••••")
                    expect(toggle).to_have_attribute("aria-label", "Mostrar saldo")
                    expect(toggle).to_have_attribute("aria-pressed", "true")
                    page.reload(wait_until="networkidle")
                    expect(page.locator("#balanceValue")).to_have_text("••••••")
                    page.locator("#toggleBalance").click()
                    self.assert_balance(page, "200.00")
                    expect(page.locator("#toggleBalance")).to_have_attribute(
                        "aria-label", "Ocultar saldo",
                    )

                    page.locator("#inicio [data-view='transferencias']").first.click()
                    self.fill_transfer(page, "25.50")
                    page.locator("#transferSubmit").click()
                    expect(page.locator("#confirmDialog")).to_be_visible()
                    expect(page.locator("#confirmAmount")).to_have_text("S/ 25.50")
                    page.locator("#cancelTransfer").click()
                    expect(page.locator("#confirmDialog")).not_to_be_visible()
                    self.assertEqual(Decimal(self.account(page)["saldo"]), Decimal("200.00"))
                    self.assertEqual(self.movements(page), [])

                    page.locator("#transferSubmit").click()
                    expect(page.locator("#confirmDialog")).to_be_visible()
                    with page.expect_response(
                        lambda response: response.url.endswith("/api/transferencias")
                        and response.request.method == "POST",
                    ) as outgoing:
                        page.locator("#confirmTransfer").click()
                    self.assertEqual(outgoing.value.status, 202)
                    expect(page.locator("#transferResult")).to_be_visible(timeout=10000)
                    expect(page.locator("#resultBeneficiary")).to_have_text("Destinatario de Prueba")
                    expect(page.locator("#resultAmount")).to_have_text(re.compile(r"S/\s*25\.50"))
                    expect(page.locator("#resultOperation")).not_to_be_empty()
                    self.assertEqual(Decimal(self.account(page)["saldo"]), Decimal("174.50"))
                    self.assertEqual(len(self.movements(page)), 1)

                    # La operación rechazada no debe crear recibo ni descontar fondos.
                    self.fill_transfer(page, "1000.00")
                    page.locator("#transferSubmit").click()
                    page.wait_for_function("""() => {
                        const dialog = document.getElementById('confirmDialog');
                        const message = document.getElementById('transferMessage');
                        return dialog.open || /saldo|fondos/i.test(message.textContent);
                    }""")
                    if page.locator("#confirmDialog").is_visible():
                        page.locator("#confirmTransfer").click()
                    expect(page.locator("#transferMessage")).to_contain_text(
                        re.compile(r"saldo|fondos", re.IGNORECASE), timeout=10000,
                    )
                    expect(page.locator("#transferResult")).to_be_hidden()
                    self.assertEqual(Decimal(self.account(page)["saldo"]), Decimal("174.50"))
                    self.assertEqual(len(self.movements(page)), 1)

                    page.locator("#transferencias [data-view='inicio']").click()
                    self.assert_balance(page, "174.50")
                    page.locator("#inicio [data-view='historial']").click()
                    expect(page.locator("#movementRows")).to_contain_text("25.50")
                    expect(page.locator("#movementRows")).to_contain_text("Destinatario de Prueba")
                    self.assertEqual(page.locator("#movementRows tr").count(), 1)
                    page.locator("#logoutButton").click()
                    expect(page.locator("#authView")).to_be_visible()
                    expect(page.locator("#bankApp")).to_be_hidden()
                    page.close()

                # Un reinicio del servidor conserva el importe y el historial.
                with server(data_dir) as restarted:
                    page = context.new_page()
                    page.on("pageerror", lambda error: errors.append(str(error)))
                    page.goto(restarted, wait_until="networkidle")
                    self.login(page)
                    self.assert_balance(page, "174.50")
                    self.assertEqual(len(self.movements(page)), 1)
                    page.locator("#logoutButton").click()
                    expect(page.locator("#authView")).to_be_visible()
                    self.assertEqual(errors, [])
            finally:
                context.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
