#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
rm -rf target/classes
mkdir -p target/classes target/classes/assets
javac --release 17 -encoding UTF-8 -d target/classes ./*.java
cp index.html style.css app.js target/classes/
cp assets/banca-movil.png target/classes/assets/
jar --create --file target/banca-movil.jar --main-class Main -C target/classes .
echo 'NDR compilado correctamente.'
