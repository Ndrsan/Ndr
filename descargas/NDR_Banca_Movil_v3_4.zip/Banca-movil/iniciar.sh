#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
java -jar target/banca-movil.jar
