@echo off
setlocal EnableExtensions
set "NDR_PUERTO=18083"
if defined PORT set "NDR_PUERTO=%PORT%"
set "NDR_URL=http://127.0.0.1:%NDR_PUERTO%/"
set "NDR_PROFILE=%LOCALAPPDATA%\NDR\navegador_diagnostico"
set "NAVEGADOR="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "NAVEGADOR=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "NAVEGADOR=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined NAVEGADOR if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "NAVEGADOR=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined NAVEGADOR if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "NAVEGADOR=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined NAVEGADOR (
 echo No se encontro Chrome ni Microsoft Edge en sus rutas habituales.
 echo Abre manualmente %NDR_URL% en un navegador normal.
 pause
 exit /b 1
)
echo Iniciando NDR en un PERFIL AISLADO, sin extensiones ni GPU.
echo Solo para diagnosticar cierres del navegador; no cambia la seguridad del banco.
start "" "%NAVEGADOR%" --user-data-dir="%NDR_PROFILE%" --disable-extensions --disable-gpu --no-first-run --new-window "%NDR_URL%"
