# NDR Banca Movil 3.4

## Uso

Java 17+ es suficiente para ejecutar el JAR incluido. En Windows, extrae el ZIP,
cierra el servidor anterior, ejecuta iniciar.bat y despues ABRIR_NDR.bat.
En Linux/macOS: sh iniciar.sh. El servidor escucha en 127.0.0.1:18083.
PORT permite elegir otro puerto. Mantener abierta la ventana del servidor.

Al entrar, Mi cuenta muestra un saldo inicial de S/ 200.00. El boton del ojo
permite ocultarlo o mostrarlo y recuerda la preferencia por cuenta y navegador.
Las operaciones posteriores actualizan ese saldo, no lo reinician.

## Cuenta e historial locales

Esta version proporciona un libro de movimientos local: no necesita conexiones,
credenciales ni llamadas a una entidad financiera. Los importes y las operaciones
se registran en el almacen de NDR. No se envian instrucciones a bancos externos.
Un CCI de destino de 20 digitos permite registrar una salida; si corresponde a
otro perfil de este mismo almacen NDR, se acredita tambien su cuenta.

Cada usuario recibe 200.00 una sola vez al activar su cuenta, incluidos los
perfiles conservados de versiones anteriores. El servidor valida importes,
saldo suficiente y destinatario; rechaza envios a la propia cuenta. La misma
clave de operacion no descuenta dos veces, incluso despues de reiniciar.

Las transferencias se revisan antes de confirmar y aparecen en el historial.
Un error no debe mostrarse como una operacion exitosa. Ante una desconexion
revisa el historial y actualiza la cuenta antes de repetir un envio incierto.

## Datos persistentes

El registro de perfiles sigue usando usuarios.ndr. El libro de cuentas e
historial se guarda por separado en el mismo directorio. Conserva y respalda
el directorio completo; no borres archivos para reiniciar el servidor.
NDR_DATA_DIR selecciona una ubicacion explicita. Windows usa normalmente
%LOCALAPPDATA%/NDR/datos, salvo que exista data/usuarios.ndr junto al proyecto.
En otros sistemas se usa data por defecto. Las sesiones se cierran al reiniciar.

Para usuarios anteriores, las contrasenas guardadas por la entrega original
habian perdido los espacios externos: usa el valor sin esos espacios para esas
cuentas. Las contrasenas de cuentas nuevas se conservan exactamente.

## API y compilacion

Se conservan las rutas /api/auth/registro, /api/auth/login, /api/auth/sesion,
/api/auth/logout, /api/estado, /api/cuenta, /api/movimientos y /api/transferencias.
Las operaciones de escritura conservan comprobaciones de origen, sesion y CSRF.
/api/salud identifica esta entrega como 3.4-navidad-saldo.

ProveedorLocal es el proveedor predeterminado. NDR_PROVIDER_CLASS permite usar
una implementacion explicita del contrato ProveedorFinanciero; si esa clase
no carga, las operaciones quedan bloqueadas y no se cambia de proveedor de
forma silenciosa. No mezcles almacenes locales con una integracion externa.

Para compilar desde fuentes, instala JDK 17+ y ejecuta compilar.bat o
sh compilar.sh. No se necesitan bibliotecas Java externas. El proyecto incluye
las fuentes y el JAR preparado; no necesitas Python para utilizar la aplicacion.

## Pruebas de desarrollo

- python3 tests/backend_smoke.py: API, acceso, saldos, operaciones y persistencia.
- python3 tests/frontend_smoke.py: interfaz con respuestas API controladas.
- python3 tests/wallet_e2e.py: Chromium contra el JAR y el servidor Java reales.

Las pruebas de navegador requieren Python, Playwright y Chromium; se puede
seleccionar el navegador con NDR_BROWSER_PATH. Usan perfiles temporales y no
deben modificar cuentas personales. Los lanzadores de Windows requieren una
comprobacion en Windows; las pruebas automatizadas se ejecutan en Linux.

El servidor esta pensado para uso local, no para exponerlo directamente en
Internet. Los datos de contacto son declarados por el usuario; no se realiza
verificacion OTP. Conserva los datos de cuenta en una ubicacion privada.
