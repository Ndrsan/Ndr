"use strict";
const $ = (id) => document.getElementById(id);
let csrf = null;
let usuario = null;
let bancario = false;
let envioPendiente = null;
let envioPreparado = null;
let modoCuenta = "local";
let saldoActual = null;
let saldoOculto = false;
let textoSaldo = "Consultando…";
let generacionSesion = 0;
const preferenciasSaldo = new Map();

function claveSaldo() { return "ndr:saldo-oculto:" + (usuario?.id || usuario?.correo || ""); }
function cargarPreferenciaSaldo() {
  const clave = claveSaldo();
  try { saldoOculto = localStorage.getItem(clave) === "1"; }
  catch { saldoOculto = preferenciasSaldo.get(clave) || false; }
}
function pintarSaldo() {
  $("balanceValue").textContent = saldoActual === null ? textoSaldo : (saldoOculto ? "••••••" : saldoActual);
  $("toggleBalance").disabled = saldoActual === null;
  $("toggleBalance").setAttribute("aria-pressed", String(saldoOculto));
  $("toggleBalance").setAttribute("aria-label", saldoOculto ? "Mostrar saldo" : "Ocultar saldo");
  $("balanceToggleText").textContent = saldoOculto ? "Mostrar" : "Ocultar";
  $("balanceEye").toggleAttribute("hidden", saldoOculto);
  $("balanceEyeOff").toggleAttribute("hidden", !saldoOculto);
}
function limpiarSaldo(texto = "Consultando…") {
  saldoActual = null; textoSaldo = texto; pintarSaldo();
}
$("toggleBalance").addEventListener("click", () => {
  if (saldoActual === null || !usuario) return;
  saldoOculto = !saldoOculto;
  preferenciasSaldo.set(claveSaldo(), saldoOculto);
  try { localStorage.setItem(claveSaldo(), saldoOculto ? "1" : "0"); } catch { }
  pintarSaldo();
});
function moneda(valor, codigo = "PEN") {
  return new Intl.NumberFormat("es-PE", {style:"currency", currency:codigo}).format(Number(valor));
}
function fechaVisible(valor) {
  const fecha = new Date(valor);
  return Number.isNaN(fecha.getTime()) ? "—" : fecha.toLocaleString("es-PE", {timeZone:"America/Lima"});
}

async function api(ruta, opciones = {}) {
  let respuesta;
  try {
    respuesta = await fetch(ruta, {credentials:"same-origin", cache:"no-store", ...opciones});
  } catch {
    throw new Error("No se pudo conectar con NDR. Comprueba que iniciar.bat sigue abierto y vuelve a intentarlo.");
  }
  let datos;
  try { datos = await respuesta.json(); }
  catch { throw new Error("No se pudo interpretar la respuesta del servidor."); }
  if (!respuesta.ok || !datos.ok) {
    const error = new Error(datos.mensaje || "No fue posible completar la solicitud.");
    error.status = respuesta.status;
    throw error;
  }
  return datos;
}
function post(ruta, cuerpo, sesion = false) {
  const headers = {"Content-Type":"application/json", "X-NDR-Request":"1"};
  if (sesion) headers["X-NDR-CSRF"] = csrf || "";
  return api(ruta, {method:"POST", headers, body:JSON.stringify(cuerpo)});
}
function estadoMensaje(id, texto, ok = false) {
  const e = $(id);
  e.textContent = texto;
  e.classList.toggle("good", ok);
}
function formatoCci(cci) {
  if (!cci) return "—";
  return String(cci).replace(/\D/g, "").replace(/(.{4})/g, "$1 ").trim();
}
function aplicarDatosUsuario() {
  if (!usuario) return;
  const nombre = usuario.nombre || "bienvenido";
  $("firstName").textContent = nombre.split(/\s+/)[0];
  $("profileName").textContent = nombre;
  $("profileEmail").textContent = usuario.correo || "—";
  $("profilePhone").textContent = usuario.telefono || "—";
  $("profileCciFull").textContent = formatoCci(usuario.cci);
  $("profileCciPreview").textContent = formatoCci(usuario.cci);
  $("transferOwnCci").textContent = formatoCci(usuario.cci);
}
function modoRegistro(registro) {
  $("loginForm").hidden = registro;
  $("registerForm").hidden = !registro;
  $("showLogin").classList.toggle("active", !registro);
  $("showRegister").classList.toggle("active", registro);
  $("showLogin").setAttribute("aria-pressed", String(!registro));
  $("showRegister").setAttribute("aria-pressed", String(registro));
  $("authTitle").textContent = registro ? "Crear tu cuenta" : "Iniciar sesión";
  $("authSubtitle").textContent = registro ? "Crea tu perfil de acceso con correo, celular y un CCI propio." : "Ingresa con tu correo o número de celular.";
  estadoMensaje("authMessage", "");
}
$("showLogin").addEventListener("click", () => modoRegistro(false));
$("showRegister").addEventListener("click", () => modoRegistro(true));

async function entrar(datos) {
  if (!datos?.csrf || !datos?.usuario?.nombre) throw new Error("Respuesta de sesión incompleta. Intenta entrar de nuevo.");
  generacionSesion++;
  csrf = datos.csrf;
  usuario = datos.usuario;
  cargarPreferenciaSaldo();
  limpiarSaldo();
  aplicarDatosUsuario();
  $("bankApp").hidden = false;
  $("authView").hidden = true;
  mostrarVista("inicio", true);
  await consultarBanco();
}
function salirDeVista() {
  generacionSesion++;
  csrf = null; usuario = null; bancario = false; envioPendiente = null; envioPreparado = null;
  $("bankApp").hidden = true;
  $("authView").hidden = false;
  $("loginForm").reset(); $("registerForm").reset();
  modoRegistro(false);
  $("sessionMessage").hidden = true;
  saldoOculto = false; modoCuenta = "local";
  limpiarSaldo("—");
  $("balanceNote").textContent = "";
  $("transferForm").reset();
  $("transferResult").hidden = true;
  $("transferSubmit").disabled = true;
  $("confirmDialog").close();
  for (const id of ["firstName", "profileName", "profileEmail", "profilePhone", "profileCciFull", "profileCciPreview", "transferOwnCci", "bankAccount", "bankProvider", "profileBank", "confirmBeneficiary", "confirmCci", "confirmAmount", "resultBeneficiary", "resultCci", "resultAmount", "resultDate", "resultOperation", "resultReference", "resultState", "transferResultText"]) $(id).textContent = "—";
  estadoMensaje("transferMessage", ""); estadoMensaje("movementMessage", "");
  vacio("Todavía no hay movimientos.");
}
$("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault(); $("loginSubmit").disabled = true;
  estadoMensaje("authMessage", "Verificando tus credenciales…");
  try {
    const d = await post("/api/auth/login", {identificador:$("loginId").value, password:$("loginPassword").value});
    $("loginPassword").value = "";
    await entrar(d);
    $("sessionMessage").hidden = true;
  } catch (err) { estadoMensaje("authMessage", err.message); }
  finally { $("loginSubmit").disabled = false; }
});
$("registerForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  if ($("registerPassword").value !== $("registerRepeat").value)
    return estadoMensaje("authMessage", "Las contraseñas no coinciden.");
  $("registerSubmit").disabled = true; estadoMensaje("authMessage", "Registrando tu perfil…");
  try {
    const d = await post("/api/auth/registro", {
      nombre:$("registerName").value, correo:$("registerEmail").value,
      telefono:$("registerPhone").value, password:$("registerPassword").value
    });
    const correo = $("registerEmail").value.trim();
    $("registerForm").reset();
    modoRegistro(false);
    $("loginId").value = correo;
    $("loginPassword").value = "";
    estadoMensaje("authMessage", d.mensaje || "Cuenta creada. Ahora inicia sesión.", true);
  } catch (err) { estadoMensaje("authMessage", err.message); }
  finally { $("registerSubmit").disabled = false; }
});
async function cerrarSesion() {
  try { await post("/api/auth/logout", {}, true); }
  catch { }
  salirDeVista();
}
$("logoutButton").addEventListener("click", cerrarSesion);
$("profileLogout").addEventListener("click", cerrarSesion);

function animarPantalla(pantalla) {
  pantalla.classList.remove("screen-animate");
  void pantalla.offsetWidth;
  pantalla.classList.add("screen-animate");
}
function mostrarVista(vista, instantanea = false) {
  if (!usuario) return;
  document.querySelectorAll(".screen").forEach(e => {
    const activa = e.id === vista;
    e.classList.toggle("active", activa);
    if (activa) animarPantalla(e);
  });
  const movimientoReducido = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  window.scrollTo({top:0, behavior:instantanea || movimientoReducido ? "instant" : "smooth"});
  if (vista === "historial") cargarMovimientos();
}
document.querySelectorAll("[data-view]").forEach(b => b.addEventListener("click", () => mostrarVista(b.dataset.view)));
function deshabilitarBanco(nombre = "Cuenta no disponible", detalle = "Vuelve a actualizar tu cuenta.", mostrarAviso = true) {
  bancario = false;
  $("connectionPill").classList.remove("connected");
  $("connectionText").textContent = nombre;
  $("integrationStatus").textContent = nombre;
  $("transferSubmit").disabled = true;
  $("bankNotice").hidden = !mostrarAviso;
  $("bankNoticeTitle").textContent = nombre;
  $("bankNoticeText").textContent = detalle;
  $("bankProvider").textContent = "—";
  $("bankAccount").textContent = usuario?.cci ? formatoCci(usuario.cci) : "—";
  limpiarSaldo(mostrarAviso ? "No disponible" : "Consultando…");
  $("balanceNote").textContent = detalle;
  $("profileBank").textContent = nombre;
}
async function consultarBanco() {
  const generacion = generacionSesion;
  deshabilitarBanco("Consultando cuenta…", "Actualizando tu información", false);
  try {
    const d = await api("/api/estado");
    if (generacion !== generacionSesion || !usuario) return;
    modoCuenta = d.modo || "externo";
    if (!d.conectado) return deshabilitarBanco("Cuenta no disponible", "El servicio de cuenta no está conectado. Vuelve a intentarlo más tarde.");
    if (!d.autenticado) {
      deshabilitarBanco("Validación pendiente", "Tu proveedor debe autorizar el acceso a la cuenta.");
      $("bankProvider").textContent = d.proveedor || "—";
      return;
    }
    bancario = true;
    $("bankProvider").textContent = d.proveedor || "NDR";
    $("connectionPill").classList.add("connected");
    $("connectionText").textContent = modoCuenta === "local" ? "Cuenta activa" : "Banco verificado";
    $("integrationStatus").textContent = modoCuenta === "local" ? "Cuenta NDR activa" : "Entidad verificada";
    $("bankNotice").hidden = true;
    $("profileBank").textContent = modoCuenta === "local" ? "Cuenta NDR activa" : "Validada por la entidad";
    await cargarCuenta();
    if (generacion === generacionSesion) $("transferSubmit").disabled = !bancario || Boolean(envioPendiente);
  } catch (err) {
    if (generacion !== generacionSesion) return;
    if (err.status === 401) return salirDeVista();
    deshabilitarBanco("Cuenta no disponible", err.message);
  }
}
async function cargarCuenta() {
  if (!bancario) return;
  const generacion = generacionSesion;
  limpiarSaldo();
  try {
    const {cuenta} = await api("/api/cuenta");
    if (generacion !== generacionSesion || !usuario) return;
    const saldo = Number(cuenta.saldo);
    if (cuenta.saldo == null || String(cuenta.saldo).trim() === "" || !Number.isFinite(saldo)) throw new Error("No se pudo consultar el saldo. Actualiza tu cuenta.");
    const numero = cuenta.numero || usuario.cci || "—";
    $("bankAccount").textContent = /^[0-9]{20}$/.test(String(numero)) ? formatoCci(numero) : numero;
    saldoActual = moneda(saldo, cuenta.moneda || "PEN");
    pintarSaldo();
    $("balanceNote").textContent = cuenta.actualizadoEn ? "Actualizado: " + fechaVisible(cuenta.actualizadoEn) : "Cuenta actualizada";
  } catch (err) {
    if (generacion !== generacionSesion) return;
    if (err.status === 401) return salirDeVista();
    deshabilitarBanco("Cuenta no disponible", err.message);
  }
}
$("refreshAccount").addEventListener("click", consultarBanco);
function celda(tr, valor) { const td = document.createElement("td"); td.textContent = valor; tr.append(td); }
function vacio(texto) {
  const tr = document.createElement("tr"); const td = document.createElement("td");
  td.colSpan = 4; td.className = "empty"; td.textContent = texto; tr.append(td);
  $("movementRows").replaceChildren(tr);
}
async function cargarMovimientos() {
  if (!bancario) { vacio("Actualiza tu cuenta para consultar sus movimientos."); return; }
  const generacion = generacionSesion;
  vacio("Consultando operaciones…");
  try {
    const {movimientos} = await api("/api/movimientos");
    if (generacion !== generacionSesion || !usuario) return;
    $("movementRows").replaceChildren();
    if (!movimientos.length) return vacio("Todavía no tienes transferencias registradas.");
    for (const mov of movimientos) {
      const tr = document.createElement("tr");
      for (const v of [mov.fecha ? fechaVisible(mov.fecha) : "—", mov.descripcion || "Transferencia", mov.monto ? moneda(mov.monto, mov.moneda || "PEN") : "—", mov.estado || "Por consultar"]) celda(tr, v);
      $("movementRows").append(tr);
    }
    estadoMensaje("movementMessage", "");
  } catch (err) {
    if (generacion !== generacionSesion) return;
    if (err.status === 401) return salirDeVista();
    vacio("No se pudo consultar el historial."); estadoMensaje("movementMessage", err.message);
  }
}
$("refreshMovements").addEventListener("click", cargarMovimientos);
function montoValido(t) {
  if (!/^\d{1,6}(\.\d{1,2})?$/.test(t)) return false;
  const n = Number(t); return Number.isFinite(n) && n > 0 && n <= 50000;
}
$("transferForm").addEventListener("submit", (e) => {
  e.preventDefault(); $("transferResult").hidden = true;
  if (!bancario) return estadoMensaje("transferMessage", "Actualiza tu cuenta antes de transferir.");
  if (envioPendiente) return estadoMensaje("transferMessage", "Hay una operación pendiente de verificar. Revisa el historial antes de volver a enviarla.");
  const datos = {beneficiario:$("beneficiary").value.trim(), cci:$("cci").value.trim(), monto:$("transferAmount").value.trim().replace(",", "."), concepto:$("concept").value.trim()};
  if (!/^[0-9]{20}$/.test(datos.cci)) return estadoMensaje("transferMessage", "El CCI debe tener 20 dígitos.");
  if (datos.beneficiario.length < 3 || datos.beneficiario.length > 100) return estadoMensaje("transferMessage", "Revisa el beneficiario.");
  if (!montoValido(datos.monto)) return estadoMensaje("transferMessage", "Introduce un monto de S/ 0.01 a S/ 50,000.00.");
  if (datos.concepto.length > 140) return estadoMensaje("transferMessage", "El concepto admite hasta 140 caracteres.");
  if (datos.cci === usuario?.cci) return estadoMensaje("transferMessage", "Elige un CCI distinto al de tu cuenta.");
  envioPreparado = {...datos, claveIdempotencia:crypto.randomUUID()};
  $("confirmBeneficiary").textContent = datos.beneficiario;
  $("confirmCci").textContent = formatoCci(datos.cci);
  $("confirmAmount").textContent = "S/ " + Number(datos.monto).toFixed(2);
  $("confirmDialog").showModal();
});
$("cancelTransfer").addEventListener("click", () => { $("confirmDialog").close(); envioPreparado = null; });
$("confirmDialog").addEventListener("close", () => { if (!envioPendiente) envioPreparado = null; });
$("confirmTransfer").addEventListener("click", async () => {
  if (!envioPreparado || !bancario || envioPendiente) return;
  const generacion = generacionSesion;
  envioPendiente = envioPreparado; envioPreparado = null;
  const operacion = envioPendiente;
  $("confirmDialog").close(); $("transferSubmit").disabled = true;
  $("confirmTransfer").disabled = true;
  estadoMensaje("transferMessage", "Procesando tu transferencia…");
  try {
    const {transferencia} = await post("/api/transferencias", operacion, true);
    if (generacion !== generacionSesion || !usuario) return;
    if (!transferencia?.id || !transferencia?.estado) throw new Error("No se pudo confirmar el estado de la operación. Consulta el historial.");
    $("transferResultTitle").textContent = modoCuenta === "local" ? "Transferencia registrada" : "Respuesta de la entidad";
    $("transferResultText").textContent = modoCuenta === "local" ? "Transferencia registrada. Revisa los detalles de la operación." : "La entidad respondió a la solicitud. Revisa el estado informado.";
    $("resultBeneficiary").textContent = operacion.beneficiario;
    $("resultCci").textContent = formatoCci(operacion.cci);
    $("resultAmount").textContent = moneda(operacion.monto);
    $("resultDate").textContent = fechaVisible(transferencia.fecha || new Date().toISOString());
    $("resultOperation").textContent = transferencia.id;
    $("resultReference").textContent = transferencia.referencia || "—";
    $("resultState").textContent = transferencia.estado;
    $("transferResult").hidden = false;
    estadoMensaje("transferMessage", "Operación registrada correctamente.", true);
    envioPendiente = null; $("transferForm").reset();
    await cargarCuenta();
  } catch (err) {
    if (generacion !== generacionSesion) return;
    if (err.status === 401) return salirDeVista();
    estadoMensaje("transferMessage", err.message + (err.status >= 400 && err.status < 500 ? "" : " Verifica el historial antes de volver a enviar la operación."));
    if (err.status >= 400 && err.status < 500) envioPendiente = null;
  } finally {
    if (generacion === generacionSesion) $("transferSubmit").disabled = !bancario || Boolean(envioPendiente);
    $("confirmTransfer").disabled = false;
  }
});

function activarTapAnimations() {
  document.addEventListener("click", (event) => {
    const boton = event.target.closest(".pressable, .tile, .btn, .auth-tab, .logout");
    if (!boton) return;
    boton.classList.remove("tap-pop");
    void boton.offsetWidth;
    boton.classList.add("tap-pop");
  });
}

(async function iniciar() {
  activarTapAnimations();
  const generacion = generacionSesion;
  try {
    const d = await api("/api/auth/sesion");
    if (generacion === generacionSesion) await entrar(d);
  } catch { if (generacion === generacionSesion) salirDeVista(); }
})();

window.addEventListener("unhandledrejection", () => {
  if (!usuario) estadoMensaje("authMessage", "Hubo un error inesperado. La página permanece abierta; actualiza e inténtalo de nuevo.");
});
