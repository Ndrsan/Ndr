# Novedades NDR 3.4

- Saldo inicial de S/ 200.00 por cuenta, persistente y mostrado en Mi cuenta.
- Boton para mostrar u ocultar el saldo, con preferencia por usuario.
- Transferencias con revision previa, descuento del saldo e historial.
- Acreditacion al destinatario cuando su CCI pertenece a otro perfil NDR local.
- Validacion de saldo suficiente, centimos y claves de operacion para evitar
  descuentos duplicados. Los movimientos se conservan al reiniciar.
- Se mantienen las correcciones de formularios ocultos y contrasena exacta.
- Fuentes y target/banca-movil.jar actualizados, compilados para Java 17+.

Cierra el servidor anterior antes de ejecutar iniciar.bat de esta entrega.
El lanzador comprueba la version 3.4-navidad-saldo para detectar servidores viejos.
Conserva todo el directorio de datos de tu instalacion anterior.

Las caracteristicas y el almacen local se describen en LEEME_NDR_BANCA_REAL.md.
El ZIP no incluye perfiles, saldos ni operaciones de las pruebas.
