@echo off
setlocal
cd /d "%~dp0"
title Instalar servidor Minecraft Java y Bedrock
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar.ps1" %*
set "RESULTADO=%ERRORLEVEL%"
echo.
pause
exit /b %RESULTADO%
