# Servidor Minecraft Java 1.21.11 + Bedrock

Servidor para alojar en tu propio ordenador con jugabilidad survival, sin mods
de juego. Usa Paper 1.21.11 y únicamente Geyser, Floodgate y ViaVersion para unir
las dos ediciones. Los jugadores no necesitan instalar mods. Paper no es el
servidor oficial sin modificar de Mojang: conserva el juego habitual con sus
optimizaciones y diferencias propias.

Java se fija en **1.21.11**. Bedrock usa otra numeración: necesita una versión
compatible con el Geyser instalado. El instalador obtiene los componentes de sus
fuentes oficiales y comprueba sus hashes SHA-256 antes de guardarlos.

## Preparar tu PC Windows

1. Instala **Java 21 de 64 bits**. Puedes obtenerlo de Eclipse Temurin:
   https://adoptium.net/temurin/releases/?version=21
   Si Java 17 ya ejecuta otra aplicación, no basta para este servidor.
2. Extrae esta carpeta completa, por ejemplo en `C:\Minecraft`. No ejecutes
   los archivos directamente dentro del ZIP.
3. Haz doble clic en **Instalar.bat**. Necesita Internet para descargar Paper
   de la versión exacta, Geyser, Floodgate y ViaVersion.
4. Haz doble clic en **Iniciar.bat**. En el primer arranque se muestra el enlace
   de la EULA de Minecraft y se pide que tú la aceptes expresamente. Si no la
   aceptas, el servidor no se inicia. No se ha aceptado en esta entrega.
5. Espera a que la consola indique `Done`. Déjala abierta mientras jueguen.
   Para apagarlo, escribe **stop** en esa consola y espera a que termine.

No se incluyen los JARs de terceros dentro del ZIP: el instalador los obtiene
directamente. Tampoco hay un mundo creado ni jugadores con permisos de operador.

## Entrar desde casa

| Dispositivo | Dirección | Puerto |
|---|---|---|
| Java 1.21.11 en el mismo PC | `localhost` | `25565` |
| Java en otro PC de la misma red | IP local del PC servidor | `25565` |
| Bedrock en la misma red | IP local del PC servidor | `19132` |

En Windows, `ipconfig` muestra la dirección IPv4 del adaptador que utilizas;
normalmente empieza por `192.168.` o `10.`. No pongas `localhost` desde otro
dispositivo. Usa una cuenta válida de Minecraft Java o de Microsoft/Xbox para
Bedrock. Floodgate permite entrar con la cuenta Bedrock sin comprar también Java.

Android, iOS y Bedrock para PC permiten añadir un servidor. Algunas consolas no
incluyen esa opción directamente y necesitan una configuración adicional.

## Que entren por Internet

El PC debe seguir encendido, con el servidor abierto y conexión a Internet.
No se utiliza Aternos ni otro alojamiento externo.

1. Reserva en tu router la IP local del PC servidor para que no cambie.
2. Permite el servidor en el firewall de Windows. El archivo
   `Configurar-Firewall.ps1` es opcional: requiere administrador y confirmación,
   y crea reglas para estos puertos en redes privadas/dominio.
   Desde esa carpeta, abre PowerShell como administrador y ejecuta:

   ```powershell
   powershell -NoProfile -ExecutionPolicy Bypass -File .\Configurar-Firewall.ps1
   ```

   El permiso de ejecución de ese comando solo afecta ese proceso; el script
   pide confirmación antes de crear las reglas.
3. Configura el reenvío de puertos de tu router hacia esa IP local:

| Uso | Puerto externo e interno | Protocolo |
|---|---|---|
| Minecraft Java | `25565` | TCP |
| Minecraft Bedrock / Geyser actual | `19132` | TCP y UDP |

El Geyser actual utiliza NetherNet con señalización: por eso se contempla TCP
además de UDP en el puerto Bedrock. No cambies `server-ip=` para poner tu IP
pública: esa propiedad debe permanecer vacía.

Tus amigos de Java usarán **tu IP pública:25565**. Los de Bedrock usarán tu IP
pública y el puerto **19132**. Prueba desde otra conexión, por ejemplo un móvil
con datos; algunos routers no permiten probar la IP pública desde la misma Wi-Fi.

Si tu operador usa **CGNAT**, abrir los puertos del router no basta. Pídele una
IP pública o utiliza por tu cuenta un túnel que soporte los protocolos
necesarios. Un script no puede eliminar el CGNAT ni modificar un router al que
no tiene acceso. La conectividad desde Internet depende de esa configuración.

## Ajustes y mantenimiento

El arranque reserva 1 GB inicial y un máximo de 3 GB. Puedes cambiar el máximo
iniciando desde una terminal de esa carpeta, por ejemplo:

```bat
Iniciar.bat -RamMaxima 2G
```

Deja memoria suficiente para Windows y para el cliente si juegas en el mismo PC. La configuración inicial limita el
servidor a diez jugadores, con distancias moderadas; puedes editar
`server.properties` con el servidor apagado.

Desde la consola, puedes usar `op TuNombreJava` para darte permisos. Los nombres
Bedrock pueden llevar el prefijo configurado por Floodgate: usa el nombre exacto
que muestra el servidor. Puedes activar la lista permitida con `whitelist on`
y añadir personas con `whitelist add Nombre`.

Se mantiene `online-mode=true`: no se desactiva la autenticación Java.
`enforce-secure-profile=false` permite la compatibilidad con los perfiles Bedrock.
RCON y la consulta remota se dejan desactivados.

Antes de actualizar, apaga el servidor con `stop` y respalda toda la carpeta,
en especial los mundos, `server.properties`, la lista permitida y `plugins`.
El instalador conserva los mundos y las configuraciones existentes. Si cambias
configuración manualmente, no la reemplaza silenciosamente. Mantén juntos
Geyser, Floodgate y ViaVersion para la compatibilidad entre versiones.

## Archivos de esta entrega

- `Instalar.bat` y `Instalar.ps1`: descarga verificada y configuración inicial.
- `Iniciar.bat` y `Iniciar.ps1`: comprueban Java, memoria, archivos y EULA.
- `Configurar-Firewall.ps1`: reglas locales opcionales, nunca cambios del router.
- `LEEME.md`: instrucciones de uso y conexión.

La instalación creará el JAR del servidor, `plugins` y sus configuraciones.
Minecraft generará sus mundos y otros archivos de funcionamiento al arrancar.
No borres esos archivos por considerarlos temporales.

## Comprobación realizada

Se revisaron las rutas y esquemas en documentación y fuentes oficiales de Paper,
Geyser, Floodgate y ViaVersion. Las pruebas del instalador usan PowerShell y un
servicio HTTP local con archivos controlados: comprueban selección de versión,
hashes, configuración, conservación de mundos y rechazo de descargas alteradas.
Las APIs de descarga de Minecraft están restringidas desde el entorno donde se
preparó este ZIP. La descarga real se realiza al ejecutar el instalador en tu PC.
No se ha afirmado que este servidor esté ya en línea ni se aceptó la EULA por ti.
