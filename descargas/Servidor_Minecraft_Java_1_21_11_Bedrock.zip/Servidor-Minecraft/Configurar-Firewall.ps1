﻿# Ejecutar manualmente como administrador. No cambia el router ni abre servicios de administracion.
[CmdletBinding()]
param()
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
try {
    $identidad = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identidad)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Abre PowerShell como administrador para configurar estas tres reglas.'
    }
    Write-Host 'Se permitiran TCP 25565 (Java), TCP 19132 y UDP 19132 (Bedrock) solo en redes privadas o de dominio.'
    if ((Read-Host 'Escribe ABRIR para continuar') -cne 'ABRIR') { Write-Host 'Cancelado. No se cambio el firewall.'; exit 0 }
    $reglas = @(
        @{ Name = 'NDR-Minecraft-Java-TCP'; DisplayName = 'NDR Minecraft Java TCP 25565'; Protocol = 'TCP'; LocalPort = 25565 },
        @{ Name = 'NDR-Minecraft-Bedrock-UDP'; DisplayName = 'NDR Minecraft Bedrock UDP 19132'; Protocol = 'UDP'; LocalPort = 19132 },
        @{ Name = 'NDR-Minecraft-Bedrock-TCP'; DisplayName = 'NDR Minecraft Bedrock TCP 19132'; Protocol = 'TCP'; LocalPort = 19132 }
    )
    foreach ($regla in $reglas) {
        if (-not (Get-NetFirewallRule -Name $regla.Name -ErrorAction SilentlyContinue)) {
            New-NetFirewallRule @regla -Direction Inbound -Action Allow -Profile Private,Domain | Out-Null
        }
    }
    Write-Host 'Reglas configuradas. Para acceso por Internet debes configurar tambien el router.'
} catch {
    Write-Error $_.Exception.Message -ErrorAction Continue
    exit 1
}
