@echo off
setlocal
cd /d "%~dp0"
title Minecraft Java 1.21.11 y Bedrock - NO CERRAR
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Iniciar.ps1" %*
set "RESULTADO=%ERRORLEVEL%"
echo.
echo Servidor detenido. Para guardar correctamente durante el juego utiliza stop.
pause
exit /b %RESULTADO%
