﻿[CmdletBinding()]
param(
    [string]$Directorio = $PSScriptRoot,
    [string]$RamMaxima = $env:RAM_MAX,
    [switch]$Comprobar
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
try {
    $Directorio = [IO.Path]::GetFullPath($Directorio)
    if (-not $RamMaxima) { $RamMaxima = '3G' }
    if ($RamMaxima -notmatch '^[1-9][0-9]*[MG]$') { throw 'RAM_MAX debe ser un valor como 3G o 4096M.' }
    $java = Get-Command java -ErrorAction SilentlyContinue
    if ($null -eq $java) { throw 'Instala Java 21 de 64 bits: https://adoptium.net/temurin/releases/?version=21' }
    $preferenciaAnterior = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $detalles = (& $java.Source '-XshowSettings:properties' '-version' 2>&1 | Out-String)
        $salidaJava = $LASTEXITCODE
    } finally { $ErrorActionPreference = $preferenciaAnterior }
    if ($salidaJava -ne 0 -or $detalles -notmatch 'version\s+"(?<mayor>[0-9]+)') { throw 'No se pudo comprobar Java.' }
    if ([int]$Matches['mayor'] -lt 21 -or $detalles -notmatch 'sun\.arch\.data\.model\s*=\s*64') { throw 'Necesitas Java 21 o superior de 64 bits.' }
    foreach ($nombre in @('servidor.jar', 'plugins/Geyser-Spigot.jar', 'plugins/floodgate-spigot.jar', 'plugins/ViaVersion.jar', 'server.properties', 'plugins/Geyser-Spigot/config.yml')) {
        if (-not (Test-Path -LiteralPath (Join-Path $Directorio $nombre) -PathType Leaf)) { throw ('Falta ' + $nombre + '. Ejecuta Instalar.bat primero.') }
    }
    $eula = Join-Path $Directorio 'eula.txt'
    $aceptada = (Test-Path -LiteralPath $eula) -and ((Get-Content -LiteralPath $eula -Raw) -match '(?m)^\s*eula\s*=\s*true\s*$')
    if ($Comprobar) {
        [pscustomobject]@{ java = $java.Source; javaMinimo = 21; ramMaxima = $RamMaxima; eulaAceptada = [bool]$aceptada; directorio = $Directorio } | ConvertTo-Json
        exit 0
    }
    if (-not $aceptada) {
        Write-Host 'Antes de ejecutar Minecraft debes leer su EULA: https://aka.ms/MinecraftEULA'
        $respuesta = Read-Host 'Si estas de acuerdo, escribe ACEPTO. Cualquier otra respuesta cancela'
        if ($respuesta -cne 'ACEPTO') { Write-Host 'Cancelado: no se acepto la EULA y no se inicio el servidor.'; exit 1 }
        [IO.File]::WriteAllText($eula, "# Aceptada expresamente por el usuario local.`neula=true`n", [Text.UTF8Encoding]::new($false))
    }
    Push-Location $Directorio
    try {
        Write-Host 'Iniciando Minecraft. Para guardar y cerrar, escribe stop en esta ventana.'
        & $java.Source '-Xms1G' ('-Xmx' + $RamMaxima) '-jar' 'servidor.jar' 'nogui'
        $resultado = $LASTEXITCODE
    } finally { Pop-Location }
    exit $resultado
} catch {
    Write-Error ('No se pudo iniciar: ' + $_.Exception.Message) -ErrorAction Continue
    exit 1
}
