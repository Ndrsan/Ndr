﻿[CmdletBinding()]
param(
    [string]$Directorio = $PSScriptRoot,
    [string]$PaperApiBase = 'https://fill.papermc.io',
    [string]$GeyserApiBase = 'https://download.geysermc.org',
    [string]$GitHubApiBase = 'https://api.github.com',
    [switch]$SoloPlan
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
$MinecraftVersion = '1.21.11'
$Agente = 'NDR-Minecraft-Setup/1.0 (https://github.com/Ndrsan/Ndr)'

function Propiedad($Objeto, [string]$Nombre) {
    if ($null -eq $Objeto) { return $null }
    $propiedad = $Objeto.PSObject.Properties[$Nombre]
    if ($null -eq $propiedad) { return $null }
    return $propiedad.Value
}

function Url-Segura([string]$Texto) {
    $uri = $null
    if (-not [Uri]::TryCreate($Texto, [UriKind]::Absolute, [ref]$uri)) { throw 'Una URL de descarga no es valida.' }
    $local = @('localhost', '127.0.0.1', '::1', '[::1]') -contains $uri.DnsSafeHost
    if (($uri.Scheme -ne 'https' -and -not ($uri.Scheme -eq 'http' -and $local)) -or $uri.UserInfo -or $uri.Fragment) {
        throw 'Las descargas requieren HTTPS. HTTP solo se permite en pruebas locales.'
    }
    return $uri.AbsoluteUri
}

function Json-Oficial([string]$Url) {
    $segura = Url-Segura $Url
    return Invoke-RestMethod -Uri $segura -UserAgent $Agente -Headers @{ Accept = 'application/json' } -TimeoutSec 30
}

function Hash-Esperado([string]$Hash) {
    if ($Hash -notmatch '^[a-fA-F0-9]{64}$') { throw 'La fuente oficial no publico un SHA256 valido. No se instalara ese archivo.' }
    return $Hash.ToLowerInvariant()
}

function Java-21 {
    $java = Get-Command java -ErrorAction SilentlyContinue
    if ($null -eq $java) { throw 'Instala Java 21 de 64 bits: https://adoptium.net/temurin/releases/?version=21' }
    # Windows PowerShell 5 trata stderr nativo como registros de error, incluso si Java sale con 0.
    $preferenciaAnterior = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $detalles = (& $java.Source '-XshowSettings:properties' '-version' 2>&1 | Out-String)
        $salidaJava = $LASTEXITCODE
    } finally { $ErrorActionPreference = $preferenciaAnterior }
    if ($salidaJava -ne 0 -or $detalles -notmatch 'version\s+"(?<mayor>[0-9]+)') { throw 'No se pudo comprobar la version de Java.' }
    $mayor = [int]$Matches['mayor']
    if ($mayor -lt 21) { throw 'Minecraft 1.21.11 necesita Java 21 o superior. Java 17 no basta.' }
    if ($detalles -notmatch 'sun\.arch\.data\.model\s*=\s*64') { throw 'Se necesita Java de 64 bits.' }
    return $java.Source
}

function Componente([string]$Nombre, [string]$Destino, [string]$Url, [string]$Hash, [string]$Version) {
    return [pscustomobject]@{ nombre = $Nombre; destino = $Destino; url = (Url-Segura $Url); sha256 = (Hash-Esperado $Hash); version = $Version }
}

function Plugin-Geyser([string]$Proyecto, [string]$Destino) {
    $meta = Json-Oficial ($GeyserApiBase.TrimEnd('/') + '/v2/projects/' + $Proyecto + '/versions/latest/builds/latest')
    $version = [string](Propiedad $meta 'version')
    $build = [string](Propiedad $meta 'build')
    if ($version -notmatch '^[0-9A-Za-z.+_-]+$' -or $build -notmatch '^[0-9]+$') { throw ('Metadata no valida para ' + $Proyecto) }
    $archivo = Propiedad (Propiedad $meta 'downloads') 'spigot'
    $hash = [string](Propiedad $archivo 'sha256')
    $url = $GeyserApiBase.TrimEnd('/') + '/v2/projects/' + $Proyecto + '/versions/' + [Uri]::EscapeDataString($version) + '/builds/' + $build + '/downloads/spigot'
    return Componente $Proyecto $Destino $url $hash ($version + ' build ' + $build)
}

function Hash-ViaVersion($Asset, $Assets) {
    $digest = [string](Propiedad $Asset 'digest')
    if ($digest -match '^sha256:([0-9a-fA-F]{64})$') { return $Matches[1].ToLowerInvariant() }
    $nombre = [string](Propiedad $Asset 'name')
    $posibles = @($Assets | Where-Object {
        $n = [string](Propiedad $_ 'name')
        $n -eq ($nombre + '.sha256') -or $n -eq ($nombre + '.sha256sum') -or $n -match '^(SHA256SUMS|sha256sums\.txt|checksums\.txt)$'
    })
    foreach ($assetHash in $posibles) {
        $url = Url-Segura ([string](Propiedad $assetHash 'browser_download_url'))
        $respuesta = Invoke-WebRequest -Uri $url -UseBasicParsing -UserAgent $Agente -TimeoutSec 30
        $contenido = [string]$respuesta.Content
        $nombreHash = [string](Propiedad $assetHash 'name')
        if (($nombreHash -eq ($nombre + '.sha256') -or $nombreHash -eq ($nombre + '.sha256sum')) -and $contenido.Trim() -match '^[0-9a-fA-F]{64}$') {
            return $contenido.Trim().ToLowerInvariant()
        }
        foreach ($linea in ($contenido -split '\r?\n')) {
            if ($linea -match ('^([0-9a-fA-F]{64})\s+\*?' + [Regex]::Escape($nombre) + '\s*$')) { return $Matches[1].ToLowerInvariant() }
        }
    }
    throw 'ViaVersion no publico un SHA256 verificable en esta version. Se cancela la instalacion.'
}

function Escribir-Utf8([string]$Ruta, [string]$Contenido) {
    [IO.File]::WriteAllText($Ruta, $Contenido, [Text.UTF8Encoding]::new($false))
}

function Cambiar-Yaml([string]$Contenido, [string]$Seccion, [string]$Clave, [string]$Valor) {
    $lineas = New-Object 'System.Collections.Generic.List[string]'
    foreach ($linea in ($Contenido -split '\r?\n')) { [void]$lineas.Add($linea) }
    $inicio = 0; $fin = $lineas.Count; $sangria = ''
    if ($Seccion) {
        $indice = -1
        for ($i = 0; $i -lt $lineas.Count; $i++) { if ($lineas[$i] -match ('^' + [Regex]::Escape($Seccion) + ':\s*(?:#.*)?$')) { $indice = $i; break } }
        if ($indice -lt 0) { [void]$lineas.Add($Seccion + ':'); $indice = $lineas.Count - 1 }
        $inicio = $indice + 1; $fin = $lineas.Count; $sangria = '  '
        for ($i = $inicio; $i -lt $lineas.Count; $i++) { if ($lineas[$i] -match '^[^\s#][^:]*:') { $fin = $i; break } }
    }
    $patron = '^' + $sangria + [Regex]::Escape($Clave) + ':.*$'
    for ($i = $inicio; $i -lt $fin; $i++) {
        if ($lineas[$i] -match $patron) { $lineas[$i] = $sangria + $Clave + ': ' + $Valor; return ($lineas -join "`n") }
    }
    $lineas.Insert($fin, $sangria + $Clave + ': ' + $Valor)
    return ($lineas -join "`n")
}

function Config-Geyser([string]$Jar, [string]$Version) {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [IO.Compression.ZipFile]::OpenRead($Jar)
    $plantilla = $null
    try {
        $entrada = $zip.GetEntry('config.yml')
        if ($null -ne $entrada) {
            $lector = New-Object IO.StreamReader($entrada.Open())
            try { $plantilla = $lector.ReadToEnd() } finally { $lector.Dispose() }
        }
    } finally { $zip.Dispose() }
    if (-not $plantilla) {
        # Configurate genera esta configuracion en Geyser 2.12.x; ya no incluye una plantilla.
        if ($Version -notmatch '^2\.12\.') { throw 'Este Geyser no incluye una plantilla compatible. Actualiza el instalador antes de continuar.' }
        return @'
config-version: 12
bedrock:
  address: 0.0.0.0
  port: 19132
  clone-remote-port: false
  transport: nethernet
  signaling:
    mode: builtin
java:
  auth-type: floodgate
advanced:
  floodgate-key-file: key.pem
'@
    }
    $plantilla = Cambiar-Yaml $plantilla 'bedrock' 'address' '0.0.0.0'
    $plantilla = Cambiar-Yaml $plantilla 'bedrock' 'port' '19132'
    $plantilla = Cambiar-Yaml $plantilla 'bedrock' 'clone-remote-port' 'false'
    if ($plantilla -match '(?m)^java:') {
        $plantilla = Cambiar-Yaml $plantilla 'java' 'auth-type' 'floodgate'
        $plantilla = Cambiar-Yaml $plantilla 'advanced' 'floodgate-key-file' 'key.pem'
    } elseif ($plantilla -match '(?m)^remote:') {
        $plantilla = Cambiar-Yaml $plantilla 'remote' 'address' '127.0.0.1'
        $plantilla = Cambiar-Yaml $plantilla 'remote' 'port' '25565'
        $plantilla = Cambiar-Yaml $plantilla 'remote' 'auth-type' 'floodgate'
        $plantilla = Cambiar-Yaml $plantilla '' 'floodgate-key-file' 'key.pem'
    } else { throw 'La plantilla de Geyser no contiene una configuracion de Java reconocible.' }
    return $plantilla
}

$temporal = $null
try {
    $Directorio = [IO.Path]::GetFullPath($Directorio)
    [void](Url-Segura $PaperApiBase); [void](Url-Segura $GeyserApiBase); [void](Url-Segura $GitHubApiBase)
    [void](Java-21)
    $respuestaPaper = Json-Oficial ($PaperApiBase.TrimEnd('/') + '/v3/projects/paper/versions/' + $MinecraftVersion + '/builds')
    $builds = @($respuestaPaper)
    $estables = @($builds | Where-Object { (Propiedad $_ 'channel') -eq 'STABLE' } | Sort-Object { [long](Propiedad $_ 'id') } -Descending)
    if ($estables.Count -eq 0) { throw ('No hay una compilacion STABLE de Paper ' + $MinecraftVersion + '. No se elegira otra version de Minecraft.') }
    $paper = $estables[0]
    $versionDeclarada = Propiedad $paper 'version'
    if ($null -ne $versionDeclarada) {
        if ($versionDeclarada -isnot [string]) { $versionDeclarada = Propiedad $versionDeclarada 'id' }
        if ($versionDeclarada -and $versionDeclarada -ne $MinecraftVersion) { throw 'Paper devolvio otra version de Minecraft. Instalacion cancelada.' }
    }
    $descarga = Propiedad (Propiedad $paper 'downloads') 'server:default'
    $componentes = @(
        (Componente 'Paper' 'servidor.jar' ([string](Propiedad $descarga 'url')) ([string](Propiedad (Propiedad $descarga 'checksums') 'sha256')) ($MinecraftVersion + ' build ' + [string](Propiedad $paper 'id'))),
        (Plugin-Geyser 'geyser' 'plugins/Geyser-Spigot.jar'),
        (Plugin-Geyser 'floodgate' 'plugins/floodgate-spigot.jar')
    )
    $release = Json-Oficial ($GitHubApiBase.TrimEnd('/') + '/repos/ViaVersion/ViaVersion/releases/latest')
    if ((Propiedad $release 'draft') -eq $true -or (Propiedad $release 'prerelease') -eq $true) { throw 'ViaVersion debe ser una version oficial estable.' }
    $assets = @(Propiedad $release 'assets')
    $jars = @($assets | Where-Object { ([string](Propiedad $_ 'name')) -match '^ViaVersion-[0-9][0-9A-Za-z.+_-]*\.jar$' })
    if ($jars.Count -ne 1) { throw 'No se encontro un unico JAR oficial de ViaVersion.' }
    $asset = $jars[0]
    $componentes += Componente 'ViaVersion' 'plugins/ViaVersion.jar' ([string](Propiedad $asset 'browser_download_url')) (Hash-ViaVersion $asset $assets) ([string](Propiedad $release 'tag_name'))
    if ($SoloPlan) {
        [pscustomobject]@{ minecraft = $MinecraftVersion; javaMinimo = 21; componentes = $componentes } | ConvertTo-Json -Depth 6
        exit 0
    }
    [void](New-Item -ItemType Directory -Path $Directorio -Force)
    $temporal = Join-Path $Directorio ('.instalacion-' + [Guid]::NewGuid().ToString('N'))
    [void](New-Item -ItemType Directory -Path $temporal)
    foreach ($componente in $componentes) {
        $archivoTemporal = Join-Path $temporal ([IO.Path]::GetFileName($componente.destino))
        $actual = Join-Path $Directorio $componente.destino
        if ((Test-Path -LiteralPath $actual -PathType Leaf) -and (Get-FileHash -LiteralPath $actual -Algorithm SHA256).Hash.ToLowerInvariant() -eq $componente.sha256) {
            Copy-Item -LiteralPath $actual -Destination $archivoTemporal
        } else {
            Write-Host ('Descargando ' + $componente.nombre + '...')
            Invoke-WebRequest -Uri $componente.url -OutFile $archivoTemporal -UseBasicParsing -UserAgent $Agente -TimeoutSec 180
        }
        if ((Get-FileHash -LiteralPath $archivoTemporal -Algorithm SHA256).Hash.ToLowerInvariant() -ne $componente.sha256) {
            throw ('El SHA256 de ' + $componente.nombre + ' no coincide. No se cambiaron los JAR instalados.')
        }
    }
    $geyser = @($componentes | Where-Object { $_.nombre -eq 'geyser' })[0]
    $configGeyser = Config-Geyser (Join-Path $temporal 'Geyser-Spigot.jar') $geyser.version
    $nuevos = New-Object 'System.Collections.Generic.List[string]'
    $publicados = New-Object 'System.Collections.Generic.List[object]'
    try {
        foreach ($componente in $componentes) {
            $destino = Join-Path $Directorio $componente.destino
            [void](New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($destino)) -Force)
            $copia = $null
            if (Test-Path -LiteralPath $destino) {
                $copia = Join-Path $temporal ('anterior-' + [IO.Path]::GetFileName($destino))
                Copy-Item -LiteralPath $destino -Destination $copia
            }
            Move-Item -LiteralPath (Join-Path $temporal ([IO.Path]::GetFileName($componente.destino))) -Destination $destino -Force
            [void]$publicados.Add([pscustomobject]@{ destino = $destino; copia = $copia })
        }
        $properties = @'
# NDR Minecraft - Java 1.21.11 y Bedrock
server-port=25565
server-ip=
online-mode=true
enforce-secure-profile=false
gamemode=survival
force-gamemode=false
difficulty=normal
max-players=10
view-distance=8
simulation-distance=6
motd=NDR - Minecraft Java y Bedrock
pvp=true
spawn-protection=16
enable-rcon=false
enable-query=false
white-list=false
level-name=world
'@
        $iniciales = @{
            'server.properties' = $properties;
            'eula.txt' = "# Lee https://aka.ms/MinecraftEULA antes de iniciar.`neula=false`n";
            'plugins/Geyser-Spigot/config.yml' = $configGeyser
        }
        foreach ($nombre in $iniciales.Keys) {
            $destino = Join-Path $Directorio $nombre
            if (-not (Test-Path -LiteralPath $destino)) {
                [void](New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($destino)) -Force)
                Escribir-Utf8 $destino $iniciales[$nombre]
                [void]$nuevos.Add($destino)
            }
        }
        $versiones = [pscustomobject]@{ minecraft = $MinecraftVersion; javaMinimo = 21; componentes = $componentes }
        Escribir-Utf8 (Join-Path $Directorio 'versiones.json') ($versiones | ConvertTo-Json -Depth 6)
    } catch {
        foreach ($creado in $nuevos) { Remove-Item -LiteralPath $creado -Force -ErrorAction SilentlyContinue }
        foreach ($publicado in $publicados) {
            if ($publicado.copia) { Copy-Item -LiteralPath $publicado.copia -Destination $publicado.destino -Force }
            else { Remove-Item -LiteralPath $publicado.destino -Force -ErrorAction SilentlyContinue }
        }
        throw
    }
    Write-Host 'Instalacion terminada. El mundo y las configuraciones existentes se conservaron.'
    Write-Host 'Java: TCP 25565. Bedrock: UDP y TCP 19132. Ejecuta Iniciar.bat.'
    Write-Host 'La EULA sigue pendiente de tu aceptacion si no la habias aceptado antes.'
} catch {
    Write-Error ('No se pudo instalar: ' + $_.Exception.Message) -ErrorAction Continue
    exit 1
} finally {
    if ($temporal -and (Test-Path -LiteralPath $temporal)) { Remove-Item -LiteralPath $temporal -Recurse -Force }
}
