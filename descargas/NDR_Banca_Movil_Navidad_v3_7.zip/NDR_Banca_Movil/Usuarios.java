import javax.crypto.Mac;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Perfiles NDR persistentes. DNI protegido mediante HMAC con clave local separada. */
public final class Usuarios {
    public record Perfil(String id, String nombre, String correo, String telefono, String cci, String huellaDni) {}
    public record Sesion(Perfil perfil, String csrf, long venceEn) {}
    public record Acceso(Sesion sesion, String tokenCookie) {}
    public record Borrador(String nombre, String correo, String telefono, String huellaDni, String sal, String resumen) {}
    public record Ingreso(Perfil perfil, String huellaDni, boolean vincularDni) {}
    private record Credencial(Perfil perfil, String sal, String resumen) {}
    private record SesionInterna(Sesion sesion) {}

    private static final int ITERACIONES = 310_000;
    private static final long VIDA = 30 * 60_000L;
    private static final SecureRandom ALEATORIO = new SecureRandom();
    private final Path archivo;
    private final byte[] claveDni;
    private final Map<String, Credencial> porCorreo = new HashMap<>();
    private final Map<String, Credencial> porTelefono = new HashMap<>();
    private final Set<String> ccis = new HashSet<>();
    private final Set<String> dnis = new HashSet<>();
    private final ConcurrentHashMap<String, SesionInterna> sesiones = new ConcurrentHashMap<>();

    public Usuarios(Path directorio) throws IOException {
        Files.createDirectories(directorio);
        limitarPermisos(directorio, true);
        archivo = directorio.resolve("usuarios.ndr");
        Path llave = directorio.resolve("dni.key");
        if (!Files.exists(llave)) {
            if (Files.exists(archivo) && Files.readString(archivo, StandardCharsets.UTF_8).startsWith("NDR-USUARIOS-3"))
                throw new IOException("Falta dni.key para los perfiles actuales. Restaura la copia de seguridad de datos.");
            byte[] nueva = nuevoAleatorio(32);
            try {
                Files.writeString(llave, Base64.getUrlEncoder().withoutPadding().encodeToString(nueva),
                        StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW);
                limitarPermisos(llave, false);
            } catch (FileAlreadyExistsException concurrencia) { /* otra instancia creó la clave */ }
        }
        try { claveDni = Base64.getUrlDecoder().decode(Files.readString(llave, StandardCharsets.UTF_8).trim()); }
        catch (IllegalArgumentException ex) { throw new IOException("La clave de DNI está dañada.", ex); }
        if (claveDni.length != 32) throw new IOException("La clave de DNI no tiene longitud válida.");
        if (Files.exists(archivo)) cargar();
    }

    private void cargar() throws IOException {
        List<String> lineas = Files.readAllLines(archivo, StandardCharsets.UTF_8);
        if (lineas.isEmpty()) throw new IOException("Archivo de usuarios vacío.");
        String cabecera = lineas.get(0);
        int version = switch (cabecera) {
            case "NDR-USUARIOS-1" -> 1;
            case "NDR-USUARIOS-2" -> 2;
            case "NDR-USUARIOS-3" -> 3;
            default -> throw new IOException("Formato de perfiles desconocido.");
        };
        for (int i = 1; i < lineas.size(); i++) {
            String[] a = lineas.get(i).split("\\|", -1);
            if (a.length != (version == 1 ? 6 : version == 2 ? 7 : 8))
                throw new IOException("Perfil dañado en línea " + (i + 1));
            try {
                String cci = version == 1 ? generarCciUnico() : dec(a[4]);
                String huella = version == 3 ? a[5] : "";
                if (!cci.matches("[0-9]{20}") || (!huella.isEmpty() && !huella.matches("[a-f0-9]{64}")))
                    throw new IOException("CCI o DNI inválido en archivo de perfiles.");
                Perfil p = new Perfil(dec(a[0]), dec(a[1]), dec(a[2]), dec(a[3]), cci, huella);
                Credencial c = new Credencial(p, a[version == 1 ? 4 : version == 2 ? 5 : 6],
                        a[version == 1 ? 5 : version == 2 ? 6 : 7]);
                if (porCorreo.putIfAbsent(p.correo(), c) != null || porTelefono.putIfAbsent(p.telefono(), c) != null)
                    throw new IOException("Contactos duplicados en perfiles.");
                if (!ccis.add(cci) || (!huella.isEmpty() && !dnis.add(huella)))
                    throw new IOException("CCI o DNI repetido en perfiles.");
            } catch (IllegalArgumentException ex) { throw new IOException("Archivo de perfiles inválido.", ex); }
        }
        if (version < 3) guardar();
    }

    public synchronized Borrador prepararRegistro(String nombre, String correo, String telefono, String dni, String clave) throws Exception {
        nombre = nombre.trim().replaceAll("\\s+", " ");
        correo = correo.trim().toLowerCase(Locale.ROOT);
        telefono = normalizarTelefono(telefono.trim());
        validar(nombre, correo, telefono, dni, clave);
        String huella = huellaDni(dni);
        asegurarDisponibles(correo, telefono, huella);
        byte[] sal = nuevoAleatorio(16);
        return new Borrador(nombre, correo, telefono, huella,
                Base64.getUrlEncoder().withoutPadding().encodeToString(sal),
                Base64.getUrlEncoder().withoutPadding().encodeToString(hash(clave.toCharArray(), sal)));
    }

    public synchronized Perfil confirmarRegistro(Borrador borrador) throws IOException {
        asegurarDisponibles(borrador.correo(), borrador.telefono(), borrador.huellaDni());
        String cci = generarCciUnico();
        Perfil p = new Perfil(UUID.randomUUID().toString(), borrador.nombre(), borrador.correo(),
                borrador.telefono(), cci, borrador.huellaDni());
        Credencial c = new Credencial(p, borrador.sal(), borrador.resumen());
        porCorreo.put(p.correo(), c);
        porTelefono.put(p.telefono(), c);
        ccis.add(cci);
        dnis.add(p.huellaDni());
        try { guardar(); }
        catch (IOException ex) {
            porCorreo.remove(p.correo()); porTelefono.remove(p.telefono()); ccis.remove(cci); dnis.remove(p.huellaDni());
            throw ex;
        }
        return p;
    }

    private void asegurarDisponibles(String correo, String telefono, String huella) {
        if (porCorreo.containsKey(correo) || porTelefono.containsKey(telefono) || dnis.contains(huella))
            throw new Falta(409, "Ya existe una cuenta con estos datos. Inicia sesión o utiliza datos diferentes.");
    }

    public synchronized Ingreso comprobarIngreso(String identificador, String dni, String clave) throws Exception {
        String entrada = identificador.trim().toLowerCase(Locale.ROOT);
        Credencial c = entrada.contains("@") ? porCorreo.get(entrada) : porTelefono.get(normalizarTelefono(entrada));
        if (!dni.matches("[0-9]{8}") || clave.length() > 256 || clave.isEmpty())
            throw new Falta(401, "Datos de acceso incorrectos.");
        byte[] sal = c == null ? new byte[16] : Base64.getUrlDecoder().decode(c.sal());
        byte[] esperado = c == null ? new byte[32] : Base64.getUrlDecoder().decode(c.resumen());
        boolean contrasenaCorrecta = MessageDigest.isEqual(hash(clave.toCharArray(), sal), esperado);
        String huella = huellaDni(dni);
        boolean dniCorrecto = c != null && (c.perfil().huellaDni().isEmpty()
                || MessageDigest.isEqual(c.perfil().huellaDni().getBytes(StandardCharsets.US_ASCII), huella.getBytes(StandardCharsets.US_ASCII)));
        if (!contrasenaCorrecta || !dniCorrecto) throw new Falta(401, "Correo/celular, DNI o contraseña incorrectos.");
        if (c.perfil().huellaDni().isEmpty() && dnis.contains(huella))
            throw new Falta(409, "Este DNI ya está vinculado a otra cuenta.");
        return new Ingreso(c.perfil(), huella, c.perfil().huellaDni().isEmpty());
    }

    /** Asociar DNI a perfiles históricos solo después de contraseña Y código recibido. */
    public synchronized Acceso confirmarIngreso(Ingreso ingreso) throws IOException {
        Credencial actual = porCorreo.get(ingreso.perfil().correo());
        if (actual == null || !actual.perfil().id().equals(ingreso.perfil().id()))
            throw new Falta(401, "Esta cuenta ya no está disponible.");
        if (ingreso.vincularDni() && actual.perfil().huellaDni().isEmpty()) {
            if (dnis.contains(ingreso.huellaDni())) throw new Falta(409, "Este DNI ya está vinculado a otra cuenta.");
            Perfil p = new Perfil(actual.perfil().id(), actual.perfil().nombre(), actual.perfil().correo(),
                    actual.perfil().telefono(), actual.perfil().cci(), ingreso.huellaDni());
            Credencial nuevo = new Credencial(p, actual.sal(), actual.resumen());
            porCorreo.put(p.correo(), nuevo); porTelefono.put(p.telefono(), nuevo); dnis.add(ingreso.huellaDni());
            try { guardar(); }
            catch (IOException ex) {
                porCorreo.put(p.correo(), actual); porTelefono.put(p.telefono(), actual); dnis.remove(ingreso.huellaDni());
                throw ex;
            }
            actual = nuevo;
        }
        if (!actual.perfil().huellaDni().equals(ingreso.huellaDni()))
            throw new Falta(401, "No se pudo confirmar la identidad.");
        return abrirSesion(actual.perfil());
    }

    public synchronized Perfil perfilPorId(String id) {
        for (Credencial c : porCorreo.values()) if (c.perfil().id().equals(id)) return c.perfil();
        return null;
    }
    public synchronized Perfil perfilPorCci(String cci) {
        for (Credencial c : porCorreo.values()) if (c.perfil().cci().equals(cci)) return c.perfil();
        return null;
    }
    private Acceso abrirSesion(Perfil perfil) {
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(nuevoAleatorio(32));
        String csrf = Base64.getUrlEncoder().withoutPadding().encodeToString(nuevoAleatorio(24));
        Sesion sesion = new Sesion(perfil, csrf, Instant.now().toEpochMilli() + VIDA);
        sesiones.put(digest(token), new SesionInterna(sesion));
        if (sesiones.size() > 4096) sesiones.entrySet().removeIf(e -> e.getValue().sesion().venceEn() < System.currentTimeMillis());
        return new Acceso(sesion, token);
    }
    public Sesion sesion(String token) {
        if (token == null || token.length() > 128 || token.isBlank()) return null;
        String clave = digest(token);
        SesionInterna s = sesiones.get(clave);
        if (s == null) return null;
        if (s.sesion().venceEn() <= System.currentTimeMillis()) { sesiones.remove(clave); return null; }
        return s.sesion();
    }
    public void cerrar(String token) { if (token != null && token.length() <= 128) sesiones.remove(digest(token)); }

    private void guardar() throws IOException {
        StringBuilder b = new StringBuilder("NDR-USUARIOS-3\n");
        for (Credencial c : porCorreo.values()) {
            Perfil p = c.perfil();
            b.append(enc(p.id())).append('|').append(enc(p.nombre())).append('|').append(enc(p.correo())).append('|')
             .append(enc(p.telefono())).append('|').append(enc(p.cci())).append('|').append(p.huellaDni())
             .append('|').append(c.sal()).append('|').append(c.resumen()).append('\n');
        }
        Path temporal = Files.createTempFile(archivo.getParent(), "ndr-", ".tmp");
        try {
            limitarPermisos(temporal, false);
            Files.writeString(temporal, b.toString(), StandardCharsets.UTF_8, StandardOpenOption.TRUNCATE_EXISTING);
            try { Files.move(temporal, archivo, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(temporal, archivo, StandardCopyOption.REPLACE_EXISTING); }
            limitarPermisos(archivo, false);
        } finally { Files.deleteIfExists(temporal); }
    }
    private static void validar(String nombre, String correo, String telefono, String dni, String clave) {
        if (nombre.length() < 3 || nombre.length() > 100 || nombre.chars().anyMatch(ch -> ch < 32))
            throw new Falta(400, "Introduce tu nombre completo (3 a 100 caracteres).");
        if (correo.length() > 254 || !correo.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$"))
            throw new Falta(400, "Introduce un correo electrónico válido.");
        if (!telefono.matches("\\+519[0-9]{8}"))
            throw new Falta(400, "Introduce un celular peruano válido: 9XXXXXXXX.");
        if (!dni.matches("[0-9]{8}")) throw new Falta(400, "El DNI debe tener exactamente 8 dígitos.");
        if (clave.length() < 12 || clave.length() > 128 || clave.chars().anyMatch(ch -> ch < 32))
            throw new Falta(400, "La contraseña debe tener entre 12 y 128 caracteres.");
    }
    public static String normalizarTelefono(String tel) {
        String limpio = tel.replaceAll("[ ()-]", "");
        if (limpio.matches("9[0-9]{8}")) limpio = "+51" + limpio;
        if (limpio.matches("519[0-9]{8}")) limpio = "+" + limpio;
        return limpio;
    }
    private String generarCciUnico() {
        String cci;
        do {
            StringBuilder b = new StringBuilder("002");
            for (int i = 0; i < 17; i++) b.append(ALEATORIO.nextInt(10));
            cci = b.toString();
        } while (ccis.contains(cci));
        return cci;
    }
    private String huellaDni(String dni) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(claveDni, "HmacSHA256"));
            return HexFormat.of().formatHex(mac.doFinal(dni.getBytes(StandardCharsets.US_ASCII)));
        } catch (Exception ex) { throw new IllegalStateException("No se pudo proteger el DNI.", ex); }
    }
    private static byte[] hash(char[] clave, byte[] sal) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(clave, sal, ITERACIONES, 256);
        try { return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(); }
        finally { spec.clearPassword(); Arrays.fill(clave, '\0'); }
    }
    private static byte[] nuevoAleatorio(int n) { byte[] b = new byte[n]; ALEATORIO.nextBytes(b); return b; }
    private static String digest(String s) {
        try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.US_ASCII))); }
        catch (Exception ex) { throw new IllegalStateException(ex); }
    }
    private static String enc(String s) { return Base64.getUrlEncoder().withoutPadding().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }
    private static String dec(String s) { return new String(Base64.getUrlDecoder().decode(s), StandardCharsets.UTF_8); }
    private static void limitarPermisos(Path p, boolean directorio) {
        try { Files.setPosixFilePermissions(p, java.nio.file.attribute.PosixFilePermissions.fromString(directorio ? "rwx------" : "rw-------")); }
        catch (UnsupportedOperationException | IOException ignored) { }
    }
    public static final class Falta extends RuntimeException {
        public final int codigo;
        public Falta(int codigo, String mensaje) { super(mensaje); this.codigo = codigo; }
    }
}
