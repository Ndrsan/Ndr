﻿$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$puerto = if ($env:PORT -match '^\d{1,5}$') { [int]$env:PORT } else { 18083 }
Write-Host ''
Write-Host '==============================================='
Write-Host " NDR 3.7 | RESEND | CUENTAS REINICIABLES ($puerto)"
Write-Host '==============================================='

if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
    Write-Host 'ERROR: Instala Java 17 o superior.' -ForegroundColor Red
    exit 1
}
if (-not (Test-Path -LiteralPath 'target\banca-movil.jar')) {
    Write-Host 'ERROR: No existe target\banca-movil.jar. Ejecuta compilar.bat.' -ForegroundColor Red
    exit 1
}
$direccion = "http://127.0.0.1:$puerto"
try {
    $ya = Invoke-RestMethod -Uri "$direccion/api/salud" -TimeoutSec 2
    if ($ya.servicio -eq 'NDR' -and $ya.version -eq '3.7-navidad-visual') {
        Write-Host 'Ya existe un servidor NDR 3.7 abierto. Usa ABRIR_NDR.bat.' -ForegroundColor Yellow
        exit 0
    }
    Write-Host 'ERROR: El puerto esta ocupado por una version anterior. CIERRA primero su ventana.' -ForegroundColor Red
    exit 2
} catch {
    # Servidor desconectado: podemos iniciarlo.
}

# Opcional: clave cifrada con DPAPI, vinculada a este usuario de Windows.
# Nunca se guarda en el ZIP ni en texto plano.
$archivoClave = $null
if (-not [string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
    $archivoClave = Join-Path $env:LOCALAPPDATA 'NDR\credenciales\resend-clave.xml'
}
if ([string]::IsNullOrWhiteSpace($env:RESEND_API_KEY) -and [string]::IsNullOrWhiteSpace($env:NDR_TWILIO_SID)) {
    $segura = $null
    $desdeAlmacen = $false
    if ($archivoClave -and (Test-Path -LiteralPath $archivoClave -PathType Leaf)) {
        try {
            $segura = Import-Clixml -LiteralPath $archivoClave
            if ($segura -isnot [System.Security.SecureString]) {
                throw 'El archivo no contiene una clave protegida.'
            }
            $desdeAlmacen = $true
            Write-Host 'Se encontro una clave Resend cifrada para este usuario de Windows.' -ForegroundColor Green
        } catch {
            Write-Host 'No se pudo recuperar la clave guardada. Introduce una nueva.' -ForegroundColor Yellow
            $segura = $null
        }
    }
    if ($null -eq $segura) {
        Write-Host ''
        Write-Host 'Crea tu clave en https://resend.com/api-keys'
        Write-Host 'La clave se escribira oculta; nunca se mostrara en pantalla.'
        $segura = Read-Host 'Pega aqui tu clave API de Resend (comienza por re_)' -AsSecureString
    }
    $puntero = [IntPtr]::Zero
    try {
        $puntero = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($segura)
        $env:RESEND_API_KEY = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($puntero)
    } finally {
        if ($puntero -ne [IntPtr]::Zero) {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($puntero)
        }
    }
    if ($env:RESEND_API_KEY -notmatch '^re_[A-Za-z0-9_-]{8,}$') {
        $segura.Dispose()
        Remove-Item Env:RESEND_API_KEY -ErrorAction SilentlyContinue
        Write-Host 'ERROR: La clave no tiene el formato esperado de Resend.' -ForegroundColor Red
        exit 3
    }
    if (-not $desdeAlmacen -and $archivoClave) {
        Write-Host ''
        Write-Host 'Si eliges S, Windows cifrara la clave solo para tu usuario (DPAPI).'
        Write-Host 'La clave no se incluye en el ZIP y no tendras que pegarla al reiniciar NDR.'
        $guardar = Read-Host 'Guardar la clave cifrada en este equipo? [S/N]'
        if ($guardar -match '^[sS]$') {
            try {
                $directorioClave = Split-Path -Parent $archivoClave
                New-Item -ItemType Directory -Path $directorioClave -Force | Out-Null
                $segura | Export-Clixml -LiteralPath $archivoClave -Force
                Write-Host 'Clave guardada cifrada para este usuario de Windows.' -ForegroundColor Green
            } catch {
                Write-Host 'No se pudo guardar la clave. Podras volver a introducirla al iniciar.' -ForegroundColor Yellow
            }
        }
    }
    $segura.Dispose()
}

if (-not [string]::IsNullOrWhiteSpace($env:RESEND_API_KEY)) {
    if ([string]::IsNullOrWhiteSpace($env:NDR_RESEND_FROM)) {
        Write-Host ''
        Write-Host 'Si aun no tienes dominio propio verificado, presiona ENTER.'
        Write-Host 'Se usara onboarding@resend.dev (solo llega a tu correo de Resend).'
        $remitente = Read-Host 'Remitente verificado (ej. seguridad@tudominio.com)'
        if ([string]::IsNullOrWhiteSpace($remitente)) {
            $env:NDR_RESEND_FROM = 'NDR Banca Movil <onboarding@resend.dev>'
        } else {
            $env:NDR_RESEND_FROM = "NDR Banca Movil <$($remitente.Trim())>"
        }
    }
    if ($env:NDR_RESEND_FROM -like '*@resend.dev*') {
        Write-Host ''
        Write-Host 'ATENCION: el remitente de prueba solo puede enviar al correo de tu cuenta Resend.' -ForegroundColor Yellow
        Write-Host 'Para otros correos, primero verifica un dominio en https://resend.com/domains'
    }
}

Write-Host ''
Write-Host 'Servidor local: ' $direccion
Write-Host 'Abre ABRIR_NDR.bat y no cierres esta ventana.'
Write-Host 'La clave API no se imprime; solo se guarda cifrada si tu lo autorizaste.'
Write-Host 'Presiona Ctrl+C para detener el servidor.'
Write-Host ''
try {
    & java -jar 'target\banca-movil.jar'
    exit $LASTEXITCODE
} finally {
    Remove-Item Env:RESEND_API_KEY -ErrorAction SilentlyContinue
}
