import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.Map;

/** Entrega externa de OTP: Resend por API HTTPS y Twilio para SMS opcional.
 * Nunca genera codigos de demostracion ni entrega el OTP al navegador.
 */
public final class Notificador {
    private static final URI RESEND_OFICIAL = URI.create("https://api.resend.com/emails");
    private final HttpClient cliente;
    private final URI endpoint;

    public Notificador() {
        this(HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build(), RESEND_OFICIAL);
    }

    /** Punto de inyeccion para pruebas de integracion con un servidor HTTPS local. */
    Notificador(HttpClient cliente, URI endpoint) {
        this.cliente = cliente;
        this.endpoint = endpoint;
    }

    private static String variable(String nombre) {
        String s = System.getenv(nombre);
        return s == null ? "" : s.trim();
    }

    public boolean disponible(String canal) {
        return switch (canal) {
            case "correo" -> !variable("RESEND_API_KEY").isEmpty();
            case "sms" -> !variable("NDR_TWILIO_SID").isEmpty()
                    && !variable("NDR_TWILIO_TOKEN").isEmpty()
                    && !variable("NDR_TWILIO_FROM").isEmpty();
            default -> false;
        };
    }

    public void enviar(String canal, String destino, String nombre, String codigo) throws Exception {
        if (!codigo.matches("[0-9]{6}")) throw new IllegalArgumentException("Codigo OTP invalido");
        if (!disponible(canal)) throw new Usuarios.Falta(503, canal.equals("sms")
                ? "El servicio SMS no esta configurado. Selecciona correo o activa Twilio."
                : "El correo no esta configurado. Ejecuta iniciar.bat e introduce tu clave API de Resend.");
        switch (canal) {
            case "correo" -> correo(destino, nombre, codigo);
            case "sms" -> sms(destino, nombre, codigo);
            default -> throw new Usuarios.Falta(400, "Canal de verificacion invalido.");
        }
    }

    private static String json(String valor) {
        StringBuilder resultado = new StringBuilder("\"");
        for (int i = 0; i < valor.length(); i++) {
            char c = valor.charAt(i);
            switch (c) {
                case '"' -> resultado.append("\\\"");
                case '\\' -> resultado.append("\\\\");
                case '\n' -> resultado.append("\\n");
                case '\r' -> resultado.append("\\r");
                case '\t' -> resultado.append("\\t");
                default -> {
                    if (c < 32) resultado.append(String.format("\\u%04x", (int) c));
                    else resultado.append(c);
                }
            }
        }
        return resultado.append('"').toString();
    }

    private static String escapar(String valor) {
        return valor.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }
    private static String html(String nombre, String codigo) {
        String saludo = escapar(nombre.split("\\s+")[0]);
        return "<!doctype html><html lang=\"es\"><head><meta charset=\"UTF-8\"></head>"
          + "<body style=\"margin:0;padding:32px 12px;background:#f1f5f2;font-family:Arial,sans-serif;color:#163c30\">"
          + "<div style=\"max-width:520px;margin:auto;background:#fff;border-radius:24px;overflow:hidden;box-shadow:0 12px 36px #154b3020\">"
          + "<div style=\"background:#095039;padding:28px;color:#fff;text-align:center;font-size:26px;font-weight:bold\">🎄 NDR · Banca Móvil</div>"
          + "<div style=\"padding:32px;text-align:center\"><p style=\"font-size:20px\">¡Hola, " + saludo + "! ✨</p>"
          + "<h1 style=\"font-size:24px;margin:10px 0\">Tu código de seguridad</h1>"
          + "<p style=\"font-size:15px;line-height:1.6\">Protegemos tu acceso con una verificación adicional. Introduce este código en NDR:</p>"
          + "<div style=\"padding:22px;margin:20px 0;background:#edf8f2;border:1px solid #a8d8bd;border-radius:18px;"
          + "font-size:40px;font-weight:800;letter-spacing:10px;color:#075539\">" + codigo + "</div>"
          + "<p style=\"font-size:14px\">⏳ Válido durante <b>10 minutos</b>.</p>"
          + "<p style=\"font-size:13px;color:#60776d;line-height:1.6\">No compartas este código con nadie. NDR nunca te lo pedirá por llamada o mensaje.</p>"
          + "<p style=\"font-size:14px;color:#a85c21\">🎁 ¡Que la seguridad te acompañe estas fiestas!</p></div>"
          + "<div style=\"padding:18px;text-align:center;background:#f4f8f5;font-size:12px;color:#61776b\">"
          + "Si no solicitaste este código, ignora el mensaje.</div></div></body></html>";
    }


    private void correo(String destino, String nombre, String codigo) throws Exception {
        String clave = variable("RESEND_API_KEY");
        if (!clave.matches("re_[A-Za-z0-9_-]{8,}"))
            throw new Usuarios.Falta(503, "La clave API de Resend no es valida o sigue siendo un ejemplo. Debe empezar con re_.");
        String remitente = variable("NDR_RESEND_FROM");
        if (remitente.isEmpty()) remitente = "NDR Banca Movil <onboarding@resend.dev>";
        if (!destino.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$"))
            throw new Usuarios.Falta(400, "La direccion del destinatario no es valida.");
        // Resend comprueba que el remitente pertenece a un dominio verificado.
        // El remitente onboarding@resend.dev solo permite envios a la cuenta de Resend.
        String texto = "NDR Banca Movil: Hola, " + nombre.split("\\s+")[0]
                + ". Tu codigo de acceso es " + codigo
                + ". Valido durante 10 minutos. No lo compartas con nadie.";
        String cuerpo = "{\"from\":" + json(remitente) + ",\"to\":[" + json(destino)
                + "],\"subject\":" + json("🎄 Tu código de seguridad NDR")
                + ",\"html\":" + json(html(nombre, codigo))
                + ",\"text\":" + json(texto) + "}";
        HttpRequest solicitud = HttpRequest.newBuilder(endpoint)
                .timeout(Duration.ofSeconds(18))
                .header("Authorization", "Bearer " + clave)
                .header("Content-Type", "application/json; charset=utf-8")
                .header("User-Agent", "NDR-Banca-Movil/3.6")
                .POST(HttpRequest.BodyPublishers.ofString(cuerpo, StandardCharsets.UTF_8))
                .build();
        HttpResponse<String> respuesta;
        try {
            respuesta = cliente.send(solicitud, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        } catch (InterruptedException interrumpido) {
            Thread.currentThread().interrupt();
            throw new Usuarios.Falta(503, "La solicitud al servicio de correo fue interrumpida. Intenta nuevamente.");
        } catch (IOException error) {
            throw new Usuarios.Falta(503, "No se pudo conectar con la API de Resend. Comprueba tu conexion a Internet.");
        }
        int estado = respuesta.statusCode();
        if (estado != 200) {
            // Nunca volcar el cuerpo HTTP al registro: puede contener datos privados.
            System.err.println("Resend rechazo el envio de correo: HTTP " + estado);
            throw new Usuarios.Falta(503, diagnosticoResend(estado, respuesta.body()));
        }
        // La respuesta debe tener un ID de mensaje aceptado por Resend. No equivale
        // a confirmacion de entrega final en el buzon del destinatario.
        try {
            Map<String, Object> resultado = JsonMini.object(respuesta.body());
            if (!(resultado.get("id") instanceof String id) || id.isBlank())
                throw new IllegalArgumentException("Respuesta sin identificador");
        } catch (IllegalArgumentException ex) {
            throw new Usuarios.Falta(503, "Resend no devolvio una confirmacion valida de envio. Intenta de nuevo.");
        }
    }

    private static String diagnosticoResend(int estado, String cuerpo) {
        String detalle = cuerpo == null ? "" : cuerpo.toLowerCase(java.util.Locale.ROOT);
        if (estado == 401)
            return "Resend rechazo la clave API. Crea una clave con permiso de envio y reinicia NDR.";
        if (estado == 403) {
            if (detalle.contains("testing emails") || detalle.contains("your own email"))
                return "Resend permite el remitente de prueba solo para el correo de tu cuenta Resend. Para otros destinatarios, verifica un dominio y configura NDR_RESEND_FROM.";
            return "Resend no autorizo el remitente. Verifica el dominio y los permisos de la clave API en Resend.";
        }
        if (estado == 422 || estado == 400)
            return "Resend rechazo los datos del correo. Revisa el remitente y la direccion registrada.";
        if (estado == 429)
            return "Limite temporal de Resend alcanzado. Vuelve a intentarlo mas tarde.";
        if (estado >= 500)
            return "Resend no esta disponible temporalmente. Prueba nuevamente mas tarde.";
        return "Resend no acepto el envio (HTTP " + estado + "). Revisa la configuracion de tu cuenta.";
    }

    private static void sms(String destino, String nombre, String codigo) throws Exception {
        String sid = System.getenv("NDR_TWILIO_SID").trim();
        String token = System.getenv("NDR_TWILIO_TOKEN");
        String origen = System.getenv("NDR_TWILIO_FROM").trim();
        if (!sid.matches("AC[a-fA-F0-9]{32}") || !origen.matches("\\+[0-9]{8,15}"))
            throw new IOException("La configuración Twilio no es válida.");
        String mensaje = "🎄 NDR: ¡Hola, " + nombre.split("\\s+")[0] + "! Tu código de ingreso es " + codigo
                + ". Vence en 10 minutos. Nunca lo compartas. ✨";
        String formulario = "To=" + enc(destino) + "&From=" + enc(origen) + "&Body=" + enc(mensaje);
        String autenticar = Base64.getEncoder().encodeToString((sid + ":" + token).getBytes(StandardCharsets.UTF_8));
        HttpClient cliente = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(12)).build();
        HttpRequest solicitud = HttpRequest.newBuilder(URI.create("https://api.twilio.com/2010-04-01/Accounts/" + sid + "/Messages.json"))
                .timeout(Duration.ofSeconds(16)).header("Authorization", "Basic " + autenticar)
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(formulario)).build();
        HttpResponse<String> respuesta = cliente.send(solicitud, HttpResponse.BodyHandlers.ofString());
        if (respuesta.statusCode() != 201) throw new IOException("El servicio SMS no aceptó el mensaje (" + respuesta.statusCode() + ").");
        // HTTP 201 confirma aceptación por Twilio, no recepción en el dispositivo final.
    }
    private static String enc(String valor) { return URLEncoder.encode(valor, StandardCharsets.UTF_8); }
}
