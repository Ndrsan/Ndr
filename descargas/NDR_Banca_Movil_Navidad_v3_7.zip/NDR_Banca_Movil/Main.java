import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.*;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Files;
import java.nio.file.AtomicMoveNotSupportedException;
import java.time.Instant;
import java.util.*;
import java.security.SecureRandom;
import java.security.MessageDigest;
import java.util.concurrent.*;

/** NDR: acceso y movimientos locales persistentes, con proveedor externo opcional. */
public final class Main {
    private static final String VERSION = "3.7-navidad-visual";
    private static final int PUERTO = puerto();
    private static final Usuarios USUARIOS;
    private static final Notificador MENSAJERIA = new Notificador();
    private static final SecureRandom CODIGOS = new SecureRandom();
    private static final byte[] CLAVE_OTP = new byte[32];
    private static final ConcurrentHashMap<String, Desafio> DESAFIOS = new ConcurrentHashMap<>();
    static { CODIGOS.nextBytes(CLAVE_OTP); }
    private static final long VIDA_OTP = 10 * 60_000L;
    private static final class Desafio {
        final boolean registro;
        final Usuarios.Borrador borrador;
        final Usuarios.Ingreso ingreso;
        final String canal, destino;
        final String codigoHash;
        final long expira;
        int fallos = 0;
        Desafio(boolean registro, Usuarios.Borrador borrador, Usuarios.Ingreso ingreso,
                String canal, String destino, String codigo, long expira) {
            this.registro = registro; this.borrador = borrador; this.ingreso = ingreso;
            this.canal = canal; this.destino = destino;
            this.codigoHash = huellaOtp(codigo); this.expira = expira;
        }
    }

    private static final ProveedorFinanciero BANCO;
    private static final BigDecimal IMPORTE_MAXIMO = new BigDecimal("50000.00");
    private static final ConcurrentHashMap<String, Intentos> LIMITES = new ConcurrentHashMap<>();
    private static final String ORIGEN = "http://localhost:" + PUERTO;
    private static final String ORIGEN_IP = "http://127.0.0.1:" + PUERTO;
    private static final String ORIGEN_PUBLICO = System.getenv("NDR_PUBLIC_ORIGIN");
    private static final String COOKIE = "NDR_SESION";
    static {
        try {
            Path datos = directorioDatos();
            USUARIOS = new Usuarios(datos);
            BANCO = proveedor(datos);
        }
        catch (IOException e) { throw new ExceptionInInitializerError("No se pudo cargar el almacén de perfiles: " + e.getMessage()); }
    }
    private static final class Intentos {
        int cantidad;
        long inicio = System.currentTimeMillis();
        synchronized boolean permitir(int maximo) {
            long ahora = System.currentTimeMillis();
            if (ahora - inicio > 15 * 60_000L) { inicio = ahora; cantidad = 0; }
            return ++cantidad <= maximo;
        }
    }

    public static void main(String[] args) throws Exception {
        if (ORIGEN_PUBLICO != null && !ORIGEN_PUBLICO.matches("https://[A-Za-z0-9.-]+(:[0-9]{1,5})?"))
            throw new IllegalArgumentException("NDR_PUBLIC_ORIGIN debe ser una URL HTTPS sin ruta.");
        HttpServer s;
        try {
            s = HttpServer.create(new InetSocketAddress("127.0.0.1", PUERTO), 48);
        } catch (java.net.BindException e) {
            System.err.println("ERROR: El puerto " + PUERTO + " está ocupado. Cierra la otra instancia de NDR o configura PORT.");
            throw e;
        }
        s.setExecutor(Executors.newFixedThreadPool(12));
        s.createContext("/", Main::despachar);
        s.start();
        System.out.println("NDR Banca Móvil · http://localhost:" + PUERTO);
        System.out.println("Proveedor de cuenta: " + BANCO.nombre());
        System.out.println("AVISO: acceso local. No publicar el servidor Java directamente en Internet.");
        if (!BANCO.estaConfigurado()) System.out.println("Proveedor no disponible. Transferencias bloqueadas.");
    }

    /** El directorio de datos del usuario evita fallos de escritura en Descargas/OneDrive.
     *  Se respetan los perfiles de una versión anterior para no perder cuentas. */
    private static Path directorioDatos() {
        String explicito = System.getenv("NDR_DATA_DIR");
        if (explicito != null && !explicito.isBlank()) return Path.of(explicito);
        Path anterior = Path.of("data");
        if (Files.exists(anterior.resolve("usuarios.ndr"))) return anterior;
        String appData = System.getenv("LOCALAPPDATA");
        if (appData != null && !appData.isBlank()) return Path.of(appData, "NDR", "datos");
        return anterior;
    }

    private static int puerto() {
        try { int p = Integer.parseInt(System.getenv().getOrDefault("PORT", "18083")); return p > 0 && p <= 65535 ? p : 8080; }
        catch (NumberFormatException e) { return 8080; }
    }
    private static ProveedorFinanciero proveedor(Path datos) throws IOException {
        String clase = System.getenv("NDR_PROVIDER_CLASS");
        if (clase == null || clase.isBlank()) return new ProveedorLocal(USUARIOS, datos);
        try {
            Object v = Class.forName(clase.trim()).getDeclaredConstructor().newInstance();
            return (ProveedorFinanciero) v;
        } catch (ReflectiveOperationException | ClassCastException | LinkageError e) {
            System.err.println("Integración bancaria no cargada. Operaciones bloqueadas: " + e.getClass().getSimpleName());
            return new ProveedorNoConectado();
        }
    }

    private static void despachar(HttpExchange ex) throws IOException {
        try {
            String ruta = ex.getRequestURI().getPath();
            String metodo = ex.getRequestMethod();
            switch (ruta) {
                case "/", "/index.html" -> { solo(ex,"GET"); recurso(ex,"/index.html","text/html; charset=utf-8"); }
                case "/style.css" -> { solo(ex,"GET"); recurso(ex,ruta,"text/css; charset=utf-8"); }
                case "/app.js" -> { solo(ex,"GET"); recurso(ex,ruta,"text/javascript; charset=utf-8"); }
                case "/assets/banca-movil.png" -> { solo(ex,"GET"); recurso(ex,ruta,"image/png"); }
                case "/favicon.ico" -> { solo(ex,"GET"); responder(ex,204,"","text/plain"); }
                case "/api/salud" -> { solo(ex,"GET"); responderJson(ex,200,"{\"ok\":true,\"servicio\":\"NDR\",\"version\":"+json(VERSION)+",\"estado\":\"activo\"}"); }
                case "/api/auth/registro" -> { solo(ex,"POST"); escritura(ex,false); limitar(ex,"registro",5); registro(ex); }
                case "/api/auth/login" -> { solo(ex,"POST"); escritura(ex,false); limitar(ex,"login",10); login(ex); }
                case "/api/auth/verificar" -> { solo(ex,"POST"); escritura(ex,false); limitar(ex,"otp",20); verificarOtp(ex); }
                case "/api/identidad/cci" -> { solo(ex,"POST"); escritura(ex,true); mostrarCci(ex,autenticado(ex)); }
                case "/api/auth/sesion" -> { solo(ex,"GET"); perfil(ex); }
                case "/api/auth/logout" -> { solo(ex,"POST"); escritura(ex,true); salir(ex); }
                case "/api/estado" -> { solo(ex,"GET"); estado(ex,autenticado(ex)); }
                case "/api/cuenta" -> { solo(ex,"GET"); cuenta(ex,vinculado(ex)); }
                case "/api/movimientos" -> { solo(ex,"GET"); movimientos(ex,vinculado(ex)); }
                case "/api/transferencias" -> { solo(ex,"POST"); escritura(ex,true); transferir(ex,vinculado(ex)); }
                default -> fallo(404,"Esta función no existe.");
            }
        } catch (Usuarios.Falta f) { responderJson(ex,f.codigo,"{\"ok\":false,\"mensaje\":"+json(f.getMessage())+"}"); }
        catch (Exception f) {
            // Los errores de registro nunca deben mostrarse como operaciones bancarias.
            String ruta = ex.getRequestURI().getPath();
            System.err.println("Error atendiendo " + ruta + ": " + f.getClass().getSimpleName() + ": " + f.getMessage());
            if ("/api/auth/registro".equals(ruta)) {
                responderJson(ex,500,"{\"ok\":false,\"mensaje\":\"No se pudo guardar el perfil. Revisa los permisos de escritura y el registro de errores del servidor.\"}");
            } else if ("/api/auth/login".equals(ruta) || ruta.startsWith("/api/auth/")) {
                responderJson(ex,500,"{\"ok\":false,\"mensaje\":\"No se pudo completar el acceso. Comprueba que NDR siga ejecutándose.\"}");
            } else {
                // Un error ambiguo en transferencias debe conciliarse con la entidad; no afirmar que falló.
                responderJson(ex,502,"{\"ok\":false,\"mensaje\":\"No se confirmó la operación. Revisa el historial y actualiza tu cuenta antes de reintentar.\"}");
            }
        } finally { ex.close(); }
    }
    private static void solo(HttpExchange e, String metodo) {
        if (!metodo.equals(e.getRequestMethod())) fallo(405,"Método no permitido.");
    }
    private static void limitar(HttpExchange e, String accion, int maximo) {
        // Límite local preliminar; producción requiere límites distribuidos por IP, usuario y dispositivo.
        String ip = e.getRemoteAddress().getAddress().getHostAddress();
        if (LIMITES.size() > 4096) LIMITES.clear();
        if (!LIMITES.computeIfAbsent(accion+":"+ip, s -> new Intentos()).permitir(maximo))
            fallo(429,"Demasiados intentos. Vuelve a intentarlo después de 15 minutos.");
    }
    private static void escritura(HttpExchange e, boolean sesionRequerida) {
        String origen = e.getRequestHeaders().getFirst("Origin");
        boolean permitido = ORIGEN_PUBLICO == null
                ? (ORIGEN.equals(origen) || ORIGEN_IP.equals(origen))
                : ORIGEN_PUBLICO.equals(origen);
        if (!permitido) fallo(403,"Origen no autorizado.");
        String tipo = e.getRequestHeaders().getFirst("Content-Type");
        if (tipo == null || !tipo.toLowerCase(Locale.ROOT).startsWith("application/json"))
            fallo(415,"Se requiere application/json.");
        if (!"1".equals(e.getRequestHeaders().getFirst("X-NDR-Request")))
            fallo(403,"Solicitud no autorizada.");
        if (sesionRequerida) {
            Usuarios.Sesion s = autenticado(e);
            String csrf = e.getRequestHeaders().getFirst("X-NDR-CSRF");
            if (csrf == null || !java.security.MessageDigest.isEqual(
                    csrf.getBytes(StandardCharsets.US_ASCII), s.csrf().getBytes(StandardCharsets.US_ASCII)))
                fallo(403,"Verificación de sesión inválida.");
        }
    }
    private static String cookie(HttpExchange e) {
        List<String> entradas = e.getRequestHeaders().getOrDefault("Cookie", List.of());
        for (String entrada : entradas) for (String item : entrada.split(";")) {
            String t = item.trim();
            if (t.startsWith(COOKIE+"=")) return t.substring((COOKIE+"=").length());
        }
        return null;
    }
    private static Usuarios.Sesion autenticado(HttpExchange e) {
        Usuarios.Sesion s = USUARIOS.sesion(cookie(e));
        if (s == null) fallo(401,"Inicia sesión para continuar.");
        return s;
    }
    private static void setCookie(HttpExchange e, String token) {
        e.getResponseHeaders().add("Set-Cookie",COOKIE+"="+token+"; HttpOnly; SameSite=Strict; Path=/; Max-Age=1800"
            + (ORIGEN_PUBLICO != null ? "; Secure" : ""));
    }
    private static void borrarCookie(HttpExchange e) {
        e.getResponseHeaders().add("Set-Cookie",COOKIE+"=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0"
            + (ORIGEN_PUBLICO != null ? "; Secure" : ""));
    }
    private static Map<String,Object> datos(HttpExchange e) throws IOException {
        byte[] bytes;
        try (InputStream in = e.getRequestBody()) { bytes = in.readNBytes(8193); }
        if (bytes.length > 8192) fallo(413,"La solicitud excede 8 KB.");
        try { return JsonMini.object(new String(bytes,StandardCharsets.UTF_8)); }
        catch (IllegalArgumentException err) { fallo(400,"Los datos no tienen formato JSON válido."); return Map.of(); }
    }
    private static String campo(Map<String,Object> d,String clave) {
        return campoLiteral(d,clave).trim();
    }
    private static String campoLiteral(Map<String,Object> d,String clave) {
        Object v = d.get(clave); return v instanceof String ? (String)v : "";
    }
    private static void registro(HttpExchange e) throws Exception {
        Map<String,Object> d = datos(e);
        String canal = campo(d,"canal");
        if (!canal.equals("correo") && !canal.equals("sms")) fallo(400,"Selecciona correo o SMS para recibir tu código.");
        if (!MENSAJERIA.disponible(canal))
            fallo(503, canal.equals("sms") ? "El servicio de SMS no está configurado; utiliza correo."
                    : "El envío por correo requiere una clave API de Resend. Cierra NDR y ejecuta iniciar.bat para configurarla.");
        Usuarios.Borrador borrador = USUARIOS.prepararRegistro(campo(d,"nombre"),campo(d,"correo"),
                campo(d,"telefono"),campo(d,"dni"),campoLiteral(d,"password"));
        iniciarOtp(e, true, borrador, null, canal,
                canal.equals("sms") ? borrador.telefono() : borrador.correo(), borrador.nombre());
    }
    private static void login(HttpExchange e) throws Exception {
        Map<String,Object> d = datos(e);
        Usuarios.Ingreso ingreso = USUARIOS.comprobarIngreso(campo(d,"identificador"),
                campo(d,"dni"),campoLiteral(d,"password"));
        String canal = campo(d,"canal");
        if (!canal.equals("correo") && !canal.equals("sms")) fallo(400,"Elige correo o SMS para verificar tu ingreso.");
        if (!MENSAJERIA.disponible(canal))
            fallo(503, canal.equals("sms") ? "El servicio de SMS no está configurado; utiliza correo."
                    : "El envío por correo requiere una clave API de Resend. Cierra NDR y ejecuta iniciar.bat para configurarla.");
        iniciarOtp(e, false, null, ingreso, canal,
                canal.equals("sms") ? ingreso.perfil().telefono() : ingreso.perfil().correo(),
                ingreso.perfil().nombre());
    }
    private static String huellaOtp(String codigo) {
        try {
            javax.crypto.Mac mac = javax.crypto.Mac.getInstance("HmacSHA256");
            mac.init(new javax.crypto.spec.SecretKeySpec(CLAVE_OTP, "HmacSHA256"));
            return HexFormat.of().formatHex(mac.doFinal(codigo.getBytes(StandardCharsets.US_ASCII)));
        } catch (Exception ex) { throw new IllegalStateException(ex); }
    }
    private static String destinoOculto(String canal, String destino) {
        if (canal.equals("sms")) return "••••••" + destino.substring(Math.max(0, destino.length()-3));
        String[] partes = destino.split("@",2);
        String prefijo = partes[0].substring(0, Math.min(2,partes[0].length()));
        return prefijo + "••••@" + partes[1];
    }
    private static void iniciarOtp(HttpExchange e, boolean registro, Usuarios.Borrador borrador,
            Usuarios.Ingreso ingreso, String canal, String destino, String nombre) throws Exception {
        limitarClave("destino-otp",destino,5);
        if (DESAFIOS.size() > 1000) DESAFIOS.entrySet().removeIf(x -> x.getValue().expira < System.currentTimeMillis());
        if (DESAFIOS.size() > 1200) fallo(503,"Hay demasiadas verificaciones en curso. Intenta más tarde.");
        String codigo = String.format(Locale.ROOT, "%06d", CODIGOS.nextInt(1_000_000));
        String id = UUID.randomUUID().toString();
        Desafio desafio = new Desafio(registro, borrador, ingreso, canal, destino, codigo,
                System.currentTimeMillis() + VIDA_OTP);
        // No dar el código en JSON ni en logs. No abrir sesión sin entrega aceptada.
        try { MENSAJERIA.enviar(canal,destino,nombre,codigo); }
        catch (Usuarios.Falta f) { throw f; }
        catch (Exception ex) {
            // Información de diagnóstico controlada: nunca imprimir claves ni OTP.
            String mensaje = canal.equals("correo")
                    ? "No fue posible conectar con Resend. Revisa Internet e inténtalo otra vez."
                    : "No fue posible contactar a Twilio. Comprueba la configuración del SMS.";
            System.err.println("No se pudo solicitar OTP por " + canal + ": " + ex.getClass().getSimpleName());
            fallo(503,mensaje);
        }
        DESAFIOS.put(id,desafio);
        USUARIOS.cerrar(cookie(e));
        borrarCookie(e);
        responderJson(e,200,"{\"ok\":true,\"desafio\":"+json(id)+",\"destino\":"+json(destinoOculto(canal,destino))+
                ",\"mensaje\":\"Resend o Twilio aceptó el envío de tu código de 6 cifras. Caduca en 10 minutos.\"}");
    }
    private static void limitarClave(String accion, String valor, int maximo) {
        if (!LIMITES.computeIfAbsent(accion+":"+HexFormat.of().formatHex(
                sha256(valor.toLowerCase(Locale.ROOT).getBytes(StandardCharsets.UTF_8))),
                a -> new Intentos()).permitir(maximo)) fallo(429,"Límite de envíos alcanzado. Intenta en 15 minutos.");
    }
    private static byte[] sha256(byte[] datos) {
        try { return MessageDigest.getInstance("SHA-256").digest(datos); }
        catch (Exception ex) { throw new IllegalStateException(ex); }
    }
    private static void verificarOtp(HttpExchange e) throws Exception {
        Map<String,Object> d = datos(e);
        String id = campo(d,"desafio"), codigo = campo(d,"codigo");
        if (!id.matches("[a-fA-F0-9-]{36}") || !codigo.matches("[0-9]{6}"))
            fallo(400,"Introduce el código de 6 cifras enviado a tu contacto.");
        Desafio desafio = DESAFIOS.get(id);
        if (desafio == null) fallo(410,"La verificación ya no está disponible. Vuelve al registro o ingreso.");
        synchronized (desafio) {
            if (desafio.expira < System.currentTimeMillis() || desafio.fallos >= 5) {
                DESAFIOS.remove(id,desafio);
                fallo(410,"El código venció o se agotaron los intentos. Solicita uno nuevo.");
            }
            if (!MessageDigest.isEqual(desafio.codigoHash.getBytes(StandardCharsets.US_ASCII),
                    huellaOtp(codigo).getBytes(StandardCharsets.US_ASCII))) {
                desafio.fallos++;
                if (desafio.fallos >= 5) DESAFIOS.remove(id,desafio);
                fallo(401, desafio.fallos >= 5 ? "Código bloqueado tras 5 intentos. Solicita uno nuevo."
                        : "Código incorrecto. Comprueba el mensaje y vuelve a intentarlo.");
            }
            if (desafio.registro) {
                USUARIOS.confirmarRegistro(desafio.borrador);
                DESAFIOS.remove(id,desafio);
                responderJson(e,201,"{\"ok\":true,\"registroCompleto\":true,\"mensaje\":\"¡Cuenta creada y contacto verificado! Ya puedes iniciar sesión.\"}");
            } else {
                Usuarios.Acceso acceso = USUARIOS.confirmarIngreso(desafio.ingreso);
                DESAFIOS.remove(id,desafio);
                setCookie(e,acceso.tokenCookie());
                responderJson(e,200,respuestaSesion(acceso.sesion()));
            }
        }
    }
    private static void mostrarCci(HttpExchange e, Usuarios.Sesion s) throws IOException {
        responderJson(e,200,"{\"ok\":true,\"cci\":"+json(s.perfil().cci())+"}");
    }
    private static void perfil(HttpExchange e) throws IOException { responderJson(e,200,respuestaSesion(autenticado(e))); }
    private static String respuestaSesion(Usuarios.Sesion s) {
        Usuarios.Perfil p = s.perfil();
        return "{\"ok\":true,\"usuario\":{\"id\":"+json(p.id())+",\"nombre\":"+json(p.nombre())+
            ",\"correo\":"+json(p.correo())+",\"telefono\":"+json(p.telefono())+",\"cciOculto\":"+json(enmascararCci(p.cci()))+
            ",\"contactosVerificados\":true},\"csrf\":"+json(s.csrf())+"}";
    }
    private static void salir(HttpExchange e) throws IOException {
        USUARIOS.cerrar(cookie(e)); borrarCookie(e);
        responderJson(e,200,"{\"ok\":true}");
    }
    private static ProveedorFinanciero.Identidad identidad(Usuarios.Sesion s) {
        return new ProveedorFinanciero.Identidad(s.perfil().id(), s.perfil().correo(), s.perfil().telefono());
    }
    private static ProveedorFinanciero.Identidad vinculado(HttpExchange e) throws Exception {
        Usuarios.Sesion s = autenticado(e);
        if (!BANCO.estaConfigurado()) fallo(503,"Entidad financiera pendiente de integración. No se realizaron operaciones.");
        var identidad = identidad(s);
        if (!BANCO.clienteVerificado(identidad)) fallo(403,"La entidad debe verificar tu identidad y autorizar tus operaciones.");
        return identidad;
    }
    private static void estado(HttpExchange e, Usuarios.Sesion s) throws Exception {
        boolean conectado = BANCO.estaConfigurado();
        boolean verificado = conectado && BANCO.clienteVerificado(identidad(s));
        String modo = BANCO instanceof ProveedorLocal ? "local" : conectado ? "externo" : "desconectado";
        responderJson(e,200,"{\"ok\":true,\"proveedor\":"+json(BANCO.nombre())+
                ",\"conectado\":"+conectado+",\"autenticado\":"+verificado+",\"modo\":"+json(modo)+",\"moneda\":\"PEN\"}");
    }
    private static String enmascararCci(String valor) {
        if (valor == null || valor.isBlank()) return "—";
        String numeros = valor.replaceAll("[^0-9]", "");
        if (numeros.length() < 4) return "••••";
        return "•••• •••• •••• •••• " + numeros.substring(numeros.length() - 4);
    }
    private static void cuenta(HttpExchange e, ProveedorFinanciero.Identidad id) throws Exception {
        ProveedorFinanciero.Cuenta c = BANCO.consultarCuenta(id);
        if (c == null || c.saldoDisponible() == null) throw new IllegalStateException("Cuenta no confirmada");
        responderJson(e,200,"{\"ok\":true,\"cuenta\":{\"titular\":"+json(c.titular())+
                ",\"numero\":"+json(enmascararCci(c.numeroEnmascarado()))+",\"moneda\":"+json(c.moneda())+
                ",\"saldo\":"+json(c.saldoDisponible().toPlainString())+
                ",\"actualizadoEn\":"+json(c.actualizadoEn())+"}}");
    }
    private static void movimientos(HttpExchange e, ProveedorFinanciero.Identidad id) throws Exception {
        List<ProveedorFinanciero.Movimiento> lista = BANCO.consultarTransferencias(id);
        if (lista == null) throw new IllegalStateException("Historial no confirmado");
        StringBuilder b = new StringBuilder("{\"ok\":true,\"movimientos\":[");
        int limite = Math.min(100,lista.size());
        for (int i=0;i<limite;i++) {
            var m=lista.get(i); if(i>0)b.append(',');
            b.append("{\"id\":").append(json(m.identificador())).append(",\"fecha\":").append(json(m.fecha()))
                .append(",\"monto\":").append(json(m.monto())).append(",\"moneda\":").append(json(m.moneda()))
                .append(",\"estado\":").append(json(m.estado())).append(",\"descripcion\":").append(json(m.descripcion())).append('}');
        }
        b.append("]}");responderJson(e,200,b.toString());
    }
    private static void transferir(HttpExchange e, ProveedorFinanciero.Identidad id) throws Exception {
        Map<String,Object> d = datos(e);
        String m = campo(d,"monto");
        if (!m.matches("[0-9]{1,6}(\\.[0-9]{1,2})?")) fallo(400,"Introduce un monto válido en soles.");
        BigDecimal monto = new BigDecimal(m).setScale(2);
        if (monto.signum()<=0 || monto.compareTo(IMPORTE_MAXIMO)>0) fallo(400,"Monto fuera del máximo permitido.");
        String cci=campo(d,"cci"), beneficiario=campo(d,"beneficiario"), concepto=campo(d,"concepto");
        if (!cci.matches("[0-9]{20}")) fallo(400,"El CCI debe contener exactamente 20 dígitos.");
        if (beneficiario.length()<3 || beneficiario.length()>100) fallo(400,"Verifica el beneficiario.");
        if (concepto.length()>140) fallo(400,"El concepto supera los 140 caracteres.");
        String clave=campo(d,"claveIdempotencia");
        try { if (!UUID.fromString(clave).toString().equalsIgnoreCase(clave)) throw new IllegalArgumentException(); }
        catch (IllegalArgumentException err) { fallo(400,"Identificador de operación inválido."); }
        ProveedorFinanciero.Transferencia r=BANCO.solicitarTransferencia(id,cci,beneficiario,monto,concepto,clave);
        if (r==null || r.identificador()==null || r.identificador().isBlank() || r.estado()==null)
            throw new IllegalStateException("Banco no identificó operación");
        // 'aceptada' no implica 'completada'; retornar solo el estado que declara la entidad.
        responderJson(e,202,"{\"ok\":true,\"transferencia\":{\"id\":"+json(r.identificador())+
                ",\"estado\":"+json(r.estado())+",\"referencia\":"+json(r.referenciaBancaria())+"}}");
    }
    private static void fallo(int codigo, String mensaje) { throw new Usuarios.Falta(codigo,mensaje); }
    private static void recurso(HttpExchange e, String ruta, String tipo) throws IOException {
        try(InputStream in=Main.class.getResourceAsStream(ruta)) {
            if(in==null) {responder(e,404,"No encontrado","text/plain; charset=utf-8");return;}
            byte[] bytes=in.readAllBytes();cabeceras(e);e.getResponseHeaders().set("Content-Type",tipo);
            e.sendResponseHeaders(200,bytes.length);
            try(OutputStream out=e.getResponseBody()){out.write(bytes);}
        }
    }
    private static void responderJson(HttpExchange e,int codigo,String mensaje) throws IOException {
        responder(e,codigo,mensaje,"application/json; charset=utf-8");
    }
    private static void responder(HttpExchange e,int codigo,String mensaje,String tipo) throws IOException {
        byte[] bytes=mensaje.getBytes(StandardCharsets.UTF_8);cabeceras(e);e.getResponseHeaders().set("Content-Type",tipo);
        if(codigo==204){e.sendResponseHeaders(204,-1);return;}
        e.sendResponseHeaders(codigo,bytes.length);
        try(OutputStream out=e.getResponseBody()){out.write(bytes);}
    }
    private static void cabeceras(HttpExchange e) {
        var h=e.getResponseHeaders();h.set("Cache-Control","no-store");h.set("X-Content-Type-Options","nosniff");
        h.set("X-Frame-Options","DENY");h.set("Referrer-Policy","no-referrer");
        h.set("Permissions-Policy","camera=(), microphone=(), geolocation=()");
        h.set("Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'none'");
    }
    private static String json(String s) {
        if(s==null) return "null";
        StringBuilder b=new StringBuilder("\"");
        for(char c:s.toCharArray()) {
            switch(c) {
                case '"' -> b.append("\\\""); case '\\' -> b.append("\\\\");
                case '\n' -> b.append("\\n"); case '\r' -> b.append("\\r"); case '\t' -> b.append("\\t");
                default -> { if(c<32)b.append(String.format("\\u%04x",(int)c)); else b.append(c); }
            }
        }
        return b.append('"').toString();
    }
}
