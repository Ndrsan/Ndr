import java.io.IOException;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;

/** Libro local de saldos y movimientos. No envía solicitudes a entidades externas. */
public final class ProveedorLocal implements ProveedorFinanciero {
    private static final long SALDO_INICIAL = 0;
    private static final String CABECERA = "NDR-CUENTAS-1";
    private record Saldo(long centavos, String actualizado) {}
    private record Operacion(String id, String emisor, String receptor, String cci,
            String beneficiario, String concepto, long centavos, String clave,
            String fecha, String referencia) {
        Transferencia respuesta() { return new Transferencia(id, "Registrada", referencia); }
    }
    private final Usuarios usuarios;
    private final Path archivo;
    private final FileChannel canalBloqueo;
    private final FileLock bloqueo;
    private Map<String, Saldo> saldos = new LinkedHashMap<>();
    private List<Operacion> operaciones = new ArrayList<>();
    private Map<String, Operacion> porClave = new HashMap<>();

    public ProveedorLocal(Usuarios usuarios, Path directorio) throws IOException {
        this.usuarios = usuarios;
        Files.createDirectories(directorio);
        archivo = directorio.resolve("cuentas-locales.ndr");
        Path rutaBloqueo = directorio.resolve("cuentas-locales.lock");
        canalBloqueo = FileChannel.open(rutaBloqueo, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
        FileLock adquirido;
        try { adquirido = canalBloqueo.tryLock(); }
        catch (OverlappingFileLockException e) { adquirido = null; }
        if (adquirido == null) {
            canalBloqueo.close();
            throw new IOException("Ya hay otra instancia usando este directorio de cuentas. Cierra la anterior.");
        }
        bloqueo = adquirido;
        permisos(rutaBloqueo);
        try { if (Files.exists(archivo)) cargar(); }
        catch (IOException | RuntimeException e) {
            bloqueo.release(); canalBloqueo.close();
            throw e;
        }
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try { bloqueo.release(); canalBloqueo.close(); } catch (IOException ignored) { }
        }, "ndr-cuentas-cerrar"));
    }

    @Override public String nombre() { return "NDR"; }
    @Override public boolean estaConfigurado() { return true; }
    @Override public boolean clienteVerificado(Identidad cliente) {
        return usuarios.perfilPorId(cliente.usuarioNdr()) != null;
    }
    private Usuarios.Perfil perfil(Identidad cliente) {
        Usuarios.Perfil perfil = usuarios.perfilPorId(cliente.usuarioNdr());
        if (perfil == null) throw new Usuarios.Falta(401, "Inicia sesión para continuar.");
        return perfil;
    }

    @Override public synchronized Cuenta consultarCuenta(Identidad cliente) throws IOException {
        Usuarios.Perfil perfil = perfil(cliente);
        Saldo saldo = saldos.get(perfil.id());
        if (saldo == null) {
            saldo = new Saldo(SALDO_INICIAL, Instant.now().toString());
            Map<String, Saldo> siguientes = new LinkedHashMap<>(saldos);
            siguientes.put(perfil.id(), saldo);
            guardar(siguientes, operaciones);
            saldos = siguientes;
        }
        return new Cuenta(perfil.nombre(), perfil.cci(), "PEN", soles(saldo.centavos()), saldo.actualizado());
    }

    @Override public synchronized List<Movimiento> consultarTransferencias(Identidad cliente) {
        String usuario = perfil(cliente).id();
        List<Movimiento> movimientos = new ArrayList<>();
        for (int i = operaciones.size() - 1; i >= 0 && movimientos.size() < 100; i--) {
            Operacion op = operaciones.get(i);
            if (op.emisor().equals(usuario)) {
                String detalle = "Envío a " + op.beneficiario();
                if (!op.concepto().isBlank()) detalle += " · " + op.concepto();
                movimientos.add(new Movimiento(op.id(), op.fecha(), soles(-op.centavos()).toPlainString(),
                        "PEN", "Registrada", detalle));
            } else if (op.receptor().equals(usuario)) {
                Usuarios.Perfil emisor = usuarios.perfilPorId(op.emisor());
                String detalle = "Recibido de " + (emisor == null ? "Cuenta NDR" : emisor.nombre());
                if (!op.concepto().isBlank()) detalle += " · " + op.concepto();
                movimientos.add(new Movimiento(op.id(), op.fecha(), "+" + soles(op.centavos()).toPlainString(),
                        "PEN", "Registrada", detalle));
            }
        }
        return movimientos;
    }

    @Override public synchronized Transferencia solicitarTransferencia(Identidad cliente, String cci,
            String beneficiario, BigDecimal monto, String concepto, String clave) throws IOException {
        Usuarios.Perfil emisor = perfil(cliente);
        long centavos;
        try { centavos = monto.movePointRight(2).longValueExact(); }
        catch (ArithmeticException e) { throw new Usuarios.Falta(400, "Introduce un monto válido en soles."); }
        if (centavos <= 0 || centavos > 5_000_000) throw new Usuarios.Falta(400, "Monto fuera del máximo permitido.");
        String llave = emisor.id() + ":" + clave.toLowerCase(Locale.ROOT);
        Operacion anterior = porClave.get(llave);
        if (anterior != null) {
            if (!anterior.cci().equals(cci) || !anterior.beneficiario().equals(beneficiario)
                    || !anterior.concepto().equals(concepto) || anterior.centavos() != centavos)
                throw new Usuarios.Falta(409, "El identificador ya se utilizó con otros datos.");
            return anterior.respuesta();
        }
        if (emisor.cci().equals(cci)) throw new Usuarios.Falta(400, "Elige una cuenta de destino diferente a la tuya.");
        String ahora = Instant.now().toString();
        Saldo disponible = saldos.getOrDefault(emisor.id(), new Saldo(SALDO_INICIAL, ahora));
        if (disponible.centavos() < centavos) throw new Usuarios.Falta(422, "Saldo insuficiente para esta transferencia.");
        Map<String, Saldo> siguientes = new LinkedHashMap<>(saldos);
        siguientes.put(emisor.id(), new Saldo(disponible.centavos() - centavos, ahora));
        Usuarios.Perfil receptor = usuarios.perfilPorCci(cci);
        if (receptor != null) {
            long saldoReceptor = siguientes.getOrDefault(receptor.id(), new Saldo(SALDO_INICIAL, ahora)).centavos();
            try { siguientes.put(receptor.id(), new Saldo(Math.addExact(saldoReceptor, centavos), ahora)); }
            catch (ArithmeticException e) { throw new Usuarios.Falta(422, "La cuenta de destino alcanzó su límite de saldo."); }
        }
        String id = UUID.randomUUID().toString();
        Operacion nueva = new Operacion(id, emisor.id(), receptor == null ? "" : receptor.id(), cci,
                beneficiario, concepto, centavos, clave.toLowerCase(Locale.ROOT), ahora,
                "NDR-" + id.replace("-", "").toUpperCase(Locale.ROOT));
        List<Operacion> registro = new ArrayList<>(operaciones);
        registro.add(nueva);
        guardar(siguientes, registro);
        // Solo publicar en memoria después de guardar el saldo y su movimiento juntos.
        saldos = siguientes;
        operaciones = registro;
        porClave.put(llave, nueva);
        return nueva.respuesta();
    }

    private void guardar(Map<String, Saldo> cuentas, List<Operacion> registro) throws IOException {
        StringBuilder contenido = new StringBuilder(CABECERA).append('\n');
        for (var cuenta : cuentas.entrySet()) {
            contenido.append("C|").append(enc(cuenta.getKey())).append('|')
                    .append(cuenta.getValue().centavos()).append('|').append(enc(cuenta.getValue().actualizado())).append('\n');
        }
        for (Operacion op : registro) {
            contenido.append("T|").append(enc(op.id())).append('|').append(enc(op.emisor())).append('|')
                    .append(enc(op.receptor())).append('|').append(enc(op.cci())).append('|')
                    .append(enc(op.beneficiario())).append('|').append(enc(op.concepto())).append('|')
                    .append(op.centavos()).append('|').append(enc(op.clave())).append('|')
                    .append(enc(op.fecha())).append('|').append(enc(op.referencia())).append('\n');
        }
        Path temporal = Files.createTempFile(archivo.getParent(), "ndr-cuentas-", ".tmp");
        try {
            permisos(temporal);
            try (FileChannel salida = FileChannel.open(temporal, StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING)) {
                ByteBuffer bytes = StandardCharsets.UTF_8.encode(contenido.toString());
                while (bytes.hasRemaining()) salida.write(bytes);
                salida.force(true);
            }
            try { Files.move(temporal, archivo, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temporal, archivo, StandardCopyOption.REPLACE_EXISTING); }
            permisos(archivo);
        } finally { Files.deleteIfExists(temporal); }
    }

    private void cargar() throws IOException {
        List<String> lineas = Files.readAllLines(archivo, StandardCharsets.UTF_8);
        if (lineas.isEmpty() || !CABECERA.equals(lineas.get(0))) throw new IOException("Archivo de cuentas inválido. No se restablecerán los saldos.");
        Map<String, Saldo> cuentas = new LinkedHashMap<>();
        List<Operacion> registro = new ArrayList<>();
        Map<String, Operacion> claves = new HashMap<>();
        Set<String> ids = new HashSet<>();
        try {
            for (int i = 1; i < lineas.size(); i++) {
                String[] campos = lineas.get(i).split("\\|", -1);
                if (campos.length == 4 && "C".equals(campos[0])) {
                    String id = dec(campos[1]);
                    UUID.fromString(id);
                    long centavos = Long.parseLong(campos[2]);
                    String fecha = dec(campos[3]); Instant.parse(fecha);
                    if (centavos < 0 || cuentas.putIfAbsent(id, new Saldo(centavos, fecha)) != null)
                        throw new IllegalArgumentException();
                } else if (campos.length == 11 && "T".equals(campos[0])) {
                    Operacion op = new Operacion(dec(campos[1]), dec(campos[2]), dec(campos[3]),
                            dec(campos[4]), dec(campos[5]), dec(campos[6]), Long.parseLong(campos[7]),
                            dec(campos[8]), dec(campos[9]), dec(campos[10]));
                    UUID.fromString(op.id()); UUID.fromString(op.emisor()); UUID.fromString(op.clave());
                    if (!op.receptor().isEmpty()) UUID.fromString(op.receptor());
                    Instant.parse(op.fecha());
                    if (op.centavos() <= 0 || op.centavos() > 5_000_000 || !op.cci().matches("[0-9]{20}")
                            || op.referencia().isBlank() || !ids.add(op.id())
                            || claves.putIfAbsent(op.emisor() + ":" + op.clave(), op) != null)
                        throw new IllegalArgumentException();
                    registro.add(op);
                } else throw new IllegalArgumentException();
            }
            for (Operacion op : registro) {
                if (!cuentas.containsKey(op.emisor()) || (!op.receptor().isEmpty() && !cuentas.containsKey(op.receptor())))
                    throw new IllegalArgumentException();
            }
        } catch (RuntimeException e) { throw new IOException("Archivo de cuentas dañado. Conserva el archivo y revisa su copia de seguridad.", e); }
        saldos = cuentas; operaciones = registro; porClave = claves;
    }
    private static BigDecimal soles(long centavos) { return BigDecimal.valueOf(centavos, 2); }
    private static String enc(String valor) { return Base64.getUrlEncoder().withoutPadding().encodeToString(valor.getBytes(StandardCharsets.UTF_8)); }
    private static String dec(String valor) { return new String(Base64.getUrlDecoder().decode(valor), StandardCharsets.UTF_8); }
    private static void permisos(Path archivo) {
        try { Files.setPosixFilePermissions(archivo, java.nio.file.attribute.PosixFilePermissions.fromString("rw-------")); }
        catch (IOException | UnsupportedOperationException ignored) { }
    }
}
