"use strict";
const $ = (id) => document.getElementById(id);
let csrf = null;
let usuario = null;
let bancario = false;
let envioPendiente = null;
let envioPreparado = null;
let modoCuenta = "local";
let saldoActual = null;
let saldoOculto = false;
let textoSaldo = "Consultando…";
let generacionSesion = 0;
let desafioOtp = null;
let tipoOtp = null;
let cciVisible = false;
const preferenciasSaldo = new Map();

function claveSaldo() { return "ndr:saldo-oculto:" + (usuario?.id || usuario?.correo || ""); }
function cargarPreferenciaSaldo() {
  const clave = claveSaldo();
  try { saldoOculto = localStorage.getItem(clave) === "1"; }
  catch { saldoOculto = preferenciasSaldo.get(clave) || false; }
}
function pintarSaldo() {
  $("balanceValue").textContent = saldoActual === null ? textoSaldo : (saldoOculto ? "••••••" : saldoActual);
  $("toggleBalance").disabled = saldoActual === null;
  $("toggleBalance").setAttribute("aria-pressed", String(saldoOculto));
  $("toggleBalance").setAttribute("aria-label", saldoOculto ? "Mostrar saldo" : "Ocultar saldo");
  $("balanceToggleText").textContent = saldoOculto ? "Mostrar" : "Ocultar";
  $("balanceEye").toggleAttribute("hidden", saldoOculto);
  $("balanceEyeOff").toggleAttribute("hidden", !saldoOculto);
}
function limpiarSaldo(texto = "Consultando…") {
  saldoActual = null; textoSaldo = texto; pintarSaldo();
}
$("toggleBalance").addEventListener("click", () => {
  if (saldoActual === null || !usuario) return;
  saldoOculto = !saldoOculto;
  preferenciasSaldo.set(claveSaldo(), saldoOculto);
  try { localStorage.setItem(claveSaldo(), saldoOculto ? "1" : "0"); } catch { }
  pintarSaldo();
});
function moneda(valor, codigo = "PEN") {
  return new Intl.NumberFormat("es-PE", {style:"currency", currency:codigo}).format(Number(valor));
}
function fechaVisible(valor) {
  const fecha = new Date(valor);
  return Number.isNaN(fecha.getTime()) ? "—" : fecha.toLocaleString("es-PE", {timeZone:"America/Lima"});
}

async function api(ruta, opciones = {}) {
  let respuesta;
  try {
    respuesta = await fetch(ruta, {credentials:"same-origin", cache:"no-store", ...opciones});
  } catch {
    throw new Error("No se pudo conectar con NDR. Comprueba que iniciar.bat sigue abierto y vuelve a intentarlo.");
  }
  let datos;
  try { datos = await respuesta.json(); }
  catch { throw new Error("No se pudo interpretar la respuesta del servidor."); }
  if (!respuesta.ok || !datos.ok) {
    const error = new Error(datos.mensaje || "No fue posible completar la solicitud.");
    error.status = respuesta.status;
    throw error;
  }
  return datos;
}
function post(ruta, cuerpo, sesion = false) {
  const headers = {"Content-Type":"application/json", "X-NDR-Request":"1"};
  if (sesion) headers["X-NDR-CSRF"] = csrf || "";
  return api(ruta, {method:"POST", headers, body:JSON.stringify(cuerpo)});
}
function estadoMensaje(id, texto, ok = false) {
  const e = $(id);
  e.textContent = texto;
  e.classList.toggle("good", ok);
}
function formatoCci(cci) {
  if (!cci) return "—";
  return String(cci).replace(/\D/g, "").replace(/(.{4})/g, "$1 ").trim();
}
function aplicarDatosUsuario() {
  if (!usuario) return;
  const nombre = usuario.nombre || "bienvenido";
  $("firstName").textContent = nombre.split(/\s+/)[0];
  $("profileName").textContent = nombre;
  $("profileEmail").textContent = usuario.correo || "—";
  $("profilePhone").textContent = usuario.telefono || "—";
  const oculto = usuario.cciOculto || "•••• •••• •••• ••••";
  $("profileCciFull").textContent = cciVisible && usuario.cci ? formatoCci(usuario.cci) : oculto;
  $("profileCciPreview").textContent = oculto;
  $("transferOwnCci").textContent = oculto;
  $("toggleCci").textContent = cciVisible ? "Ocultar" : "Mostrar";
  $("toggleCci").setAttribute("aria-pressed", String(cciVisible));
}
function modoRegistro(registro) {
  desafioOtp = null; tipoOtp = null;
  $("otpPanel").hidden = true;
  $("otpPanel").reset();
  $("authTabs").hidden = false;
  $("loginForm").hidden = registro;
  $("registerForm").hidden = !registro;
  $("showLogin").classList.toggle("active", !registro);
  $("showRegister").classList.toggle("active", registro);
  $("showLogin").setAttribute("aria-pressed", String(!registro));
  $("showRegister").setAttribute("aria-pressed", String(registro));
  $("authTitle").textContent = registro ? "Crear tu cuenta" : "Iniciar sesión";
  $("authSubtitle").textContent = registro ? "Regístrate con correo, celular y DNI. Verificaremos tu contacto." : "Ingresa con correo o celular, DNI y contraseña.";
  estadoMensaje("authMessage", "");
}
$("showLogin").addEventListener("click", () => modoRegistro(false));
$("showRegister").addEventListener("click", () => modoRegistro(true));

async function entrar(datos) {
  if (!datos?.csrf || !datos?.usuario?.nombre) throw new Error("Respuesta de sesión incompleta. Intenta entrar de nuevo.");
  generacionSesion++;
  csrf = datos.csrf;
  usuario = datos.usuario;
  document.body.classList.remove("modo-acceso");
  cciVisible = false;
  cargarPreferenciaSaldo();
  limpiarSaldo();
  aplicarDatosUsuario();
  $("bankApp").hidden = false;
  $("authView").hidden = true;
  mostrarVista("inicio", true);
  await consultarBanco();
}
function salirDeVista() {
  generacionSesion++;
  document.body.classList.add("modo-acceso");
  csrf = null; usuario = null; bancario = false; envioPendiente = null; envioPreparado = null;
  desafioOtp = null; tipoOtp = null; cciVisible = false;
  $("bankApp").hidden = true;
  $("authView").hidden = false;
  $("loginForm").reset(); $("registerForm").reset(); $("otpPanel").reset();
  modoRegistro(false);
  $("sessionMessage").hidden = true;
  saldoOculto = false; modoCuenta = "local";
  limpiarSaldo("—");
  $("balanceNote").textContent = "";
  $("transferForm").reset();
  $("transferResult").hidden = true;
  $("transferSubmit").disabled = true;
  $("confirmDialog").close();
  for (const id of ["firstName", "profileName", "profileEmail", "profilePhone", "profileCciFull", "profileCciPreview", "transferOwnCci", "bankAccount", "bankProvider", "profileBank", "confirmBeneficiary", "confirmCci", "confirmAmount", "resultBeneficiary", "resultCci", "resultAmount", "resultDate", "resultOperation", "resultReference", "resultState", "transferResultText"]) $(id).textContent = "—";
  estadoMensaje("transferMessage", ""); estadoMensaje("movementMessage", "");
  vacio("Todavía no hay movimientos.");
}
function mostrarVerificacion(respuesta, tipo) {
  if (!respuesta?.desafio) throw new Error("No se pudo iniciar la verificación.");
  desafioOtp = respuesta.desafio;
  tipoOtp = tipo;
  $("authTabs").hidden = true;
  $("loginForm").hidden = true;
  $("registerForm").hidden = true;
  $("otpPanel").hidden = false;
  $("authTitle").textContent = "Código de seguridad";
  $("authSubtitle").textContent = "Último paso para proteger tu cuenta";
  $("otpDestination").textContent = "🎄 Código solicitado para " + (respuesta.destino || "tu contacto registrado") + ".";
  estadoMensaje("authMessage", respuesta.mensaje || "Revisa tu correo o celular.", true);
  $("otpCode").focus();
}
$("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault(); $("loginSubmit").disabled = true;
  estadoMensaje("authMessage", "Validando credenciales y preparando el código…");
  try {
    const d = await post("/api/auth/login", {
      identificador:$("loginId").value, dni:$("loginDni").value,
      password:$("loginPassword").value, canal:$("loginChannel").value
    });
    $("loginPassword").value = "";
    mostrarVerificacion(d, "login");
  } catch (err) { estadoMensaje("authMessage", err.message); }
  finally { $("loginSubmit").disabled = false; }
});
$("registerForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  if ($("registerPassword").value !== $("registerRepeat").value)
    return estadoMensaje("authMessage", "Las contraseñas no coinciden.");
  $("registerSubmit").disabled = true;
  estadoMensaje("authMessage", "Preparando tu verificación…");
  try {
    const d = await post("/api/auth/registro", {
      nombre:$("registerName").value, correo:$("registerEmail").value,
      telefono:$("registerPhone").value, dni:$("registerDni").value,
      password:$("registerPassword").value, canal:$("registerChannel").value
    });
    $("registerPassword").value = "";
    $("registerRepeat").value = "";
    mostrarVerificacion(d, "registro");
  } catch (err) { estadoMensaje("authMessage", err.message); }
  finally { $("registerSubmit").disabled = false; }
});
$("otpPanel").addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!desafioOtp) return;
  $("otpSubmit").disabled = true;
  estadoMensaje("authMessage", "Comprobando código…");
  try {
    const r = await post("/api/auth/verificar", {desafio:desafioOtp, codigo:$("otpCode").value});
    if (tipoOtp === "registro") {
      const correo = $("registerEmail").value.trim();
      const dni = $("registerDni").value.trim();
      $("registerForm").reset();
      modoRegistro(false);
      $("loginId").value = correo;
      $("loginDni").value = dni;
      estadoMensaje("authMessage", r.mensaje || "Cuenta verificada. Inicia sesión.", true);
    } else {
      desafioOtp = null; tipoOtp = null;
      $("otpPanel").reset();
      await entrar(r);
      $("sessionMessage").hidden = true;
    }
  } catch (err) {
    estadoMensaje("authMessage", err.message);
    $("otpCode").value = "";
  } finally { $("otpSubmit").disabled = false; }
});
$("otpCancel").addEventListener("click", () => {
  const registro = tipoOtp === "registro";
  modoRegistro(registro);
});
$("toggleCci").addEventListener("click", async () => {
  if (!usuario) return;
  if (cciVisible) {
    cciVisible = false;
    delete usuario.cci;
    aplicarDatosUsuario();
    return;
  }
  $("toggleCci").disabled = true;
  try {
    const r = await post("/api/identidad/cci", {}, true);
    if (!usuario) return;
    usuario.cci = r.cci;
    cciVisible = true;
    aplicarDatosUsuario();
  } catch (err) { estadoMensaje("authMessage", err.message); }
  finally { $("toggleCci").disabled = false; }
});
async function cerrarSesion() {
  try { await post("/api/auth/logout", {}, true); }
  catch { }
  salirDeVista();
}
$("logoutButton").addEventListener("click", cerrarSesion);
$("profileLogout").addEventListener("click", cerrarSesion);

function animarPantalla(pantalla) {
  pantalla.classList.remove("screen-animate");
  void pantalla.offsetWidth;
  pantalla.classList.add("screen-animate");
}
function mostrarVista(vista, instantanea = false) {
  if (!usuario) return;
  document.querySelectorAll(".screen").forEach(e => {
    const activa = e.id === vista;
    e.classList.toggle("active", activa);
    if (activa) animarPantalla(e);
  });
  const movimientoReducido = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  window.scrollTo({top:0, behavior:instantanea || movimientoReducido ? "instant" : "smooth"});
  if (vista === "historial") cargarMovimientos();
}
document.querySelectorAll("[data-view]").forEach(b => b.addEventListener("click", () => mostrarVista(b.dataset.view)));
function deshabilitarBanco(nombre = "Cuenta no disponible", detalle = "Vuelve a actualizar tu cuenta.", mostrarAviso = true) {
  bancario = false;
  $("connectionPill").classList.remove("connected");
  $("connectionText").textContent = nombre;
  $("integrationStatus").textContent = nombre;
  $("transferSubmit").disabled = true;
  $("bankNotice").hidden = !mostrarAviso;
  $("bankNoticeTitle").textContent = nombre;
  $("bankNoticeText").textContent = detalle;
  $("bankProvider").textContent = "—";
  $("bankAccount").textContent = usuario?.cciOculto || "—";
  limpiarSaldo(mostrarAviso ? "No disponible" : "Consultando…");
  $("balanceNote").textContent = detalle;
  $("profileBank").textContent = nombre;
}
async function consultarBanco() {
  const generacion = generacionSesion;
  deshabilitarBanco("Consultando cuenta…", "Actualizando tu información", false);
  try {
    const d = await api("/api/estado");
    if (generacion !== generacionSesion || !usuario) return;
    modoCuenta = d.modo || "externo";
    if (!d.conectado) return deshabilitarBanco("Cuenta no disponible", "El servicio de cuenta no está conectado. Vuelve a intentarlo más tarde.");
    if (!d.autenticado) {
      deshabilitarBanco("Validación pendiente", "Tu proveedor debe autorizar el acceso a la cuenta.");
      $("bankProvider").textContent = d.proveedor || "—";
      return;
    }
    bancario = true;
    $("bankProvider").textContent = d.proveedor || "NDR";
    $("connectionPill").classList.add("connected");
    $("connectionText").textContent = modoCuenta === "local" ? "Cuenta activa" : "Banco verificado";
    $("integrationStatus").textContent = modoCuenta === "local" ? "Cuenta NDR activa" : "Entidad verificada";
    $("bankNotice").hidden = true;
    $("profileBank").textContent = modoCuenta === "local" ? "Cuenta NDR activa" : "Validada por la entidad";
    await cargarCuenta();
    if (generacion === generacionSesion) $("transferSubmit").disabled = !bancario || Boolean(envioPendiente);
  } catch (err) {
    if (generacion !== generacionSesion) return;
    if (err.status === 401) return salirDeVista();
    deshabilitarBanco("Cuenta no disponible", err.message);
  }
}
async function cargarCuenta() {
  if (!bancario) return;
  const generacion = generacionSesion;
  limpiarSaldo();
  try {
    const {cuenta} = await api("/api/cuenta");
    if (generacion !== generacionSesion || !usuario) return;
    const saldo = Number(cuenta.saldo);
    if (cuenta.saldo == null || String(cuenta.saldo).trim() === "" || !Number.isFinite(saldo)) throw new Error("No se pudo consultar el saldo. Actualiza tu cuenta.");
    const numero = cuenta.numero || usuario.cciOculto || "—";
    $("bankAccount").textContent = /^[0-9]{20}$/.test(String(numero)) ? "•••• •••• •••• •••• " + String(numero).slice(-4) : numero;
    saldoActual = moneda(saldo, cuenta.moneda || "PEN");
    pintarSaldo();
    $("balanceNote").textContent = cuenta.actualizadoEn ? "Actualizado: " + fechaVisible(cuenta.actualizadoEn) : "Cuenta actualizada";
  } catch (err) {
    if (generacion !== generacionSesion) return;
    if (err.status === 401) return salirDeVista();
    deshabilitarBanco("Cuenta no disponible", err.message);
  }
}
$("refreshAccount").addEventListener("click", consultarBanco);
function celda(tr, valor) { const td = document.createElement("td"); td.textContent = valor; tr.append(td); }
function vacio(texto) {
  const tr = document.createElement("tr"); const td = document.createElement("td");
  td.colSpan = 4; td.className = "empty"; td.textContent = texto; tr.append(td);
  $("movementRows").replaceChildren(tr);
}
async function cargarMovimientos() {
  if (!bancario) { vacio("Actualiza tu cuenta para consultar sus movimientos."); return; }
  const generacion = generacionSesion;
  vacio("Consultando operaciones…");
  try {
    const {movimientos} = await api("/api/movimientos");
    if (generacion !== generacionSesion || !usuario) return;
    $("movementRows").replaceChildren();
    if (!movimientos.length) return vacio("Todavía no tienes transferencias registradas.");
    for (const mov of movimientos) {
      const tr = document.createElement("tr");
      for (const v of [mov.fecha ? fechaVisible(mov.fecha) : "—", mov.descripcion || "Transferencia", mov.monto ? moneda(mov.monto, mov.moneda || "PEN") : "—", mov.estado || "Por consultar"]) celda(tr, v);
      $("movementRows").append(tr);
    }
    estadoMensaje("movementMessage", "");
  } catch (err) {
    if (generacion !== generacionSesion) return;
    if (err.status === 401) return salirDeVista();
    vacio("No se pudo consultar el historial."); estadoMensaje("movementMessage", err.message);
  }
}
$("refreshMovements").addEventListener("click", cargarMovimientos);
function montoValido(t) {
  if (!/^\d{1,6}(\.\d{1,2})?$/.test(t)) return false;
  const n = Number(t); return Number.isFinite(n) && n > 0 && n <= 50000;
}
$("transferForm").addEventListener("submit", (e) => {
  e.preventDefault(); $("transferResult").hidden = true;
  if (!bancario) return estadoMensaje("transferMessage", "Actualiza tu cuenta antes de transferir.");
  if (envioPendiente) return estadoMensaje("transferMessage", "Hay una operación pendiente de verificar. Revisa el historial antes de volver a enviarla.");
  const datos = {beneficiario:$("beneficiary").value.trim(), cci:$("cci").value.trim(), monto:$("transferAmount").value.trim().replace(",", "."), concepto:$("concept").value.trim()};
  if (!/^[0-9]{20}$/.test(datos.cci)) return estadoMensaje("transferMessage", "El CCI debe tener 20 dígitos.");
  if (datos.beneficiario.length < 3 || datos.beneficiario.length > 100) return estadoMensaje("transferMessage", "Revisa el beneficiario.");
  if (!montoValido(datos.monto)) return estadoMensaje("transferMessage", "Introduce un monto de S/ 0.01 a S/ 50,000.00.");
  if (datos.concepto.length > 140) return estadoMensaje("transferMessage", "El concepto admite hasta 140 caracteres.");
  if (datos.cci === usuario?.cci) return estadoMensaje("transferMessage", "Elige un CCI distinto al de tu cuenta.");
  envioPreparado = {...datos, claveIdempotencia:crypto.randomUUID()};
  $("confirmBeneficiary").textContent = datos.beneficiario;
  $("confirmCci").textContent = formatoCci(datos.cci);
  $("confirmAmount").textContent = "S/ " + Number(datos.monto).toFixed(2);
  $("confirmDialog").showModal();
});
$("cancelTransfer").addEventListener("click", () => { $("confirmDialog").close(); envioPreparado = null; });
$("confirmDialog").addEventListener("close", () => { if (!envioPendiente) envioPreparado = null; });
$("confirmTransfer").addEventListener("click", async () => {
  if (!envioPreparado || !bancario || envioPendiente) return;
  const generacion = generacionSesion;
  envioPendiente = envioPreparado; envioPreparado = null;
  const operacion = envioPendiente;
  $("confirmDialog").close(); $("transferSubmit").disabled = true;
  $("confirmTransfer").disabled = true;
  estadoMensaje("transferMessage", "Procesando tu transferencia…");
  try {
    const {transferencia} = await post("/api/transferencias", operacion, true);
    if (generacion !== generacionSesion || !usuario) return;
    if (!transferencia?.id || !transferencia?.estado) throw new Error("No se pudo confirmar el estado de la operación. Consulta el historial.");
    $("transferResultTitle").textContent = modoCuenta === "local" ? "Transferencia registrada" : "Respuesta de la entidad";
    $("transferResultText").textContent = modoCuenta === "local" ? "Transferencia registrada. Revisa los detalles de la operación." : "La entidad respondió a la solicitud. Revisa el estado informado.";
    $("resultBeneficiary").textContent = operacion.beneficiario;
    $("resultCci").textContent = formatoCci(operacion.cci);
    $("resultAmount").textContent = moneda(operacion.monto);
    $("resultDate").textContent = fechaVisible(transferencia.fecha || new Date().toISOString());
    $("resultOperation").textContent = transferencia.id;
    $("resultReference").textContent = transferencia.referencia || "—";
    $("resultState").textContent = transferencia.estado;
    $("transferResult").hidden = false;
    estadoMensaje("transferMessage", "Operación registrada correctamente.", true);
    envioPendiente = null; $("transferForm").reset();
    await cargarCuenta();
  } catch (err) {
    if (generacion !== generacionSesion) return;
    if (err.status === 401) return salirDeVista();
    estadoMensaje("transferMessage", err.message + (err.status >= 400 && err.status < 500 ? "" : " Verifica el historial antes de volver a enviar la operación."));
    if (err.status >= 400 && err.status < 500) envioPendiente = null;
  } finally {
    if (generacion === generacionSesion) $("transferSubmit").disabled = !bancario || Boolean(envioPendiente);
    $("confirmTransfer").disabled = false;
  }
});

function activarTapAnimations() {
  document.addEventListener("click", (event) => {
    const boton = event.target.closest(".pressable, .tile, .btn, .auth-tab, .logout");
    if (!boton) return;
    boton.classList.remove("tap-pop");
    void boton.offsetWidth;
    boton.classList.add("tap-pop");
  });
}

(async function iniciar() {
  activarTapAnimations();
  // Los formularios solo cambian de pantalla tras una respuesta del servidor.
  // Ningún evento de escritura navega o cierra ventanas.
  document.querySelectorAll("#authView form").forEach(form => {
    form.addEventListener("invalid", () => document.body.classList.add("modo-acceso"), true);
  });
  const generacion = generacionSesion;
  try {
    const d = await api("/api/auth/sesion");
    if (generacion === generacionSesion) await entrar(d);
  } catch { if (generacion === generacionSesion) salirDeVista(); }
})();

window.addEventListener("unhandledrejection", () => {
  if (!usuario) estadoMensaje("authMessage", "Hubo un error inesperado. La página permanece abierta; actualiza e inténtalo de nuevo.");
});

/* La decoración se pausa fuera de la pestaña y respeta la preferencia del sistema. */
(function prepararEfectosNavidenos() {
  const boton = document.getElementById("toggleMotion");
  if (!boton) return;
  const preferencia = window.matchMedia("(prefers-reduced-motion: reduce)");
  const clave = "ndr:holiday-effects-paused";
  let pausado = false;
  try { pausado = localStorage.getItem(clave) === "1"; } catch { }
  function actualizar() {
    const reducido = preferencia.matches;
    document.body.classList.toggle("effects-paused", pausado || reducido || document.hidden);
    boton.disabled = reducido;
    boton.setAttribute("aria-pressed", String(pausado || reducido));
    boton.setAttribute("aria-label", reducido ? "Movimiento reducido activado por el sistema" : pausado ? "Reanudar efectos navideños" : "Pausar efectos navideños");
    boton.querySelector(".motion-label").textContent = reducido ? "Movimiento reducido" : pausado ? "Reanudar efectos" : "Pausar efectos";
    boton.querySelector("path").setAttribute("d", pausado || reducido ? "m7 4 8 6-8 6Z" : "M7 5v10M13 5v10");
  }
  boton.addEventListener("click", () => {
    pausado = !pausado;
    try { localStorage.setItem(clave, pausado ? "1" : "0"); } catch { }
    actualizar();
  });
  document.addEventListener("visibilitychange", actualizar);
  if (preferencia.addEventListener) preferencia.addEventListener("change", actualizar);
  else preferencia.addListener(actualizar);
  actualizar();
})();
