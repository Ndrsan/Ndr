# Restablece SOLO las cuentas, DNI y movimientos LOCALES de NDR.
# No modifica Gmail, Resend, el sistema Windows ni otros archivos.
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
Write-Host ''
Write-Host '=============================================='
Write-Host ' NDR | LIMPIAR CUENTAS LOCALES'
Write-Host '=============================================='
Write-Host 'Se borraran DEFINITIVAMENTE perfiles, DNI vinculados, CCI, saldos y movimientos guardados en este equipo.' -ForegroundColor Yellow
Write-Host 'La clave API de Resend guardada (si existe) NO se borrara.'
Write-Host ''

# Nunca borrar mientras el servidor utiliza los archivos. Si hay un proceso
# escuchando en uno de los puertos usados por NDR, primero hay que cerrarlo.
$puertos = @(18083)
if ($env:PORT -match '^\d{1,5}$') {
    $alternativo = [int]$env:PORT
    if ($alternativo -gt 0 -and $alternativo -le 65535 -and $alternativo -ne 18083) {
        $puertos += $alternativo
    }
}
foreach ($p in $puertos) {
    $cliente = New-Object System.Net.Sockets.TcpClient
    try {
        $pendiente = $cliente.BeginConnect('127.0.0.1', $p, $null, $null)
        if ($pendiente.AsyncWaitHandle.WaitOne(400)) {
            try {
                $cliente.EndConnect($pendiente)
                Write-Host "ERROR: hay un servidor abierto en el puerto $p. Cierra iniciar.bat y vuelve a intentar." -ForegroundColor Red
                exit 2
            } catch [System.Net.Sockets.SocketException] { }
        }
    } finally {
        $cliente.Close()
    }
}

$rutas = New-Object 'System.Collections.Generic.List[string]'
if (-not [string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
    $rutas.Add((Join-Path $env:LOCALAPPDATA 'NDR\datos'))
}
$rutas.Add((Join-Path $PSScriptRoot 'data'))
if (-not [string]::IsNullOrWhiteSpace($env:NDR_DATA_DIR)) {
    $rutas.Add($env:NDR_DATA_DIR)
}
$archivos = @('usuarios.ndr', 'cuentas-locales.ndr', 'dni.key', 'cuentas-locales.lock')
$unicos = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
$encontrados = New-Object 'System.Collections.Generic.List[string]'
foreach ($ruta in $rutas) {
    $rutaCompleta = [IO.Path]::GetFullPath($ruta)
    if (-not $unicos.Add($rutaCompleta) -or -not (Test-Path -LiteralPath $rutaCompleta -PathType Container)) { continue }
    foreach ($nombre in $archivos) {
        $f = Join-Path $rutaCompleta $nombre
        if (Test-Path -LiteralPath $f -PathType Leaf) { $encontrados.Add($f) }
    }
    foreach ($f in (Get-ChildItem -LiteralPath $rutaCompleta -File -ErrorAction Stop)) {
        if ($f.Name -match '^ndr-(?:cuentas-)?[^\\/]*\.tmp$') { $encontrados.Add($f.FullName) }
    }
}
# Protección adicional: abortar si una instancia Java mantiene el libro abierto,
# incluso si el usuario la inició en otro puerto.
foreach ($ruta in $rutas) {
    $rutaCompleta = [IO.Path]::GetFullPath($ruta)
    $archivoBloqueo = Join-Path $rutaCompleta 'cuentas-locales.lock'
    if (Test-Path -LiteralPath $archivoBloqueo -PathType Leaf) {
        try {
            $verificador = [System.IO.File]::Open($archivoBloqueo, [System.IO.FileMode]::Open, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
            $verificador.Dispose()
        } catch {
            Write-Host 'ERROR: el directorio NDR sigue en uso. Cierra todas las ventanas iniciar.bat antes de borrar.' -ForegroundColor Red
            exit 2
        }
    }
}
if ($encontrados.Count -eq 0) {
    Write-Host 'No se encontraron cuentas locales en los directorios habituales. NDR ya esta limpio.' -ForegroundColor Green
    exit 0
}
Write-Host 'Archivos de NDR que se eliminaran:'
foreach ($f in $encontrados) { Write-Host " - $f" }
Write-Host ''
$confirmacion = Read-Host 'Para confirmar, escribe exactamente BORRAR'
if ($confirmacion -cne 'BORRAR') {
    Write-Host 'Cancelado: no se borro ningun archivo.' -ForegroundColor Yellow
    exit 0
}
try {
    foreach ($f in $encontrados) { Remove-Item -LiteralPath $f -Force -ErrorAction Stop }
    Write-Host ''
    Write-Host 'LISTO: cuentas, CCI, DNI vinculados, saldos y movimientos locales eliminados.' -ForegroundColor Green
    Write-Host 'Ahora ejecuta iniciar.bat, luego ABRIR_NDR.bat y crea una cuenta nueva.'
} catch {
    Write-Host 'No fue posible terminar la limpieza. Cierra NDR y revisa los permisos de la carpeta.' -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 3
}
