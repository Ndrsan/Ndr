@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title NDR 3.6.1 - CODIGOS POR RESEND
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0iniciar.ps1"
set "RESULTADO=%ERRORLEVEL%"
if not "%RESULTADO%"=="0" (
 echo.
 echo NDR se detuvo con codigo %RESULTADO%.
)
echo.
pause
exit /b %RESULTADO%
