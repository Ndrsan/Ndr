@echo off
setlocal EnableExtensions
rem Abrir NDR en una ventana aislada de Microsoft Edge (sin extensiones
rem ni aceleracion por GPU). Evita interferencias de Brave/Chrome al escribir.
set "NDR_PUERTO=18083"
if defined PORT set "NDR_PUERTO=%PORT%"
set "NDR_URL=http://127.0.0.1:%NDR_PUERTO%/"
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" set "EDGE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE%" (
  echo Microsoft Edge no esta disponible. Abriendo el navegador predeterminado.
  start "" "%NDR_URL%"
  exit /b 0
)
set "NDR_PERFIL=%LOCALAPPDATA%\NDR\NavegadorEstable"
if not defined LOCALAPPDATA set "NDR_PERFIL=%TEMP%\NDR\NavegadorEstable"
if not exist "%NDR_PERFIL%" mkdir "%NDR_PERFIL%" >nul 2>nul
start "" "%EDGE%" --user-data-dir="%NDR_PERFIL%" --no-first-run --no-default-browser-check --disable-extensions --disable-gpu --app="%NDR_URL%"
exit /b 0
