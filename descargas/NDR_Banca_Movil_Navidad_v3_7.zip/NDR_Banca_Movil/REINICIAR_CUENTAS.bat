@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title NDR - Reiniciar cuentas locales
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0REINICIAR_CUENTAS.ps1"
set "RESULTADO=%ERRORLEVEL%"
echo.
pause
exit /b %RESULTADO%
