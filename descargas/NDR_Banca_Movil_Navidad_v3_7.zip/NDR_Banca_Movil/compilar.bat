@echo off
setlocal
cd /d "%~dp0"
where javac >nul 2>nul
if errorlevel 1 (
 echo Necesitas JDK 17 o superior para compilar.
 pause
 exit /b 1
)
if exist "target\classes" rmdir /s /q "target\classes"
mkdir "target\classes"
javac --release 17 -encoding UTF-8 -d "target\classes" *.java
if errorlevel 1 (echo ERROR al compilar. & pause & exit /b 1)
copy /y index.html "target\classes\index.html" >nul
copy /y style.css "target\classes\style.css" >nul
copy /y app.js "target\classes\app.js" >nul
if not exist "target\classes\assets" mkdir "target\classes\assets"
copy /y "assets\banca-movil.png" "target\classes\assets\banca-movil.png" >nul
jar --create --file "target\banca-movil.jar" --main-class Main -C "target\classes" .
if errorlevel 1 (echo ERROR al crear JAR. & pause & exit /b 1)
rmdir /s /q "target\classes"
echo NDR compilado correctamente.
pause
