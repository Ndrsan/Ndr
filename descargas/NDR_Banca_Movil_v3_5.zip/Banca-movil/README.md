# NDR · Banca Móvil 3.5

Aplicación Java 17 con interfaz HTML, CSS y JavaScript. Incluye registro e ingreso
con DNI y código de seis cifras, saldo personal, transferencias e historial.

## Ejecutar

1. Extrae la carpeta completa y cierra el servidor de la entrega anterior.
2. Configura el envío de códigos como se indica abajo.
3. En Windows, ejecuta `iniciar.bat` y después `ABRIR_NDR.bat`.
   En Linux o macOS, ejecuta `sh iniciar.sh` y abre la dirección que aparece.
4. Mantén abierta la ventana del servidor mientras utilizas la aplicación.

El JAR preparado está en `dist/banca-movil.jar`; para ejecutarlo basta Java 17+.
El puerto predeterminado es 18083. La variable `PORT` permite elegir otro.

## Envío de códigos

Se puede elegir **correo electrónico o SMS** en el registro y en cada ingreso.
Los servicios de envío necesitan credenciales propias. El proyecto no incluye
claves ni un remitente de terceros. Sin configurar al menos un canal, el acceso
con código queda pendiente y la aplicación muestra un mensaje; no finge enviar.

Completa `configuracion.properties` **en tu computadora** y reinicia el servidor:

| Canal | Valores necesarios | Servicio |
|---|---|---|
| Correo | `NDR_EMAIL_API_KEY`, `NDR_EMAIL_FROM` | Resend, con remitente autorizado |
| SMS | `NDR_SMS_ACCOUNT_SID`, `NDR_SMS_AUTH_TOKEN`, `NDR_SMS_FROM` | Twilio, con número emisor habilitado |

También puedes usar variables de entorno con esos nombres; tienen prioridad
sobre el archivo. No compartas el archivo una vez completado ni lo incluyas en
una presentación o publicación. La plantilla de esta entrega está vacía.
Las cuentas de prueba de los servicios pueden limitar los destinatarios.

El código caduca a los cinco minutos, admite cinco intentos y se utiliza una
sola vez. Se puede reenviar tras 60 segundos, hasta tres veces. La aplicación
no muestra ni registra los códigos recibidos por los servicios de envío.

## Cuentas y movimientos

El DNI debe contener ocho cifras y se pide al registrar e ingresar. Se comprueba
su formato y coincidencia con el perfil; no se consulta un registro de identidad.
El código enviado al contacto elegido es el último paso para abrir la sesión.

Los perfiles de versiones anteriores se conservan. Si no tenían DNI, este se
asocia después de validar su contraseña y el código, sin perder su ID, CCI,
saldo ni movimientos. No borres los datos para actualizar la aplicación.

El saldo inicial es S/ 200.00 por cuenta y se conserva después de cada operación.
El ojo permite mostrarlo u ocultarlo. El CCI propio permanece enmascarado en
pantalla; se puede consultar expresamente desde el perfil. El CCI del
beneficiario permanece visible al revisar una transferencia.

El libro de cuentas funciona localmente. Una transferencia descuenta el importe
y lo registra en el historial; si el destinatario pertenece al mismo almacén
NDR, se acredita su cuenta. No se envían instrucciones a bancos externos.

Los perfiles y el libro de movimientos se guardan fuera de `src` y `dist`.
Windows usa normalmente `%LOCALAPPDATA%/NDR/datos`; si existe `data/usuarios.ndr`
junto al proyecto, se conserva esa ubicación. `NDR_DATA_DIR` permite elegir otra.
Respalda la carpeta completa de datos antes de cambiar de equipo.

## Estructura del proyecto

| Archivo o carpeta | Función |
|---|---|
| `src/main/java` | Servidor, usuarios, códigos, configuración y libro de movimientos |
| `src/main/resources` | Interfaz y su icono |
| `dist/banca-movil.jar` | Aplicación lista para ejecutar |
| `tests` | Pruebas de acceso, interfaz, códigos y transferencias |
| `pom.xml` | Compilación Maven con estructura estándar |
| `compilar.bat` / `compilar.sh` | Compilación sin instalar Maven |
| `iniciar.bat` / `iniciar.sh` | Inicio del servidor |
| `ABRIR_NDR.bat` | Apertura del navegador en Windows |
| `configuracion.properties` | Configuración privada del envío de códigos |

Se omitieron ajustes personales del IDE, cachés, clases compiladas duplicadas,
carpetas vacías de compilación, diagnósticos antiguos y documentación repetida.
No se incluyen cuentas personales ni datos usados por las pruebas.

## Compilar y comprobar

Se necesita JDK 17+ para compilar. Ejecuta `compilar.bat` o `sh compilar.sh`.
Maven también puede producir el JAR con `mvn package`.

Las pruebas requieren Python 3 y JDK 17+; las de navegador, Playwright y Chromium.
Se ejecutan desde la carpeta del proyecto:

```sh
python3 tests/backend_smoke.py
python3 tests/delivery_smoke.py
python3 tests/frontend_smoke.py
python3 tests/wallet_e2e.py
```

Las pruebas usan servicios HTTP de envío controlados en memoria, contactos
ficticios y datos temporales. Comprueban el flujo sin enviar mensajes a personas.
El envío real se comprueba después de completar las credenciales de ambos
servicios y usar destinatarios permitidos por esas cuentas.
