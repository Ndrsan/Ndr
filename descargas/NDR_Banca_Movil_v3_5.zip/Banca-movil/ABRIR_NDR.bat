@echo off
setlocal
set "NDR_PUERTO=18083"
if defined PORT set "NDR_PUERTO=%PORT%"
start "" "http://127.0.0.1:%NDR_PUERTO%/"
