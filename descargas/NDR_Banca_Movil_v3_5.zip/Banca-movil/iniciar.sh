#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
java -jar dist/banca-movil.jar
