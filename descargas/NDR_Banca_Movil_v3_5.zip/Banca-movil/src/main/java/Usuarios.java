import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Perfiles locales; el DNI declarado no sustituye una verificación oficial de identidad. */
public final class Usuarios {
    public record Perfil(String id, String nombre, String correo, String telefono, String cci,
                         String dni, boolean correoVerificado, boolean telefonoVerificado) {}
    public record Sesion(Perfil perfil, String csrf, long venceEn) {}
    public record Acceso(Sesion sesion, String tokenCookie) {}
    /** Contiene exclusivamente la credencial derivada; nunca la contraseña original. */
    public record RegistroPendiente(Perfil perfil, String sal, String resumen) {}
    public record IngresoPendiente(Perfil perfil, String dni) {}
    private record Credencial(Perfil perfil, String sal, String resumen) {}
    private static final int ITERACIONES = 310_000;
    private static final long VIDA = 30 * 60_000L;
    private static final SecureRandom ALEATORIO = new SecureRandom();
    private final Path archivo;
    private final Map<String, Credencial> porCorreo = new HashMap<>();
    private final Map<String, Credencial> porTelefono = new HashMap<>();
    private final Map<String, Credencial> porDni = new HashMap<>();
    private final Set<String> ccis = new HashSet<>();
    private final ConcurrentHashMap<String, Sesion> sesiones = new ConcurrentHashMap<>();

    public Usuarios(Path directorio) throws IOException {
        Files.createDirectories(directorio);
        limitarPermisos(directorio, true);
        archivo = directorio.resolve("usuarios.ndr");
        if (Files.exists(archivo)) cargar();
    }

    private void cargar() throws IOException {
        List<String> lineas = Files.readAllLines(archivo, StandardCharsets.UTF_8);
        if (lineas.isEmpty()) throw new IOException("Archivo de perfiles vacío.");
        String cabecera = lineas.get(0);
        boolean v1 = "NDR-USUARIOS-1".equals(cabecera);
        boolean v2 = "NDR-USUARIOS-2".equals(cabecera);
        boolean v3 = "NDR-USUARIOS-3".equals(cabecera);
        if (!v1 && !v2 && !v3) throw new IOException("Formato de perfiles desconocido. No se iniciará el servidor.");
        for (int i = 1; i < lineas.size(); i++) {
            String[] partes = lineas.get(i).split("\\|", -1);
            if ((v1 && partes.length != 6) || (v2 && partes.length != 7) || (v3 && partes.length != 10))
                throw new IOException("Archivo de perfiles dañado en línea " + (i + 1));
            try {
                String cci = v1 ? generarCciUnico() : dec(partes[4]);
                String dni = v3 ? dec(partes[5]) : "";
                if (!cci.matches("[0-9]{20}") || (!dni.isEmpty() && !dni.matches("[0-9]{8}")))
                    throw new IOException("Identificador inválido en archivo de perfiles.");
                if (v3 && (!Set.of("0", "1").contains(partes[6]) || !Set.of("0", "1").contains(partes[7])))
                    throw new IOException("Estado de contacto inválido en archivo de perfiles.");
                Perfil p = new Perfil(dec(partes[0]), dec(partes[1]), dec(partes[2]), dec(partes[3]), cci,
                        dni, v3 && "1".equals(partes[6]), v3 && "1".equals(partes[7]));
                String sal = partes[v3 ? 8 : v2 ? 5 : 4];
                String resumen = partes[v3 ? 9 : v2 ? 6 : 5];
                if (Base64.getUrlDecoder().decode(sal).length != 16 || Base64.getUrlDecoder().decode(resumen).length != 32)
                    throw new IOException("Credencial inválida en archivo de perfiles.");
                Credencial c = new Credencial(p, sal, resumen);
                if (porCorreo.putIfAbsent(p.correo(), c) != null || porTelefono.putIfAbsent(p.telefono(), c) != null
                        || (!dni.isEmpty() && porDni.putIfAbsent(dni, c) != null) || !ccis.add(cci))
                    throw new IOException("Identidad duplicada en el archivo de perfiles.");
            } catch (IllegalArgumentException e) { throw new IOException("Archivo de perfiles inválido.", e); }
        }
        // V1 necesita conservar el CCI que acaba de asignarse. V2 ya lo tiene y no se reescribe
        // hasta confirmar el acceso: su DNI sigue vacío hasta completar contraseña y OTP.
        if (v1) guardar();
    }

    public synchronized RegistroPendiente prepararRegistro(String nombre, String correo, String telefono,
                                                           String dni, String clave) throws Exception {
        nombre = nombre.trim().replaceAll("\\s+", " ");
        correo = correo.trim().toLowerCase(Locale.ROOT);
        telefono = normalizarTelefono(telefono);
        dni = dni.trim();
        validar(nombre, correo, telefono, dni, clave);
        comprobarDisponibilidad(correo, telefono, dni);
        byte[] sal = nuevoAleatorio(16);
        String resumen = Base64.getUrlEncoder().withoutPadding().encodeToString(hash(clave.toCharArray(), sal));
        Perfil p = new Perfil(UUID.randomUUID().toString(), nombre, correo, telefono, generarCciUnico(), dni, false, false);
        return new RegistroPendiente(p, Base64.getUrlEncoder().withoutPadding().encodeToString(sal), resumen);
    }

    public synchronized Acceso confirmarRegistro(RegistroPendiente pendiente, String canal) throws IOException {
        Perfil p = verificarContacto(pendiente.perfil(), canal, pendiente.perfil().dni());
        comprobarDisponibilidad(p.correo(), p.telefono(), p.dni());
        if (ccis.contains(p.cci())) throw new Falta(409, "No se pudo asignar esta cuenta. Inicia el registro de nuevo.");
        Credencial nueva = new Credencial(p, pendiente.sal(), pendiente.resumen());
        indexar(nueva);
        try { guardar(); }
        catch (IOException e) { desindexar(nueva); throw e; }
        return abrirSesion(p);
    }

    public synchronized IngresoPendiente prepararIngreso(String identificador, String dni, String clave) throws Exception {
        validarDni(dni);
        String entrada = identificador.trim().toLowerCase(Locale.ROOT);
        Credencial c = entrada.contains("@") ? porCorreo.get(entrada) : porTelefono.get(normalizarTelefono(entrada));
        if (clave.length() > 256) throw accesoIncorrecto();
        byte[] sal = c == null ? new byte[16] : Base64.getUrlDecoder().decode(c.sal());
        byte[] esperado = c == null ? new byte[32] : Base64.getUrlDecoder().decode(c.resumen());
        boolean ok = MessageDigest.isEqual(hash(clave.toCharArray(), sal), esperado);
        if (!ok || c == null || (!c.perfil().dni().isEmpty() && !c.perfil().dni().equals(dni)))
            throw accesoIncorrecto();
        if (c.perfil().dni().isEmpty() && porDni.containsKey(dni)) throw accesoIncorrecto();
        return new IngresoPendiente(c.perfil(), dni);
    }

    public synchronized Acceso confirmarIngreso(IngresoPendiente pendiente, String canal) throws IOException {
        Perfil anterior = pendiente.perfil();
        Credencial actual = porCorreo.get(anterior.correo());
        if (actual == null || !actual.perfil().id().equals(anterior.id())) throw accesoIncorrecto();
        if (!actual.perfil().dni().isEmpty() && !actual.perfil().dni().equals(pendiente.dni())) throw accesoIncorrecto();
        Credencial titularDni = porDni.get(pendiente.dni());
        if (titularDni != null && !titularDni.perfil().id().equals(anterior.id()))
            throw new Falta(409, "El DNI ya está asociado a otro perfil.");
        Perfil actualizado = verificarContacto(actual.perfil(), canal, pendiente.dni());
        Credencial nueva = new Credencial(actualizado, actual.sal(), actual.resumen());
        desindexar(actual);
        indexar(nueva);
        try { guardar(); }
        catch (IOException e) { desindexar(nueva); indexar(actual); throw e; }
        return abrirSesion(actualizado);
    }

    private static Perfil verificarContacto(Perfil p, String canal, String dni) {
        return new Perfil(p.id(), p.nombre(), p.correo(), p.telefono(), p.cci(), dni,
                p.correoVerificado() || "correo".equals(canal), p.telefonoVerificado() || "sms".equals(canal));
    }
    private void comprobarDisponibilidad(String correo, String telefono, String dni) {
        if (porCorreo.containsKey(correo) || porTelefono.containsKey(telefono) || porDni.containsKey(dni))
            throw new Falta(409, "El correo, el celular o el DNI ya está registrado.");
    }
    private void indexar(Credencial c) {
        Perfil p = c.perfil();
        porCorreo.put(p.correo(), c); porTelefono.put(p.telefono(), c);
        if (!p.dni().isEmpty()) porDni.put(p.dni(), c);
        ccis.add(p.cci());
    }
    private void desindexar(Credencial c) {
        Perfil p = c.perfil();
        porCorreo.remove(p.correo()); porTelefono.remove(p.telefono());
        if (!p.dni().isEmpty()) porDni.remove(p.dni());
        ccis.remove(p.cci());
    }
    private static Falta accesoIncorrecto() {
        return new Falta(401, "DNI, correo/celular o contraseña incorrectos.");
    }

    public synchronized Perfil perfilPorId(String id) {
        for (Credencial c : porCorreo.values()) if (c.perfil().id().equals(id)) return c.perfil();
        return null;
    }
    public synchronized Perfil perfilPorCci(String cci) {
        for (Credencial c : porCorreo.values()) if (c.perfil().cci().equals(cci)) return c.perfil();
        return null;
    }
    private Acceso abrirSesion(Perfil perfil) {
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(nuevoAleatorio(32));
        String csrf = Base64.getUrlEncoder().withoutPadding().encodeToString(nuevoAleatorio(24));
        Sesion sesion = new Sesion(perfil, csrf, Instant.now().toEpochMilli() + VIDA);
        sesiones.put(digest(token), sesion);
        if (sesiones.size() > 4096) sesiones.entrySet().removeIf(e -> e.getValue().venceEn() < System.currentTimeMillis());
        return new Acceso(sesion, token);
    }
    public Sesion sesion(String token) {
        if (token == null || token.length() > 128 || token.isBlank()) return null;
        Sesion s = sesiones.get(digest(token));
        if (s == null) return null;
        if (s.venceEn() <= System.currentTimeMillis()) { sesiones.remove(digest(token)); return null; }
        return s;
    }
    public void cerrar(String token) {
        if (token != null && token.length() <= 128) sesiones.remove(digest(token));
    }

    private void guardar() throws IOException {
        StringBuilder b = new StringBuilder("NDR-USUARIOS-3\n");
        for (Credencial c : porCorreo.values()) {
            Perfil p = c.perfil();
            b.append(enc(p.id())).append('|').append(enc(p.nombre())).append('|')
             .append(enc(p.correo())).append('|').append(enc(p.telefono())).append('|')
             .append(enc(p.cci())).append('|').append(enc(p.dni())).append('|')
             .append(p.correoVerificado() ? '1' : '0').append('|').append(p.telefonoVerificado() ? '1' : '0').append('|')
             .append(c.sal()).append('|').append(c.resumen()).append('\n');
        }
        Path temporal = Files.createTempFile(archivo.getParent(), "ndr-", ".tmp");
        try {
            limitarPermisos(temporal, false);
            Files.writeString(temporal, b.toString(), StandardCharsets.UTF_8, StandardOpenOption.TRUNCATE_EXISTING);
            try { Files.move(temporal, archivo, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temporal, archivo, StandardCopyOption.REPLACE_EXISTING); }
            limitarPermisos(archivo, false);
        } finally { Files.deleteIfExists(temporal); }
    }

    private static void validar(String nombre, String correo, String telefono, String dni, String clave) {
        if (nombre.length() < 3 || nombre.length() > 100 || nombre.chars().anyMatch(ch -> ch < 32))
            throw new Falta(400, "Introduce tu nombre completo (3 a 100 caracteres).");
        if (correo.length() > 254 || !correo.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$"))
            throw new Falta(400, "Introduce un correo electrónico válido.");
        if (!telefono.matches("\\+519[0-9]{8}"))
            throw new Falta(400, "Introduce un celular peruano válido: +51 9XXXXXXXX.");
        validarDni(dni);
        if (clave.length() < 12 || clave.length() > 128 || clave.chars().anyMatch(ch -> ch < 32))
            throw new Falta(400, "La contraseña debe tener entre 12 y 128 caracteres.");
    }
    private static void validarDni(String dni) {
        if (!dni.matches("[0-9]{8}")) throw new Falta(400, "Introduce un DNI de 8 dígitos.");
    }
    public static String normalizarTelefono(String tel) {
        String limpio = tel.replaceAll("[ ()-]", "");
        if (limpio.matches("9[0-9]{8}")) limpio = "+51" + limpio;
        if (limpio.matches("519[0-9]{8}")) limpio = "+" + limpio;
        return limpio;
    }
    private String generarCciUnico() {
        String cci;
        do {
            StringBuilder b = new StringBuilder("002");
            for (int i = 0; i < 17; i++) b.append(ALEATORIO.nextInt(10));
            cci = b.toString();
        } while (ccis.contains(cci));
        return cci;
    }
    private static byte[] hash(char[] clave, byte[] sal) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(clave, sal, ITERACIONES, 256);
        try { return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded(); }
        finally { spec.clearPassword(); Arrays.fill(clave, '\0'); }
    }
    private static byte[] nuevoAleatorio(int cantidad) { byte[] a = new byte[cantidad]; ALEATORIO.nextBytes(a); return a; }
    private static String digest(String s) {
        try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.US_ASCII))); }
        catch (Exception e) { throw new IllegalStateException(e); }
    }
    private static String enc(String s) { return Base64.getUrlEncoder().withoutPadding().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }
    private static String dec(String s) { return new String(Base64.getUrlDecoder().decode(s), StandardCharsets.UTF_8); }
    private static void limitarPermisos(Path p, boolean dir) {
        try { Files.setPosixFilePermissions(p, java.nio.file.attribute.PosixFilePermissions.fromString(dir ? "rwx------" : "rw-------")); }
        catch (UnsupportedOperationException | IOException ignored) { }
    }
    public static final class Falta extends RuntimeException {
        public final int codigo;
        public Falta(int codigo, String mensaje) { super(mensaje); this.codigo = codigo; }
    }
}
