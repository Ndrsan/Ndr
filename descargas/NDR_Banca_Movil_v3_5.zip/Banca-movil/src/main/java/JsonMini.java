import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
/** Parser JSON estricto y acotado para solicitudes a la API bancaria. */
public final class JsonMini {
    private final String s;
    private int p;
    private JsonMini(String s){this.s=s;}
    public static Map<String,Object> object(String json){
        if(json==null||json.length()>131072)throw new IllegalArgumentException("Respuesta JSON demasiado grande");
        JsonMini parser=new JsonMini(json);
        Object result=parser.value(0);
        parser.ws();
        if(parser.p!=parser.s.length()||!(result instanceof Map<?,?>))throw new IllegalArgumentException("JSON no es objeto");
        @SuppressWarnings("unchecked") Map<String,Object> m=(Map<String,Object>)result;
        return m;
    }
    private void ws(){while(p<s.length()&&" \r\n\t".indexOf(s.charAt(p))>=0)p++;}
    private char next(){if(p>=s.length())throw new IllegalArgumentException("JSON incompleto");return s.charAt(p++);}
    private void expected(char c){ws();if(next()!=c)throw new IllegalArgumentException("JSON inválido");}
    private Object value(int d){
        if(d>32)throw new IllegalArgumentException("JSON demasiado profundo");
        ws();if(p==s.length())throw new IllegalArgumentException("JSON incompleto");
        return switch(s.charAt(p)){
            case '{'->obj(d+1);
            case '['->array(d+1);
            case '"'->string();
            case 't'->literal("true",Boolean.TRUE);
            case 'f'->literal("false",Boolean.FALSE);
            case 'n'->literal("null",null);
            default->number();
        };
    }
    private Object literal(String token,Object result){if(!s.startsWith(token,p))throw new IllegalArgumentException("JSON inválido");p+=token.length();return result;}
    private Map<String,Object> obj(int d){
        expected('{');Map<String,Object> v=new LinkedHashMap<>();ws();
        if(p<s.length()&&s.charAt(p)=='}'){p++;return v;}
        while(true){ws();String k=string();expected(':');Object value=value(d);if(v.containsKey(k))throw new IllegalArgumentException("Clave duplicada");v.put(k,value);
            ws();char sep=next();if(sep=='}')return v;if(sep!=',')throw new IllegalArgumentException("JSON inválido");}
    }
    private List<Object> array(int d){
        expected('[');List<Object> a=new ArrayList<>();ws();if(p<s.length()&&s.charAt(p)==']'){p++;return a;}
        while(true){a.add(value(d));ws();char sep=next();if(sep==']')return a;if(sep!=',')throw new IllegalArgumentException("JSON inválido");}
    }
    private String string(){
        expected('"');StringBuilder b=new StringBuilder();while(true){char c=next();if(c=='"')return b.toString();
            if(c<32)throw new IllegalArgumentException("Carácter inválido");
            if(c!='\\'){b.append(c);continue;}c=next();
            switch(c){case '"','\\','/'->b.append(c);case 'b'->b.append('\b');case 'f'->b.append('\f');
                case 'n'->b.append('\n');case 'r'->b.append('\r');case 't'->b.append('\t');
                case 'u'->{if(p+4>s.length())throw new IllegalArgumentException("Unicode inválido");
                    b.append((char)Integer.parseInt(s.substring(p,p+4),16));p+=4;}
                default->throw new IllegalArgumentException("Escape inválido");}
        }
    }
    private String number(){
        int start=p;if(p<s.length()&&s.charAt(p)=='-')p++;
        if(p>=s.length())throw new IllegalArgumentException("Número inválido");
        if(s.charAt(p)=='0')p++;else {if(s.charAt(p)<'1'||s.charAt(p)>'9')throw new IllegalArgumentException("Número inválido");while(p<s.length()&&Character.isDigit(s.charAt(p)))p++;}
        if(p<s.length()&&s.charAt(p)=='.'){p++;int a=p;while(p<s.length()&&Character.isDigit(s.charAt(p)))p++;if(p==a)throw new IllegalArgumentException("Decimal inválido");}
        if(p<s.length()&&(s.charAt(p)=='e'||s.charAt(p)=='E')){p++;if(p<s.length()&&(s.charAt(p)=='+'||s.charAt(p)=='-'))p++;int a=p;while(p<s.length()&&Character.isDigit(s.charAt(p)))p++;if(p==a)throw new IllegalArgumentException("Exponente inválido");}
        return s.substring(start,p);
    }
}
