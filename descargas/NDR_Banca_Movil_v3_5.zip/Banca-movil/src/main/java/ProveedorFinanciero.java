import java.math.BigDecimal;
import java.util.List;

/**
 * Contrato para el libro local NDR o un adaptador de una entidad financiera.
 * Un proveedor externo debe resolver su propio vínculo verificado entre NDR ID y cliente bancario.
 */
public interface ProveedorFinanciero {
    record Identidad(String usuarioNdr, String correoNoVerificado, String telefonoNoVerificado) {}
    record Cuenta(String titular, String numeroEnmascarado, String moneda,
                  BigDecimal saldoDisponible, String actualizadoEn) {}
    record Transferencia(String identificador, String estado, String referenciaBancaria) {}
    record Movimiento(String identificador, String fecha, String monto, String moneda,
                      String estado, String descripcion) {}

    String nombre();
    boolean estaConfigurado();
    /** El proveedor local valida el perfil NDR; uno externo debe exigir su KYC y autorización propios. */
    boolean clienteVerificado(Identidad cliente) throws Exception;
    Cuenta consultarCuenta(Identidad cliente) throws Exception;
    List<Movimiento> consultarTransferencias(Identidad cliente) throws Exception;
    /** Exigir idempotencia duradera; un adaptador externo también debe verificar beneficiario y autorización con su entidad. */
    Transferencia solicitarTransferencia(Identidad cliente, String cci, String beneficiario,
                                        BigDecimal montoPEN, String concepto, String claveIdempotencia) throws Exception;
}
