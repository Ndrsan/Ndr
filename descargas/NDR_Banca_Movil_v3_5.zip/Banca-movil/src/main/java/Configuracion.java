import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Preferencia por variables del proceso; el archivo local nunca se sirve por HTTP. */
public final class Configuracion {
    private static final Properties ARCHIVO = cargar();

    private Configuracion() { }

    public static String valor(String nombre) {
        String entorno = System.getenv(nombre);
        if (entorno != null && !entorno.isBlank()) return entorno.trim();
        return ARCHIVO.getProperty(nombre, "").trim();
    }

    private static Properties cargar() {
        Properties valores = new Properties();
        Path ruta = Path.of("configuracion.properties");
        if (Files.exists(ruta)) {
            try (Reader entrada = Files.newBufferedReader(ruta, StandardCharsets.UTF_8)) {
                valores.load(entrada);
            } catch (IOException | IllegalArgumentException e) {
                throw new ExceptionInInitializerError("No se pudo leer configuracion.properties. Revisa sus permisos y formato.");
            }
        }
        return valores;
    }
}
