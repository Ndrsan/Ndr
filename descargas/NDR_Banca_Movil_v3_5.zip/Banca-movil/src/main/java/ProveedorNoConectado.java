import java.math.BigDecimal;
import java.util.List;

/** No inventa transferencias, saldos ni movimientos. Operaciones bloqueadas por defecto. */
public final class ProveedorNoConectado implements ProveedorFinanciero {
    @Override public String nombre() { return "Entidad bancaria pendiente"; }
    @Override public boolean estaConfigurado() { return false; }
    @Override public boolean clienteVerificado(Identidad cliente) { return false; }
    private IllegalStateException falta() { return new IllegalStateException("No se ha vinculado una entidad financiera."); }
    @Override public Cuenta consultarCuenta(Identidad cliente) { throw falta(); }
    @Override public List<Movimiento> consultarTransferencias(Identidad cliente) { throw falta(); }
    @Override public Transferencia solicitarTransferencia(Identidad cliente, String cci, String beneficiario,
        BigDecimal montoPEN, String concepto, String claveIdempotencia) { throw falta(); }
}
