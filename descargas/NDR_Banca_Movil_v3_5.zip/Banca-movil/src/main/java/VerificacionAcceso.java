import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Clock;
import java.util.Base64;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Desafíos de un solo uso: el código solo se entrega al proveedor de mensajería. */
public final class VerificacionAcceso {
    public record Info(String id, String canal, String destino, String tipo,
                       int expiraEnSegundos, int reenviarEnSegundos) {}
    public record Inicio(Info verificacion, String cookie) {}
    public record Confirmacion(Usuarios.Acceso acceso, boolean registro) {}
    @FunctionalInterface private interface Completar { Usuarios.Acceso ejecutar(String canal) throws Exception; }
    private static final SecureRandom ALEATORIO = new SecureRandom();
    private static final long VIDA = 300_000L;
    private static final long ESPERA = 60_000L;
    private static final int MAX_INTENTOS = 5;
    private static final int MAX_REENVIOS = 3;
    private final Usuarios usuarios;
    private final EnvioCodigos envio;
    private final Clock reloj;
    private final Map<String, Pendiente> pendientes = new HashMap<>();

    private static final class Pendiente {
        final String id, canal, destino, nombre, tipo;
        final byte[] cookie;
        final Completar completar;
        byte[] codigo;
        long vence, ultimoEnvio;
        int intentos, reenvios;
        Pendiente(String id, String canal, String destino, String nombre, String tipo,
                  byte[] cookie, Completar completar) {
            this.id = id; this.canal = canal; this.destino = destino; this.nombre = nombre;
            this.tipo = tipo; this.cookie = cookie; this.completar = completar;
        }
    }
    public VerificacionAcceso(Usuarios usuarios, EnvioCodigos envio) { this(usuarios, envio, Clock.systemUTC()); }
    // El reloj inyectable permite probar vencimientos sin reducir la seguridad en ejecución.
    VerificacionAcceso(Usuarios usuarios, EnvioCodigos envio, Clock reloj) {
        this.usuarios = usuarios; this.envio = envio; this.reloj = reloj;
    }
    public boolean disponible(String canal) { return envio.disponible(canal); }
    public Inicio registro(Usuarios.RegistroPendiente registro, String canal) {
        Usuarios.Perfil p = registro.perfil();
        return iniciar(p, canal, "registro", c -> usuarios.confirmarRegistro(registro, c));
    }
    public Inicio ingreso(Usuarios.IngresoPendiente ingreso, String canal) {
        return iniciar(ingreso.perfil(), canal, "login", c -> usuarios.confirmarIngreso(ingreso, c));
    }
    private synchronized Inicio iniciar(Usuarios.Perfil perfil, String canal, String tipo, Completar completar) {
        limpiarVencidos();
        if (!"correo".equals(canal) && !"sms".equals(canal))
            throw new Usuarios.Falta(400, "Selecciona correo electrónico o SMS para recibir el código.");
        if (!envio.disponible(canal))
            throw new Usuarios.Falta(503, "El servicio de envío por " + ("correo".equals(canal) ? "correo" : "SMS") + " no está configurado. Revisa la configuración de NDR.");
        if (pendientes.size() >= 1024) throw new Usuarios.Falta(429, "Hay demasiadas verificaciones pendientes. Vuelve a intentarlo después.");
        String id = aleatorio(24), cookie = aleatorio(32);
        String destino = "correo".equals(canal) ? perfil.correo() : perfil.telefono();
        Pendiente p = new Pendiente(id, canal, destino, perfil.nombre(), tipo, resumen(cookie), completar);
        enviar(p);
        pendientes.put(id, p);
        return new Inicio(info(p), cookie);
    }
    public synchronized Info reenviar(String id, String cookie) {
        Pendiente p = buscar(id, cookie);
        long restantes = p.ultimoEnvio + ESPERA - reloj.millis();
        if (restantes > 0) throw new Usuarios.Falta(429, "Espera " + ((restantes + 999) / 1000) + " segundos antes de reenviar el código.");
        if (p.reenvios >= MAX_REENVIOS) {
            pendientes.remove(p.id);
            throw new Usuarios.Falta(429, "Se alcanzó el máximo de reenvíos. Inicia el acceso de nuevo.");
        }
        enviar(p); // Un fallo conserva el código anterior y su vencimiento.
        p.reenvios++;
        return info(p);
    }
    public synchronized Confirmacion confirmar(String id, String cookie, String codigo) throws Exception {
        Pendiente p = buscar(id, cookie);
        boolean formato = codigo != null && codigo.matches("[0-9]{6}");
        boolean coincide = formato && MessageDigest.isEqual(p.codigo, resumen(p.id + ":" + codigo));
        if (!coincide) {
            p.intentos++;
            if (p.intentos >= MAX_INTENTOS) {
                pendientes.remove(p.id);
                throw new Usuarios.Falta(401, "Se agotaron los intentos. Inicia el acceso de nuevo.");
            }
            throw new Usuarios.Falta(401, "El código no es correcto. Revisa los seis dígitos e inténtalo de nuevo.");
        }
        Usuarios.Acceso acceso;
        try { acceso = p.completar.ejecutar(p.canal); }
        catch (Usuarios.Falta e) { pendientes.remove(p.id); throw e; }
        // La sesión solo se crea después de validar el código y persistir el perfil.
        pendientes.remove(p.id);
        return new Confirmacion(acceso, "registro".equals(p.tipo));
    }
    public synchronized void cancelar(String id, String cookie) {
        if (id == null || cookie == null) return;
        Pendiente p = pendientes.get(id);
        if (p != null && MessageDigest.isEqual(p.cookie, resumen(cookie))) pendientes.remove(id);
    }
    private Pendiente buscar(String id, String cookie) {
        if (id == null || id.length() > 128 || cookie == null || cookie.length() > 128)
            throw new Usuarios.Falta(401, "La verificación no es válida. Inicia el acceso de nuevo.");
        Pendiente p = pendientes.get(id);
        if (p == null || !MessageDigest.isEqual(p.cookie, resumen(cookie)))
            throw new Usuarios.Falta(401, "La verificación no es válida. Inicia el acceso de nuevo.");
        if (p.vence <= reloj.millis()) {
            pendientes.remove(id);
            throw new Usuarios.Falta(410, "El código venció. Inicia el acceso de nuevo para recibir otro.");
        }
        return p;
    }
    private void enviar(Pendiente p) {
        String codigo;
        do { codigo = String.format(Locale.ROOT, "%06d", ALEATORIO.nextInt(1_000_000)); }
        while (p.codigo != null && MessageDigest.isEqual(p.codigo, resumen(p.id + ":" + codigo)));
        try { envio.enviar(p.canal, p.destino, p.nombre, codigo); }
        catch (IOException | RuntimeException e) {
            // El proveedor puede incluir secretos en su error: nunca propagarlo ni registrarlo.
            throw new Usuarios.Falta(503, "No se pudo enviar el código. Comprueba la configuración de envío e inténtalo de nuevo.");
        }
        p.codigo = resumen(p.id + ":" + codigo);
        p.ultimoEnvio = reloj.millis();
        p.vence = p.ultimoEnvio + VIDA;
        p.intentos = 0;
    }
    private Info info(Pendiente p) {
        int expira = (int) Math.max(0, (p.vence - reloj.millis() + 999) / 1000);
        int espera = (int) Math.max(0, (p.ultimoEnvio + ESPERA - reloj.millis() + 999) / 1000);
        return new Info(p.id, p.canal, enmascarar(p.destino, p.canal), p.tipo, expira, espera);
    }
    private void limpiarVencidos() { pendientes.entrySet().removeIf(e -> e.getValue().vence <= reloj.millis()); }
    private static String enmascarar(String destino, String canal) {
        if ("sms".equals(canal)) return "••••••" + destino.substring(Math.max(0, destino.length() - 3));
        int arroba = destino.indexOf('@');
        return arroba < 1 ? "••••" : destino.substring(0, 1) + "•••" + destino.substring(arroba);
    }
    private static String aleatorio(int longitud) {
        byte[] bytes = new byte[longitud]; ALEATORIO.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
    private static byte[] resumen(String valor) {
        try { return MessageDigest.getInstance("SHA-256").digest(valor.getBytes(StandardCharsets.US_ASCII)); }
        catch (Exception e) { throw new IllegalStateException(e); }
    }
}
