import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.SocketAddress;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

/** Envía códigos mediante las cuentas de correo y SMS configuradas por el propietario. */
public final class EnvioCodigos {
    private static final Duration ESPERA = Duration.ofSeconds(15);
    private volatile HttpClient cliente;

    public EnvioCodigos() { }

    public boolean disponible(String canal) {
        try {
            if ("correo".equals(canal)) {
                return presente("NDR_EMAIL_API_KEY") && presente("NDR_EMAIL_FROM")
                        && direccion("NDR_EMAIL_API_URL", "https://api.resend.com/emails") != null;
            }
            if ("sms".equals(canal)) {
                return valor("NDR_SMS_ACCOUNT_SID").matches("AC[0-9a-fA-F]{32}")
                        && presente("NDR_SMS_AUTH_TOKEN") && presente("NDR_SMS_FROM")
                        && direccion("NDR_SMS_API_URL", urlSms()) != null;
            }
            return false;
        } catch (IOException e) { return false; }
    }

    public void enviar(String canal, String destino, String nombre, String codigo) throws IOException {
        if (!codigo.matches("[0-9]{6}")) throw new IOException("El código de acceso no es válido.");
        if (!disponible(canal)) throw new IOException("El servicio de verificación no está configurado para este canal.");
        if (destino == null || destino.isBlank()) throw new IOException("El destino de verificación no es válido.");
        try {
            HttpRequest solicitud;
            if ("correo".equals(canal)) {
                String texto = "Hola, " + nombreSeguro(nombre) + ".\n\nTu código de acceso NDR es: " + codigo
                        + "\n\nVence en 5 minutos. No compartas este código con nadie."
                        + "\nSi no solicitaste este acceso, puedes ignorar este mensaje.\n\nCon cariño, el equipo NDR.";
                String cuerpo = "{\"from\":" + json(valor("NDR_EMAIL_FROM"))
                        + ",\"to\":[" + json(destino) + "],\"subject\":\"Tu código de acceso a NDR\""
                        + ",\"text\":" + json(texto) + ",\"html\":" + json(correoHtml(nombre, codigo)) + "}";
                solicitud = HttpRequest.newBuilder(direccion("NDR_EMAIL_API_URL", "https://api.resend.com/emails"))
                        .timeout(ESPERA).header("Authorization", "Bearer " + valor("NDR_EMAIL_API_KEY"))
                        .header("Content-Type", "application/json; charset=utf-8")
                        .POST(HttpRequest.BodyPublishers.ofString(cuerpo, StandardCharsets.UTF_8)).build();
            } else {
                String saludo = nombreSeguro(nombre).split("\\s+", 2)[0];
                if (saludo.length() > 24) saludo = saludo.substring(0, 24);
                String mensaje = "NDR: Hola, " + saludo + ". Tu código de acceso es " + codigo
                        + ". Vence en 5 minutos. No lo compartas.";
                String cuerpo = "To=" + formulario(destino) + "&From=" + formulario(valor("NDR_SMS_FROM"))
                        + "&Body=" + formulario(mensaje);
                String autenticar = Base64.getEncoder().encodeToString((valor("NDR_SMS_ACCOUNT_SID") + ":"
                        + valor("NDR_SMS_AUTH_TOKEN")).getBytes(StandardCharsets.UTF_8));
                solicitud = HttpRequest.newBuilder(direccion("NDR_SMS_API_URL", urlSms()))
                        .timeout(ESPERA).header("Authorization", "Basic " + autenticar)
                        .header("Content-Type", "application/x-www-form-urlencoded; charset=utf-8")
                        .POST(HttpRequest.BodyPublishers.ofString(cuerpo, StandardCharsets.UTF_8)).build();
            }
            HttpResponse<Void> respuesta = cliente().send(solicitud, HttpResponse.BodyHandlers.discarding());
            if (respuesta.statusCode() < 200 || respuesta.statusCode() >= 300)
                throw new IOException("El servicio de envío no aceptó el mensaje. Revisa su configuración e inténtalo más tarde.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Se interrumpió el envío del código. Vuelve a intentarlo.");
        } catch (IOException e) {
            // Los detalles HTTP, TLS o del proveedor no deben alcanzar los logs ni la interfaz.
            throw new IOException("No se pudo enviar el código. Revisa el servicio de envío e inténtalo más tarde.");
        } catch (IllegalArgumentException e) {
            throw new IOException("La configuración del servicio de envío no es válida.");
        }
    }

    private HttpClient cliente() throws IOException {
        HttpClient actual = cliente;
        if (actual != null) return actual;
        synchronized (this) {
            if (cliente == null) {
                try {
                    cliente = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5))
                            .followRedirects(HttpClient.Redirect.NEVER).proxy(new ProxyHeredado())
                            .sslContext(confianza()).build();
                } catch (GeneralSecurityException e) {
                    throw new IOException("No se pudo preparar la conexión segura del servicio de envío.");
                }
            }
            return cliente;
        }
    }

    private static String valor(String nombre) { return Configuracion.valor(nombre).trim(); }
    private static boolean presente(String nombre) { return !valor(nombre).isEmpty(); }
    private static String urlSms() {
        return "https://api.twilio.com/2010-04-01/Accounts/" + valor("NDR_SMS_ACCOUNT_SID") + "/Messages.json";
    }
    private static URI direccion(String nombre, String predeterminada) throws IOException {
        String seleccionada = valor(nombre);
        try {
            URI uri = URI.create(seleccionada.isEmpty() ? predeterminada : seleccionada);
            boolean segura = "https".equalsIgnoreCase(uri.getScheme());
            boolean pruebaLocal = "http".equalsIgnoreCase(uri.getScheme()) && local(uri.getHost());
            if ((!segura && !pruebaLocal) || uri.getHost() == null || uri.getUserInfo() != null
                    || uri.getFragment() != null || uri.getPort() == 0)
                throw new IllegalArgumentException();
            return uri;
        } catch (IllegalArgumentException e) { throw new IOException("La dirección del servicio de envío no es válida."); }
    }
    private static boolean local(String host) {
        return "localhost".equalsIgnoreCase(host) || "127.0.0.1".equals(host)
                || "::1".equals(host) || "[::1]".equals(host);
    }
    private static String nombreSeguro(String nombre) {
        return nombre == null || nombre.isBlank() ? "bienvenido" : nombre.strip();
    }
    private static String formulario(String valor) { return URLEncoder.encode(valor, StandardCharsets.UTF_8); }
    private static String html(String valor) {
        return valor.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }
    private static String correoHtml(String nombre, String codigo) {
        return "<!doctype html><html lang=\"es\"><body style=\"margin:0;padding:32px 16px;background:#edf6f1;"
                + "font-family:Arial,sans-serif;color:#173c2e\"><main style=\"max-width:520px;margin:auto;"
                + "background:#fff;border-radius:24px;overflow:hidden\"><header style=\"background:#0d4937;"
                + "padding:28px 32px;color:#fff\"><strong style=\"font-size:28px\">NDR.</strong>"
                + "<p style=\"margin:8px 0 0;color:#eddbaf\">Un acceso seguro, una experiencia contigo.</p></header>"
                + "<section style=\"padding:32px\"><h1 style=\"font-size:24px;margin:0 0 18px\">Hola, "
                + html(nombreSeguro(nombre)) + "</h1><p style=\"line-height:1.7\">Nos alegra verte de nuevo. "
                + "Usa este código para completar el acceso a tu cuenta:</p>"
                + "<div style=\"margin:24px 0;padding:22px 12px;background:#f2f7f4;border:1px solid #d8e7de;"
                + "border-radius:16px;text-align:center;font-size:36px;font-weight:bold;letter-spacing:10px;color:#0d4937\">"
                + codigo + "</div><p style=\"line-height:1.7\">Tu código vence en <strong>5 minutos</strong>. "
                + "Por tu seguridad, no lo compartas con nadie.</p><p style=\"font-size:13px;line-height:1.7;color:#64786b\">"
                + "Si no solicitaste este acceso, puedes ignorar este mensaje.</p>"
                + "<p style=\"margin:24px 0 0\">Con cariño,<br><strong>El equipo NDR</strong></p></section></main></body></html>";
    }
    private static String json(String valor) {
        StringBuilder salida = new StringBuilder("\"");
        for (char c : valor.toCharArray()) {
            switch (c) {
                case '\\' -> salida.append("\\\\");
                case '"' -> salida.append("\\\"");
                case '\n' -> salida.append("\\n");
                case '\r' -> salida.append("\\r");
                case '\t' -> salida.append("\\t");
                default -> { if (c < 32) salida.append(String.format("\\u%04x", (int)c)); else salida.append(c); }
            }
        }
        return salida.append('"').toString();
    }

    /** Conserva el proxy del proceso y permite solamente las excepciones NO_PROXY indicadas por él. */
    private static final class ProxyHeredado extends ProxySelector {
        private final ProxySelector original = ProxySelector.getDefault();
        @Override public List<Proxy> select(URI uri) {
            if (local(uri.getHost()) || sinProxy(uri)) return List.of(Proxy.NO_PROXY);
            String nombre = "https".equalsIgnoreCase(uri.getScheme()) ? "HTTPS_PROXY" : "HTTP_PROXY";
            String configurado = System.getenv(nombre);
            if (configurado == null || configurado.isBlank()) configurado = System.getenv(nombre.toLowerCase(Locale.ROOT));
            if (configurado != null && !configurado.isBlank()) {
                try {
                    URI proxy = URI.create(configurado);
                    if (proxy.getHost() != null) return List.of(new Proxy(Proxy.Type.HTTP,
                            InetSocketAddress.createUnresolved(proxy.getHost(), proxy.getPort() < 0 ? 80 : proxy.getPort())));
                } catch (IllegalArgumentException ignored) { }
                // Una configuración de proxy inválida debe fallar, no intentar salida directa.
                return List.of(new Proxy(Proxy.Type.HTTP, InetSocketAddress.createUnresolved("127.0.0.1", 1)));
            }
            return original == null ? List.of(Proxy.NO_PROXY) : original.select(uri);
        }
        @Override public void connectFailed(URI uri, SocketAddress direccion, IOException error) { }
        private static boolean sinProxy(URI uri) {
            String lista = System.getenv("NO_PROXY");
            if (lista == null) lista = System.getenv("no_proxy");
            if (lista == null || uri.getHost() == null) return false;
            String host = uri.getHost().toLowerCase(Locale.ROOT);
            for (String entrada : lista.split(",")) {
                String regla = entrada.trim().toLowerCase(Locale.ROOT);
                if (regla.equals("*")) return true;
                if (regla.isEmpty()) continue;
                int separador = regla.lastIndexOf(':');
                if (separador > 0 && regla.indexOf(':') == separador) {
                    try {
                        int puerto = uri.getPort() >= 0 ? uri.getPort() : "https".equals(uri.getScheme()) ? 443 : 80;
                        if (Integer.parseInt(regla.substring(separador + 1)) != puerto) continue;
                        regla = regla.substring(0, separador);
                    } catch (NumberFormatException e) { continue; }
                }
                if (regla.startsWith(".")) regla = regla.substring(1);
                if (host.equals(regla) || host.endsWith("." + regla)) return true;
            }
            return false;
        }
    }

    /** Añade el paquete CA configurado al almacén estándar sin desactivar TLS ni la verificación del nombre. */
    private static SSLContext confianza() throws GeneralSecurityException, IOException {
        String paquete = System.getenv("SSL_CERT_FILE");
        if (paquete == null || paquete.isBlank() || System.getProperty("javax.net.ssl.trustStore") != null)
            return SSLContext.getDefault();
        TrustManagerFactory estandar = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        estandar.init((KeyStore)null);
        KeyStore adicionales = KeyStore.getInstance(KeyStore.getDefaultType());
        adicionales.load(null, null);
        int indice = 0;
        try (InputStream in = Files.newInputStream(Path.of(paquete))) {
            for (var certificado : CertificateFactory.getInstance("X.509").generateCertificates(in))
                adicionales.setCertificateEntry("ca-configurada-" + indice++, certificado);
        }
        if (indice == 0) throw new CertificateException("No se encontraron certificados CA.");
        TrustManagerFactory complemento = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        complemento.init(adicionales);
        X509TrustManager primero = gestor(estandar), segundo = gestor(complemento);
        X509TrustManager combinado = new X509TrustManager() {
            public void checkClientTrusted(X509Certificate[] cadena, String tipo) throws CertificateException {
                primero.checkClientTrusted(cadena, tipo);
            }
            public void checkServerTrusted(X509Certificate[] cadena, String tipo) throws CertificateException {
                try { primero.checkServerTrusted(cadena, tipo); }
                catch (CertificateException e) { segundo.checkServerTrusted(cadena, tipo); }
            }
            public X509Certificate[] getAcceptedIssuers() {
                List<X509Certificate> certificados = new ArrayList<>(List.of(primero.getAcceptedIssuers()));
                certificados.addAll(List.of(segundo.getAcceptedIssuers()));
                return certificados.toArray(X509Certificate[]::new);
            }
        };
        SSLContext contexto = SSLContext.getInstance("TLS");
        contexto.init(null, new TrustManager[]{combinado}, null);
        return contexto;
    }
    private static X509TrustManager gestor(TrustManagerFactory fabrica) throws GeneralSecurityException {
        for (TrustManager gestor : fabrica.getTrustManagers()) if (gestor instanceof X509TrustManager x509) return x509;
        throw new GeneralSecurityException("No se pudo cargar el almacén de confianza TLS.");
    }
}
