"use strict";
const $ = (id) => document.getElementById(id);
let csrf = null;
let usuario = null;
let bancario = false;
let envioPendiente = null;
let envioPreparado = null;
let modoCuenta = "local";
let saldoActual = null;
let saldoOculto = false;
let textoSaldo = "Consultando…";
let generacionSesion = 0;
const preferenciasSaldo = new Map();
let cciRevelado = false;
let verificacionPendiente = null;
let relojVerificacion = null;
let venceVerificacion = 0;
let permiteReenvio = 0;
let generacionAcceso = 0;
let authOcupado = false;
let verificacionOcupada = false;
let registroActivo = false;
let canalesAcceso = null;

function claveSaldo() { return "ndr:saldo-oculto:" + (usuario?.id || usuario?.correo || ""); }
function cargarPreferenciaSaldo() {
  const clave = claveSaldo();
  try { saldoOculto = localStorage.getItem(clave) === "1"; }
  catch { saldoOculto = preferenciasSaldo.get(clave) || false; }
}
function pintarSaldo() {
  $("balanceValue").textContent = saldoActual === null ? textoSaldo : (saldoOculto ? "••••••" : saldoActual);
  $("toggleBalance").disabled = saldoActual === null;
  $("toggleBalance").setAttribute("aria-pressed", String(saldoOculto));
  $("toggleBalance").setAttribute("aria-label", saldoOculto ? "Mostrar saldo" : "Ocultar saldo");
  $("balanceToggleText").textContent = saldoOculto ? "Mostrar" : "Ocultar";
  $("balanceEye").toggleAttribute("hidden", saldoOculto);
  $("balanceEyeOff").toggleAttribute("hidden", !saldoOculto);
}
function limpiarSaldo(texto = "Consultando…") {
  saldoActual = null; textoSaldo = texto; pintarSaldo();
}
$("toggleBalance").addEventListener("click", () => {
  if (saldoActual === null || !usuario) return;
  saldoOculto = !saldoOculto;
  preferenciasSaldo.set(claveSaldo(), saldoOculto);
  try { localStorage.setItem(claveSaldo(), saldoOculto ? "1" : "0"); } catch { }
  pintarSaldo();
});
function moneda(valor, codigo = "PEN") {
  return new Intl.NumberFormat("es-PE", {style:"currency", currency:codigo}).format(Number(valor));
}
function fechaVisible(valor) {
  const fecha = new Date(valor);
  return Number.isNaN(fecha.getTime()) ? "—" : fecha.toLocaleString("es-PE", {timeZone:"America/Lima"});
}

async function api(ruta, opciones = {}) {
  let respuesta;
  try {
    respuesta = await fetch(ruta, {credentials:"same-origin", cache:"no-store", ...opciones});
  } catch {
    throw new Error("No se pudo conectar con NDR. Comprueba que iniciar.bat sigue abierto y vuelve a intentarlo.");
  }
  let datos;
  try { datos = await respuesta.json(); }
  catch { throw new Error("No se pudo interpretar la respuesta del servidor."); }
  if (!respuesta.ok || !datos.ok) {
    const error = new Error(datos.mensaje || "No fue posible completar la solicitud.");
    error.status = respuesta.status;
    throw error;
  }
  return datos;
}
function post(ruta, cuerpo, sesion = false) {
  const headers = {"Content-Type":"application/json", "X-NDR-Request":"1"};
  if (sesion) headers["X-NDR-CSRF"] = csrf || "";
  return api(ruta, {method:"POST", headers, body:JSON.stringify(cuerpo)});
}
function estadoMensaje(id, texto, ok = false) {
  const e = $(id);
  e.textContent = texto;
  e.classList.toggle("good", ok);
}
function formatoCci(cci) {
  if (!cci) return "—";
  return String(cci).replace(/\D/g, "").replace(/(.{4})/g, "$1 ").trim();
}
function cciPrivado(cci) {
  const digitos = String(cci || "").replace(/\D/g, "");
  return digitos ? "•••• •••• •••• •••• " + digitos.slice(-4) : "—";
}
function pintarCciPerfil() {
  $("profileCciFull").textContent = usuario ? (cciRevelado ? formatoCci(usuario.cci) : cciPrivado(usuario.cci)) : "—";
  $("toggleCci").setAttribute("aria-label", cciRevelado ? "Ocultar CCI" : "Mostrar CCI");
  $("toggleCci").setAttribute("aria-pressed", String(cciRevelado));
  $("cciToggleText").textContent = cciRevelado ? "Ocultar" : "Mostrar";
}
$("toggleCci").addEventListener("click", () => {
  if (!usuario) return;
  cciRevelado = !cciRevelado;
  pintarCciPerfil();
});
function aplicarDatosUsuario() {
  if (!usuario) return;
  const nombre = usuario.nombre || "bienvenido";
  $("firstName").textContent = nombre.split(/\s+/)[0];
  $("profileName").textContent = nombre;
  $("profileEmail").textContent = usuario.correo || "—";
  $("profilePhone").textContent = usuario.telefono || "—";
  $("profileDni").textContent = usuario.dniEnmascarado || "—";
  cciRevelado = false;
  pintarCciPerfil();
  $("profileCciPreview").textContent = cciPrivado(usuario.cci);
  $("transferOwnCci").textContent = cciPrivado(usuario.cci);
}
function aplicarCanales() {
  const disponibles = canalesAcceso ? ["correo", "sms"].filter(c => canalesAcceso[c]) : ["correo", "sms"];
  for (const id of ["loginChannel", "registerChannel"]) {
    const selector = $(id);
    for (const opcion of selector.options) opcion.disabled = !disponibles.includes(opcion.value);
    if (!disponibles.includes(selector.value) && disponibles.length) selector.value = disponibles[0];
    selector.disabled = !disponibles.length;
  }
  $("loginSubmit").disabled = authOcupado || !disponibles.length;
  $("registerSubmit").disabled = authOcupado || !disponibles.length;
  if (canalesAcceso) {
    $("deliveryStatus").textContent = !disponibles.length ? "Verificación pendiente de configurar. El servicio de códigos todavía no está disponible."
      : disponibles.length === 2 ? "Elige dónde recibir tu código de acceso."
      : disponibles[0] === "correo" ? "Recibe tu código por correo electrónico." : "Recibe tu código por SMS al celular registrado.";
    $("deliveryStatus").classList.toggle("pending", !disponibles.length);
  }
}
async function consultarCanales() {
  try {
    const datos = await api("/api/auth/canales");
    canalesAcceso = {correo:datos.correo === true, sms:datos.sms === true};
    aplicarCanales();
  } catch {
    $("deliveryStatus").textContent = "No se pudo consultar el servicio de códigos. Puedes volver a intentar tu acceso.";
  }
}
function limpiarVerificacion() {
  if (relojVerificacion) clearInterval(relojVerificacion);
  relojVerificacion = null;
  verificacionPendiente = null;
  verificacionOcupada = false;
  $("verificationForm").reset();
  $("verificationForm").hidden = true;
  $("verificationDest").textContent = "—";
  $("verificationCountdown").textContent = "";
  estadoMensaje("verificationMessage", "");
}
function modoRegistro(registro) {
  generacionAcceso++;
  authOcupado = false;
  registroActivo = registro;
  limpiarVerificacion();
  $("loginForm").hidden = registro;
  $("registerForm").hidden = !registro;
  $("authTabs").hidden = false;
  $("authMessage").hidden = false;
  $("deliveryStatus").hidden = false;
  $("showLogin").classList.toggle("active", !registro);
  $("showRegister").classList.toggle("active", registro);
  $("showLogin").setAttribute("aria-pressed", String(!registro));
  $("showRegister").setAttribute("aria-pressed", String(registro));
  $("authTitle").textContent = registro ? "Crear tu cuenta" : "Iniciar sesión";
  $("authSubtitle").textContent = registro ? "Completa tus datos y confirma el código para crear tu cuenta." : "Ingresa tu correo o celular, DNI y contraseña.";
  estadoMensaje("authMessage", "");
  aplicarCanales();
}
$("showLogin").addEventListener("click", () => modoRegistro(false));
$("showRegister").addEventListener("click", () => modoRegistro(true));
for (const id of ["loginDni", "registerDni", "verificationCode"]) {
  $(id).addEventListener("input", () => {
    const limite = id === "verificationCode" ? 6 : 8;
    $(id).value = $(id).value.replace(/\D/g, "").slice(0, limite);
  });
}
function actualizarRelojVerificacion() {
  if (!verificacionPendiente) return;
  const segundos = Math.max(0, Math.ceil((venceVerificacion - Date.now()) / 1000));
  const espera = Math.max(0, Math.ceil((permiteReenvio - Date.now()) / 1000));
  $("verificationCountdown").textContent = segundos ? "El código vence en " + Math.floor(segundos / 60) + ":" + String(segundos % 60).padStart(2, "0") + "." : "El código venció. Vuelve para solicitar uno nuevo.";
  $("verificationSubmit").disabled = verificacionOcupada || !segundos;
  $("verificationCode").disabled = verificacionOcupada || !segundos;
  $("resendCode").disabled = verificacionOcupada || !segundos || espera > 0;
  $("resendCode").textContent = espera > 0 ? "Reenviar en " + espera + " s" : "Reenviar código";
  if (!segundos && relojVerificacion) {
    clearInterval(relojVerificacion);
    relojVerificacion = null;
  }
}
function mostrarVerificacion(datos) {
  const paso = datos?.verificacion;
  if (!paso?.id || !["correo", "sms"].includes(paso.canal) || !paso.destino)
    throw new Error("No se recibió la verificación de acceso. Comprueba que el servidor esté actualizado.");
  limpiarVerificacion();
  verificacionPendiente = {id:paso.id, canal:paso.canal, tipo:paso.tipo};
  const segundos = Number(paso.expiraEnSegundos);
  const espera = Number(paso.reenviarEnSegundos);
  venceVerificacion = Date.now() + (Number.isFinite(segundos) && segundos > 0 ? segundos : 300) * 1000;
  permiteReenvio = Date.now() + (Number.isFinite(espera) && espera >= 0 ? espera : 60) * 1000;
  $("authTitle").textContent = paso.canal === "correo" ? "Revisa tu correo" : "Revisa tu celular";
  $("authSubtitle").textContent = "Confirma tu acceso con el código de seis cifras.";
  $("verificationDest").textContent = paso.destino;
  $("loginForm").hidden = true;
  $("registerForm").hidden = true;
  $("authTabs").hidden = true;
  $("authMessage").hidden = true;
  $("deliveryStatus").hidden = true;
  $("verificationForm").hidden = false;
  $("loginPassword").value = "";
  $("registerPassword").value = "";
  $("registerRepeat").value = "";
  $("loginDni").value = "";
  $("registerDni").value = "";
  actualizarRelojVerificacion();
  relojVerificacion = setInterval(actualizarRelojVerificacion, 1000);
  $("verificationCode").focus();
}
async function entrar(datos) {
  if (!datos?.csrf || !datos?.usuario?.nombre) throw new Error("Respuesta de sesión incompleta. Intenta entrar de nuevo.");
  generacionSesion++;
  generacionAcceso++;
  authOcupado = false;
  limpiarVerificacion();
  $("loginForm").reset(); $("registerForm").reset();
  csrf = datos.csrf;
  usuario = datos.usuario;
  cargarPreferenciaSaldo();
  limpiarSaldo();
  aplicarDatosUsuario();
  $("bankApp").hidden = false;
  $("authView").hidden = true;
  mostrarVista("inicio", true);
  await consultarBanco();
}
function salirDeVista() {
  generacionSesion++;
  csrf = null; usuario = null; bancario = false; envioPendiente = null; envioPreparado = null;
  $("bankApp").hidden = true;
  $("authView").hidden = false;
  $("loginForm").reset(); $("registerForm").reset();
  modoRegistro(false);
  $("sessionMessage").hidden = true;
  saldoOculto = false; modoCuenta = "local";
  cciRevelado = false; pintarCciPerfil();
  limpiarSaldo("—");
  $("balanceNote").textContent = "";
  $("transferForm").reset();
  $("transferResult").hidden = true;
  $("transferSubmit").disabled = true;
  $("confirmDialog").close();
  for (const id of ["firstName", "profileName", "profileEmail", "profilePhone", "profileDni", "profileCciFull", "profileCciPreview", "transferOwnCci", "bankAccount", "bankProvider", "profileBank", "confirmBeneficiary", "confirmCci", "confirmAmount", "resultBeneficiary", "resultCci", "resultAmount", "resultDate", "resultOperation", "resultReference", "resultState", "transferResultText"]) $(id).textContent = "—";
  estadoMensaje("transferMessage", ""); estadoMensaje("movementMessage", "");
  vacio("Todavía no hay movimientos.");
}
async function solicitarCodigo(tipo) {
  if (authOcupado) return;
  const registro = tipo === "registro";
  const dni = $(registro ? "registerDni" : "loginDni").value;
  if (!/^[0-9]{8}$/.test(dni)) return estadoMensaje("authMessage", "Introduce un DNI de ocho dígitos.");
  if (registro && $("registerPassword").value !== $("registerRepeat").value)
    return estadoMensaje("authMessage", "Las contraseñas no coinciden.");
  const canal = $(registro ? "registerChannel" : "loginChannel").value;
  if (canalesAcceso && !canalesAcceso[canal]) return estadoMensaje("authMessage", "El canal de verificación no está disponible.");
  const generacion = ++generacionAcceso;
  authOcupado = true;
  aplicarCanales();
  estadoMensaje("authMessage", registro ? "Preparando tu registro…" : "Verificando tus credenciales…");
  const cuerpo = registro ? {
    nombre:$("registerName").value, correo:$("registerEmail").value,
    telefono:$("registerPhone").value, dni, password:$("registerPassword").value, canal
  } : {identificador:$("loginId").value, dni, password:$("loginPassword").value, canal};
  try {
    const datos = await post("/api/auth/" + tipo, cuerpo);
    if (generacion !== generacionAcceso) return;
    mostrarVerificacion(datos);
  } catch (err) {
    if (generacion === generacionAcceso) estadoMensaje("authMessage", err.message);
  } finally {
    if (generacion === generacionAcceso) {
      authOcupado = false;
      aplicarCanales();
    }
  }
}
$("loginForm").addEventListener("submit", e => { e.preventDefault(); solicitarCodigo("login"); });
$("registerForm").addEventListener("submit", e => { e.preventDefault(); solicitarCodigo("registro"); });
$("verificationForm").addEventListener("submit", async e => {
  e.preventDefault();
  if (!verificacionPendiente || verificacionOcupada || Date.now() >= venceVerificacion) return;
  const codigo = $("verificationCode").value;
  if (!/^[0-9]{6}$/.test(codigo)) return estadoMensaje("verificationMessage", "Introduce las seis cifras del código.");
  const generacion = generacionAcceso;
  verificacionOcupada = true;
  actualizarRelojVerificacion();
  estadoMensaje("verificationMessage", "Confirmando tu código…");
  try {
    const datos = await post("/api/auth/verificar", {verificacion:verificacionPendiente.id, codigo});
    if (generacion !== generacionAcceso) return;
    await entrar(datos);
  } catch (err) {
    if (generacion !== generacionAcceso) return;
    estadoMensaje("verificationMessage", err.message);
    $("verificationCode").value = "";
    if (err.status === 410 || err.status === 429) venceVerificacion = Date.now();
  } finally {
    if (generacion === generacionAcceso) {
      verificacionOcupada = false;
      actualizarRelojVerificacion();
      if (!$("verificationCode").disabled) $("verificationCode").focus();
    }
  }
});
$("resendCode").addEventListener("click", async () => {
  if (!verificacionPendiente || verificacionOcupada || Date.now() < permiteReenvio || Date.now() >= venceVerificacion) return;
  const generacion = generacionAcceso;
  verificacionOcupada = true;
  actualizarRelojVerificacion();
  estadoMensaje("verificationMessage", "Solicitando otro código…");
  try {
    const datos = await post("/api/auth/reenviar", {verificacion:verificacionPendiente.id});
    if (generacion !== generacionAcceso) return;
    mostrarVerificacion(datos);
    estadoMensaje("verificationMessage", "Te enviamos un nuevo código. Utiliza el más reciente.", true);
  } catch (err) {
    if (generacion === generacionAcceso) estadoMensaje("verificationMessage", err.message);
  } finally {
    if (generacion === generacionAcceso) {
      verificacionOcupada = false;
      actualizarRelojVerificacion();
    }
  }
});
$("cancelVerification").addEventListener("click", () => modoRegistro(registroActivo));
async function cerrarSesion() {
  try { await post("/api/auth/logout", {}, true); }
  catch { }
  salirDeVista();
}
$("logoutButton").addEventListener("click", cerrarSesion);
$("profileLogout").addEventListener("click", cerrarSesion);

function animarPantalla(pantalla) {
  pantalla.classList.remove("screen-animate");
  void pantalla.offsetWidth;
  pantalla.classList.add("screen-animate");
}
function mostrarVista(vista, instantanea = false) {
  if (!usuario) return;
  if (vista !== "perfil") { cciRevelado = false; pintarCciPerfil(); }
  document.querySelectorAll(".screen").forEach(e => {
    const activa = e.id === vista;
    e.classList.toggle("active", activa);
    if (activa) animarPantalla(e);
  });
  const movimientoReducido = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  window.scrollTo({top:0, behavior:instantanea || movimientoReducido ? "instant" : "smooth"});
  if (vista === "historial") cargarMovimientos();
}
document.querySelectorAll("[data-view]").forEach(b => b.addEventListener("click", () => mostrarVista(b.dataset.view)));
function deshabilitarBanco(nombre = "Cuenta no disponible", detalle = "Vuelve a actualizar tu cuenta.", mostrarAviso = true) {
  bancario = false;
  $("connectionPill").classList.remove("connected");
  $("connectionText").textContent = nombre;
  $("integrationStatus").textContent = nombre;
  $("transferSubmit").disabled = true;
  $("bankNotice").hidden = !mostrarAviso;
  $("bankNoticeTitle").textContent = nombre;
  $("bankNoticeText").textContent = detalle;
  $("bankProvider").textContent = "—";
  $("bankAccount").textContent = usuario?.cci ? cciPrivado(usuario.cci) : "—";
  limpiarSaldo(mostrarAviso ? "No disponible" : "Consultando…");
  $("balanceNote").textContent = detalle;
  $("profileBank").textContent = nombre;
}
async function consultarBanco() {
  const generacion = generacionSesion;
  deshabilitarBanco("Consultando cuenta…", "Actualizando tu información", false);
  try {
    const d = await api("/api/estado");
    if (generacion !== generacionSesion || !usuario) return;
    modoCuenta = d.modo || "externo";
    if (!d.conectado) return deshabilitarBanco("Cuenta no disponible", "El servicio de cuenta no está conectado. Vuelve a intentarlo más tarde.");
    if (!d.autenticado) {
      deshabilitarBanco("Validación pendiente", "Tu proveedor debe autorizar el acceso a la cuenta.");
      $("bankProvider").textContent = d.proveedor || "—";
      return;
    }
    bancario = true;
    $("bankProvider").textContent = d.proveedor || "NDR";
    $("connectionPill").classList.add("connected");
    $("connectionText").textContent = modoCuenta === "local" ? "Cuenta activa" : "Banco verificado";
    $("integrationStatus").textContent = modoCuenta === "local" ? "Cuenta NDR activa" : "Entidad verificada";
    $("bankNotice").hidden = true;
    $("profileBank").textContent = modoCuenta === "local" ? "Cuenta NDR activa" : "Validada por la entidad";
    await cargarCuenta();
    if (generacion === generacionSesion) $("transferSubmit").disabled = !bancario || Boolean(envioPendiente);
  } catch (err) {
    if (generacion !== generacionSesion) return;
    if (err.status === 401) return salirDeVista();
    deshabilitarBanco("Cuenta no disponible", err.message);
  }
}
async function cargarCuenta() {
  if (!bancario) return;
  const generacion = generacionSesion;
  limpiarSaldo();
  try {
    const {cuenta} = await api("/api/cuenta");
    if (generacion !== generacionSesion || !usuario) return;
    const saldo = Number(cuenta.saldo);
    if (cuenta.saldo == null || String(cuenta.saldo).trim() === "" || !Number.isFinite(saldo)) throw new Error("No se pudo consultar el saldo. Actualiza tu cuenta.");
    const numero = cuenta.numero || usuario.cci || "—";
    $("bankAccount").textContent = /^[0-9]{20}$/.test(String(numero)) ? cciPrivado(numero) : numero;
    saldoActual = moneda(saldo, cuenta.moneda || "PEN");
    pintarSaldo();
    $("balanceNote").textContent = cuenta.actualizadoEn ? "Actualizado: " + fechaVisible(cuenta.actualizadoEn) : "Cuenta actualizada";
  } catch (err) {
    if (generacion !== generacionSesion) return;
    if (err.status === 401) return salirDeVista();
    deshabilitarBanco("Cuenta no disponible", err.message);
  }
}
$("refreshAccount").addEventListener("click", consultarBanco);
function celda(tr, valor) { const td = document.createElement("td"); td.textContent = valor; tr.append(td); }
function vacio(texto) {
  const tr = document.createElement("tr"); const td = document.createElement("td");
  td.colSpan = 4; td.className = "empty"; td.textContent = texto; tr.append(td);
  $("movementRows").replaceChildren(tr);
}
async function cargarMovimientos() {
  if (!bancario) { vacio("Actualiza tu cuenta para consultar sus movimientos."); return; }
  const generacion = generacionSesion;
  vacio("Consultando operaciones…");
  try {
    const {movimientos} = await api("/api/movimientos");
    if (generacion !== generacionSesion || !usuario) return;
    $("movementRows").replaceChildren();
    if (!movimientos.length) return vacio("Todavía no tienes transferencias registradas.");
    for (const mov of movimientos) {
      const tr = document.createElement("tr");
      for (const v of [mov.fecha ? fechaVisible(mov.fecha) : "—", mov.descripcion || "Transferencia", mov.monto ? moneda(mov.monto, mov.moneda || "PEN") : "—", mov.estado || "Por consultar"]) celda(tr, v);
      $("movementRows").append(tr);
    }
    estadoMensaje("movementMessage", "");
  } catch (err) {
    if (generacion !== generacionSesion) return;
    if (err.status === 401) return salirDeVista();
    vacio("No se pudo consultar el historial."); estadoMensaje("movementMessage", err.message);
  }
}
$("refreshMovements").addEventListener("click", cargarMovimientos);
function montoValido(t) {
  if (!/^\d{1,6}(\.\d{1,2})?$/.test(t)) return false;
  const n = Number(t); return Number.isFinite(n) && n > 0 && n <= 50000;
}
$("transferForm").addEventListener("submit", (e) => {
  e.preventDefault(); $("transferResult").hidden = true;
  if (!bancario) return estadoMensaje("transferMessage", "Actualiza tu cuenta antes de transferir.");
  if (envioPendiente) return estadoMensaje("transferMessage", "Hay una operación pendiente de verificar. Revisa el historial antes de volver a enviarla.");
  const datos = {beneficiario:$("beneficiary").value.trim(), cci:$("cci").value.trim(), monto:$("transferAmount").value.trim().replace(",", "."), concepto:$("concept").value.trim()};
  if (!/^[0-9]{20}$/.test(datos.cci)) return estadoMensaje("transferMessage", "El CCI debe tener 20 dígitos.");
  if (datos.beneficiario.length < 3 || datos.beneficiario.length > 100) return estadoMensaje("transferMessage", "Revisa el beneficiario.");
  if (!montoValido(datos.monto)) return estadoMensaje("transferMessage", "Introduce un monto de S/ 0.01 a S/ 50,000.00.");
  if (datos.concepto.length > 140) return estadoMensaje("transferMessage", "El concepto admite hasta 140 caracteres.");
  if (datos.cci === usuario?.cci) return estadoMensaje("transferMessage", "Elige un CCI distinto al de tu cuenta.");
  envioPreparado = {...datos, claveIdempotencia:crypto.randomUUID()};
  $("confirmBeneficiary").textContent = datos.beneficiario;
  $("confirmCci").textContent = formatoCci(datos.cci);
  $("confirmAmount").textContent = "S/ " + Number(datos.monto).toFixed(2);
  $("confirmDialog").showModal();
});
$("cancelTransfer").addEventListener("click", () => { $("confirmDialog").close(); envioPreparado = null; });
$("confirmDialog").addEventListener("close", () => { if (!envioPendiente) envioPreparado = null; });
$("confirmTransfer").addEventListener("click", async () => {
  if (!envioPreparado || !bancario || envioPendiente) return;
  const generacion = generacionSesion;
  envioPendiente = envioPreparado; envioPreparado = null;
  const operacion = envioPendiente;
  $("confirmDialog").close(); $("transferSubmit").disabled = true;
  $("confirmTransfer").disabled = true;
  estadoMensaje("transferMessage", "Procesando tu transferencia…");
  try {
    const {transferencia} = await post("/api/transferencias", operacion, true);
    if (generacion !== generacionSesion || !usuario) return;
    if (!transferencia?.id || !transferencia?.estado) throw new Error("No se pudo confirmar el estado de la operación. Consulta el historial.");
    $("transferResultTitle").textContent = modoCuenta === "local" ? "Transferencia registrada" : "Respuesta de la entidad";
    $("transferResultText").textContent = modoCuenta === "local" ? "Transferencia registrada. Revisa los detalles de la operación." : "La entidad respondió a la solicitud. Revisa el estado informado.";
    $("resultBeneficiary").textContent = operacion.beneficiario;
    $("resultCci").textContent = formatoCci(operacion.cci);
    $("resultAmount").textContent = moneda(operacion.monto);
    $("resultDate").textContent = fechaVisible(transferencia.fecha || new Date().toISOString());
    $("resultOperation").textContent = transferencia.id;
    $("resultReference").textContent = transferencia.referencia || "—";
    $("resultState").textContent = transferencia.estado;
    $("transferResult").hidden = false;
    estadoMensaje("transferMessage", "Operación registrada correctamente.", true);
    envioPendiente = null; $("transferForm").reset();
    await cargarCuenta();
  } catch (err) {
    if (generacion !== generacionSesion) return;
    if (err.status === 401) return salirDeVista();
    estadoMensaje("transferMessage", err.message + (err.status >= 400 && err.status < 500 ? "" : " Verifica el historial antes de volver a enviar la operación."));
    if (err.status >= 400 && err.status < 500) envioPendiente = null;
  } finally {
    if (generacion === generacionSesion) $("transferSubmit").disabled = !bancario || Boolean(envioPendiente);
    $("confirmTransfer").disabled = false;
  }
});

function activarTapAnimations() {
  document.addEventListener("click", (event) => {
    const boton = event.target.closest(".pressable, .tile, .btn, .auth-tab, .logout");
    if (!boton) return;
    boton.classList.remove("tap-pop");
    void boton.offsetWidth;
    boton.classList.add("tap-pop");
  });
}

(async function iniciar() {
  activarTapAnimations();
  consultarCanales();
  const generacion = generacionSesion;
  try {
    const d = await api("/api/auth/sesion");
    if (generacion === generacionSesion) await entrar(d);
  } catch { if (generacion === generacionSesion) salirDeVista(); }
})();

window.addEventListener("unhandledrejection", () => {
  if (!usuario) estadoMensaje("authMessage", "Hubo un error inesperado. La página permanece abierta; actualiza e inténtalo de nuevo.");
});
