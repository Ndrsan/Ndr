"""Herramientas de prueba locales: no envían mensajes ni guardan códigos."""

from contextlib import contextmanager
from http.cookiejar import CookieJar
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import tempfile
import threading
import time
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs
from urllib.request import HTTPCookieProcessor, ProxyHandler, Request, build_opener


ROOT = Path(__file__).resolve().parents[1]
JAR = ROOT / "dist" / "banca-movil.jar"
PASSWORD = " abc1234567 "
PROFILE = {
    "nombre": "Persona de Prueba",
    "correo": "prueba@example.invalid",
    "telefono": "900000001",
    "dni": "10000001",
    "password": PASSWORD,
    "canal": "correo",
}


class DeliveryStub:
    """Sustituye Resend/Twilio solo en las pruebas; códigos únicamente en RAM."""

    def __init__(self):
        self.messages = []
        self.fail_channels = set()
        self.condition = threading.Condition()

    def __enter__(self):
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_POST(self):
                body = self.rfile.read(int(self.headers.get("Content-Length", "0")))
                channel = "correo" if self.path == "/email" else "sms"
                if channel in owner.fail_channels:
                    self.send_response(503)
                    self.end_headers()
                    self.wfile.write(b'{"error":"test delivery failure"}')
                    return
                if channel == "correo":
                    data = json.loads(body)
                    destination = data["to"]
                    if isinstance(destination, list):
                        destination = destination[0]
                    text = data.get("text", "") or data.get("html", "")
                else:
                    data = parse_qs(body.decode("utf-8"))
                    destination, text = data["To"][0], data["Body"][0]
                match = re.search(r"(?<!\d)(\d{6})(?!\d)", text)
                if not match:
                    self.send_response(400)
                    self.end_headers()
                    return
                with owner.condition:
                    owner.messages.append({
                        "canal": channel, "destino": destination, "codigo": match.group(1),
                    })
                    owner.condition.notify_all()
                self.send_response(200 if channel == "correo" else 201)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"id":"test-message","sid":"test-message","status":"queued"}')

        self.http = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.thread = threading.Thread(target=self.http.serve_forever, daemon=True)
        self.thread.start()
        base = f"http://127.0.0.1:{self.http.server_address[1]}"
        self.environment = {
            "NDR_EMAIL_API_KEY": "test-email-credential",
            "NDR_EMAIL_FROM": "NDR <acceso@example.invalid>",
            "NDR_EMAIL_API_URL": base + "/email",
            "NDR_SMS_ACCOUNT_SID": "AC" + "1" * 32,
            "NDR_SMS_AUTH_TOKEN": "test-sms-credential",
            "NDR_SMS_FROM": "+15005550006",
            "NDR_SMS_API_URL": base + "/sms",
        }
        return self

    def __exit__(self, *args):
        self.http.shutdown()
        self.http.server_close()
        self.thread.join(timeout=5)
        self.messages.clear()

    def code_since(self, index, channel=None, destination=None):
        deadline = time.monotonic() + 5
        with self.condition:
            while True:
                for message in self.messages[index:]:
                    if channel is not None and message["canal"] != channel:
                        continue
                    if destination is not None and message["destino"] != destination:
                        continue
                    return message["codigo"]
                left = deadline - time.monotonic()
                if left <= 0:
                    raise AssertionError("El proveedor local de prueba no recibió el mensaje esperado.")
                self.condition.wait(left)


class ApiClient:
    def __init__(self, base):
        self.base = base
        self.cookies = CookieJar()
        self.http = build_opener(ProxyHandler({}), HTTPCookieProcessor(self.cookies))

    def request(self, path, data=None, csrf=None):
        headers = {}
        if data is not None:
            headers.update({"Origin": self.base, "Content-Type": "application/json", "X-NDR-Request": "1"})
        if csrf is not None:
            headers["X-NDR-CSRF"] = csrf
        request = Request(
            self.base + path,
            data=None if data is None else json.dumps(data).encode("utf-8"),
            headers=headers,
        )
        try:
            response = self.http.open(request, timeout=10)
        except HTTPError as error:
            response = error
        with response:
            return response.status, json.load(response)

    def clear(self):
        self.cookies.clear()


@contextmanager
def java_server(data_dir, delivery=None, provider=None):
    if not JAR.is_file():
        raise RuntimeError("Ejecuta compilar.sh o compilar.bat para crear dist/banca-movil.jar.")
    with socket.socket() as available:
        available.bind(("127.0.0.1", 0))
        port = available.getsockname()[1]
    base = f"http://127.0.0.1:{port}"
    environment = os.environ.copy()
    for name in list(environment):
        if name.startswith("NDR_"):
            environment.pop(name)
    environment.update(PORT=str(port), NDR_DATA_DIR=str(data_dir))
    if delivery is not None:
        environment.update(delivery.environment)
    if provider is not None:
        environment["NDR_PROVIDER_CLASS"] = provider
    with tempfile.TemporaryFile(mode="w+b") as log:
        process = subprocess.Popen(
            ["java", "-jar", str(JAR)], cwd=ROOT, env=environment,
            stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
        )
        try:
            deadline = time.monotonic() + 20
            while time.monotonic() < deadline:
                if process.poll() is not None:
                    raise RuntimeError("El servidor Java terminó durante el arranque.")
                try:
                    status, health = ApiClient(base).request("/api/salud")
                    if status == 200 and health.get("servicio") == "NDR":
                        break
                except (OSError, URLError):
                    pass
                time.sleep(0.05)
            else:
                raise RuntimeError("El servidor Java no estuvo disponible en 20 segundos.")
            yield base
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=5)


def challenge(client, path, payload, delivery):
    start = len(delivery.messages)
    status, result = client.request(path, payload)
    if status != 202:
        raise AssertionError(f"Se esperaba un reto de acceso, estado recibido: {status}.")
    verification = result["verificacion"]
    code = delivery.code_since(start, payload.get("canal", "correo"))
    # La API nunca entrega al navegador el código que recibió el servicio de envío.
    if code in json.dumps(result):
        raise AssertionError("El código de acceso se expuso en la respuesta de la API.")
    return verification, code


def verified_registration(client, delivery, profile=PROFILE):
    verification, code = challenge(client, "/api/auth/registro", profile, delivery)
    status, result = client.request("/api/auth/verificar", {"verificacion": verification["id"], "codigo": code})
    if status != 201:
        raise AssertionError(f"No se completó el registro verificado: HTTP {status}.")
    return result


def verified_login(client, delivery, profile=PROFILE, channel="correo", password=None, identifier=None):
    payload = {
        "identificador": identifier or profile["correo"], "dni": profile["dni"],
        "password": profile["password"] if password is None else password, "canal": channel,
    }
    verification, code = challenge(client, "/api/auth/login", payload, delivery)
    status, result = client.request("/api/auth/verificar", {"verificacion": verification["id"], "codigo": code})
    if status != 200:
        raise AssertionError(f"No se completó el ingreso verificado: HTTP {status}.")
    return result
