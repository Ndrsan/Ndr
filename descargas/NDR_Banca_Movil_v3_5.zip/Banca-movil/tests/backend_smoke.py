#!/usr/bin/env python3
"""Pruebas reales de API con correo/SMS sustituidos por transporte local en RAM.

Ejecutar después de compilar: python3 tests/backend_smoke.py
No envía mensajes externos y no modifica perfiles personales.
"""

import base64
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
import uuid

from support import (
    ApiClient, DeliveryStub, JAR, PASSWORD, PROFILE, ROOT, challenge, java_server,
    verified_login, verified_registration,
)


class BackendSmoke(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="ndr-api-test-")
        self.addCleanup(self.temporary.cleanup)
        self.data = Path(self.temporary.name) / "data"
        self.delivery = self.enterContext(DeliveryStub())

    def assert_logged_out(self, client):
        self.assertEqual(client.request("/api/auth/sesion")[0], 401)
        self.assertEqual(client.request("/api/cuenta")[0], 401)

    def verify(self, client, verification, code):
        return client.request("/api/auth/verificar", {
            "verificacion": verification["id"], "codigo": code,
        })

    def test_registration_requires_code_and_opens_session_only_after_verification(self):
        with java_server(self.data, self.delivery) as base:
            client = ApiClient(base)
            verification, code = challenge(client, "/api/auth/registro", PROFILE, self.delivery)
            self.assertEqual(verification["canal"], "correo")
            self.assertEqual(verification["tipo"], "registro")
            self.assertEqual(verification["expiraEnSegundos"], 300)
            self.assertEqual(verification["reenviarEnSegundos"], 60)
            self.assertNotEqual(verification["destino"], PROFILE["correo"])
            self.assert_logged_out(client)
            self.assertFalse((self.data / "usuarios.ndr").exists())
            self.assertTrue(any(c.name == "NDR_VERIFICACION" and c.has_nonstandard_attr("HttpOnly") for c in client.cookies))
            wrong = "000000" if code != "000000" else "000001"
            self.assertEqual(self.verify(client, verification, wrong)[0], 401)
            self.assert_logged_out(client)
            status, session = self.verify(client, verification, code)
            self.assertEqual(status, 201)
            self.assertTrue(session["csrf"])
            self.assertEqual(session["usuario"]["correo"], PROFILE["correo"])
            self.assertEqual(client.request("/api/auth/sesion")[0], 200)
            self.assertTrue((self.data / "usuarios.ndr").read_text().startswith("NDR-USUARIOS-3\n"))
            self.assertEqual(self.verify(client, verification, code)[0], 401)

    def test_dni_format_uniqueness_and_login_match(self):
        with java_server(self.data, self.delivery) as base:
            client = ApiClient(base)
            for dni in ["", "123", "1234567x"]:
                self.assertEqual(client.request("/api/auth/registro", {**PROFILE, "dni": dni})[0], 400)
            verified_registration(client, self.delivery)
            second = {**PROFILE, "correo": "otra@example.invalid", "telefono": "900000002"}
            self.assertEqual(client.request("/api/auth/registro", second)[0], 409)
            client.clear()
            status, _ = client.request("/api/auth/login", {
                "identificador": PROFILE["correo"], "password": PASSWORD,
                "dni": "10000002", "canal": "correo",
            })
            self.assertEqual(status, 401)
            self.assert_logged_out(client)
            self.assertEqual(len(self.delivery.messages), 1)

    def test_sms_registration_and_email_or_phone_login_require_otp(self):
        with java_server(self.data, self.delivery) as base:
            client = ApiClient(base)
            self.assertEqual(client.request("/api/auth/canales")[1], {"ok": True, "correo": True, "sms": True})
            profile = {**PROFILE, "canal": "sms"}
            registered = verified_registration(client, self.delivery, profile)
            self.assertEqual(self.delivery.messages[-1]["canal"], "sms")
            self.assertEqual(self.delivery.messages[-1]["destino"], "+51900000001")
            client.clear()
            payload = {"identificador": "+51 900000001", "dni": PROFILE["dni"], "password": PASSWORD, "canal": "correo"}
            verification, code = challenge(client, "/api/auth/login", payload, self.delivery)
            self.assert_logged_out(client)
            self.assertEqual(verification["tipo"], "login")
            status, session = self.verify(client, verification, code)
            self.assertEqual(status, 200)
            self.assertEqual(session["usuario"]["id"], registered["usuario"]["id"])

    def test_no_provider_does_not_fake_delivery_or_create_profile(self):
        with java_server(self.data) as base:
            client = ApiClient(base)
            self.assertEqual(client.request("/api/auth/canales")[1], {"ok": True, "correo": False, "sms": False})
            for channel in ["correo", "sms"]:
                status, response = client.request("/api/auth/registro", {**PROFILE, "canal": channel})
                self.assertEqual(status, 503)
                self.assertFalse(response["ok"])
                self.assertNotIn("verificacion", response)
            self.assertFalse((self.data / "usuarios.ndr").exists())
            self.assert_logged_out(client)

    def test_delivery_failure_does_not_commit_profile_and_can_be_retried(self):
        self.delivery.fail_channels.add("correo")
        with java_server(self.data, self.delivery) as base:
            client = ApiClient(base)
            status, response = client.request("/api/auth/registro", PROFILE)
            self.assertEqual(status, 503)
            self.assertNotIn("verificacion", response)
            self.assertFalse((self.data / "usuarios.ndr").exists())
            self.assert_logged_out(client)
            self.delivery.fail_channels.clear()
            verified_registration(client, self.delivery)
            self.assertEqual(client.request("/api/cuenta")[1]["cuenta"]["saldo"], "200.00")

    def test_code_is_bound_to_browser_and_expires_after_five_wrong_attempts(self):
        with java_server(self.data, self.delivery) as base:
            owner = ApiClient(base)
            stranger = ApiClient(base)
            verification, code = challenge(owner, "/api/auth/registro", PROFILE, self.delivery)
            self.assertEqual(self.verify(stranger, verification, code)[0], 401)
            wrong = "000000" if code != "000000" else "000001"
            for _ in range(5):
                self.assertEqual(self.verify(owner, verification, wrong)[0], 401)
            self.assertEqual(self.verify(owner, verification, code)[0], 401)
            self.assertFalse((self.data / "usuarios.ndr").exists())
            self.assert_logged_out(owner)

    def test_resend_obeys_cooldown_and_never_returns_code(self):
        with java_server(self.data, self.delivery) as base:
            client = ApiClient(base)
            verification, code = challenge(client, "/api/auth/registro", PROFILE, self.delivery)
            status, response = client.request("/api/auth/reenviar", {"verificacion": verification["id"]})
            self.assertEqual(status, 429)
            self.assertFalse(code in str(response), "La API expuso el código de acceso.")
            self.assertEqual(len(self.delivery.messages), 1)
            self.assertEqual(self.verify(client, verification, code)[0], 201)

    def test_exact_password_and_logout_keep_authentication_checks(self):
        with java_server(self.data, self.delivery) as base:
            client = ApiClient(base)
            registered = verified_registration(client, self.delivery)
            self.assertEqual(client.request("/api/auth/logout", {})[0], 403)
            self.assertEqual(client.request("/api/auth/logout", {}, registered["csrf"])[0], 200)
            self.assert_logged_out(client)
            self.assertEqual(client.request("/api/auth/login", {
                "identificador": PROFILE["correo"], "dni": PROFILE["dni"],
                "password": PASSWORD.strip(), "canal": "correo",
            })[0], 401)
            session = verified_login(client, self.delivery, channel="sms")
            self.assertEqual(client.request("/api/auth/logout", {}, session["csrf"])[0], 200)
            self.assert_logged_out(client)

    def test_legacy_profile_binds_dni_only_after_valid_code_without_losing_balance(self):
        self.data.mkdir(parents=True)
        def enc(value):
            return base64.urlsafe_b64encode(value.encode()).decode().rstrip("=")
        profile_id = str(uuid.uuid4())
        cci = "00200000000000000001"
        salt = b"0123456789abcdef"
        hash_value = hashlib.pbkdf2_hmac("sha256", PASSWORD.encode(), salt, 310_000, 32)
        fields = [profile_id, PROFILE["nombre"], PROFILE["correo"], "+51900000001", cci]
        original = "NDR-USUARIOS-2\n" + "|".join(map(enc, fields)) + "|" + base64.urlsafe_b64encode(salt).decode().rstrip("=") + "|" + base64.urlsafe_b64encode(hash_value).decode().rstrip("=") + "\n"
        users = self.data / "usuarios.ndr"
        users.write_text(original)
        (self.data / "cuentas-locales.ndr").write_text(
            "NDR-CUENTAS-1\nC|" + enc(profile_id) + "|12345|" + enc("2026-11-03T12:00:00Z") + "\n"
        )
        with java_server(self.data, self.delivery) as base:
            client = ApiClient(base)
            verification, code = challenge(client, "/api/auth/login", {
                "identificador": PROFILE["correo"], "dni": PROFILE["dni"],
                "password": PASSWORD, "canal": "correo",
            }, self.delivery)
            self.assertTrue(users.read_text() == original, "El archivo anterior se cambió antes de completar el código.")
            self.assert_logged_out(client)
            self.assertEqual(self.verify(client, verification, code)[0], 200)
            session = client.request("/api/auth/sesion")[1]
            self.assertEqual(session["usuario"]["id"], profile_id)
            self.assertEqual(session["usuario"]["cci"], cci)
            self.assertEqual(client.request("/api/cuenta")[1]["cuenta"]["saldo"], "123.45")
            self.assertTrue(users.read_text().startswith("NDR-USUARIOS-3\n"))
        with java_server(self.data, self.delivery) as base:
            client = ApiClient(base)
            verified_login(client, self.delivery)
            self.assertEqual(client.request("/api/cuenta")[1]["cuenta"]["saldo"], "123.45")
            self.assertEqual(client.request("/api/auth/login", {
                "identificador": PROFILE["correo"], "dni": "10000002",
                "password": PASSWORD, "canal": "correo",
            })[0], 401)

    def transfer(self, **changes):
        payload = {"beneficiario": "Destino de Prueba", "cci": "00999999999999999999",
                   "monto": "25.50", "concepto": "Prueba local", "claveIdempotencia": str(uuid.uuid4())}
        payload.update(changes)
        return payload

    def test_wallet_keeps_balance_and_idempotency_across_verified_login_and_restart(self):
        operation = self.transfer()
        with java_server(self.data, self.delivery) as base:
            client = ApiClient(base)
            session = verified_registration(client, self.delivery)
            self.assertEqual(client.request("/api/cuenta")[1]["cuenta"]["saldo"], "200.00")
            status, receipt = client.request("/api/transferencias", operation, session["csrf"])
            self.assertEqual(status, 202)
            self.assertEqual(client.request("/api/transferencias", operation, session["csrf"]), (202, receipt))
            self.assertEqual(client.request("/api/cuenta")[1]["cuenta"]["saldo"], "174.50")
            for amount in ["0", "-1", "1.001", "50000.01"]:
                self.assertEqual(client.request("/api/transferencias", self.transfer(monto=amount), session["csrf"])[0], 400)
            self.assertEqual(client.request("/api/transferencias", self.transfer(monto="174.51"), session["csrf"])[0], 422)
            self.assertEqual(client.request("/api/transferencias", self.transfer(cci=session["usuario"]["cci"]), session["csrf"])[0], 400)
        with java_server(self.data, self.delivery) as base:
            client = ApiClient(base)
            session = verified_login(client, self.delivery)
            self.assertEqual(client.request("/api/cuenta")[1]["cuenta"]["saldo"], "174.50")
            self.assertEqual(client.request("/api/transferencias", operation, session["csrf"]), (202, receipt))
            self.assertEqual(client.request("/api/transferencias", {**operation, "monto": "1.00"}, session["csrf"])[0], 409)
            self.assertEqual(len(client.request("/api/movimientos")[1]["movimientos"]), 1)

    def test_transfer_credits_only_registered_recipient(self):
        second = {**PROFILE, "nombre": "Otra Persona", "correo": "otra@example.invalid", "telefono": "900000002", "dni": "10000002"}
        with java_server(self.data, self.delivery) as base:
            client = ApiClient(base)
            sender = verified_registration(client, self.delivery)
            receiver = verified_registration(client, self.delivery, second)
            sender = verified_login(client, self.delivery)
            operation = self.transfer(cci=receiver["usuario"]["cci"], monto="12.34")
            self.assertEqual(client.request("/api/transferencias", operation, sender["csrf"])[0], 202)
            self.assertEqual(client.request("/api/cuenta")[1]["cuenta"]["saldo"], "187.66")
            verified_login(client, self.delivery, second)
            self.assertEqual(client.request("/api/cuenta")[1]["cuenta"]["saldo"], "212.34")
            self.assertEqual(client.request("/api/movimientos")[1]["movimientos"][0]["monto"], "+12.34")

    def test_explicit_unavailable_financial_provider_stays_blocked(self):
        with java_server(self.data, self.delivery, provider="ProveedorQueNoExiste") as base:
            client = ApiClient(base)
            session = verified_registration(client, self.delivery)
            self.assertEqual(client.request("/api/estado")[1]["modo"], "desconectado")
            self.assertEqual(client.request("/api/cuenta")[0], 503)
            self.assertEqual(client.request("/api/transferencias", self.transfer(), session["csrf"])[0], 503)

    def test_expiry_and_resend_limits_with_controlled_clock(self):
        compiler = shutil.which("javac")
        if not compiler:
            self.skipTest("La comprobación con reloj requiere JDK 17+, además del entorno Java de ejecución.")
        with tempfile.TemporaryDirectory(prefix="ndr-clock-test-") as classes:
            compile_result = subprocess.run(
                [compiler, "--release", "17", "-encoding", "UTF-8", "-cp", str(JAR),
                 "-d", classes, str(ROOT / "tests/VerificacionAccesoClockTest.java")],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30,
            )
            self.assertEqual(compile_result.returncode, 0, "No se pudo compilar la comprobación del reloj.")
            environment = os.environ.copy()
            for name in list(environment):
                if name.startswith("NDR_"):
                    environment.pop(name)
            environment.update(self.delivery.environment)
            result = subprocess.run(
                ["java", "-cp", str(JAR) + os.pathsep + classes, "VerificacionAccesoClockTest"],
                env=environment, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30,
            )
            self.assertEqual(result.returncode, 0, "Falló la prueba de caducidad, intentos o reenvíos con reloj controlado.")


if __name__ == "__main__":
    unittest.main(verbosity=2)
