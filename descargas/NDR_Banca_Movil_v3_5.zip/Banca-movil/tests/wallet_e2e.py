#!/usr/bin/env python3
"""Chromium y Java reales, con el servicio de correo/SMS sustituido en memoria.

Ejecutar: python3 tests/wallet_e2e.py
Requiere Playwright y Chromium; NDR_BROWSER_PATH selecciona el ejecutable.
NDR_SCREENSHOT_DIR permite capturas opcionales del panel, sin datos personales.
"""

from decimal import Decimal
import os
from pathlib import Path
import re
import shutil
import tempfile
import unittest
from urllib.parse import urljoin

from playwright.sync_api import expect, sync_playwright

from support import DeliveryStub, PASSWORD, PROFILE, java_server


class WalletE2E(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.playwright = sync_playwright().start()
        executable = os.environ.get("NDR_BROWSER_PATH") or shutil.which("chromium")
        options = {"headless": True, "args": ["--no-sandbox"]}
        if executable:
            options["executable_path"] = executable
        cls.browser = cls.playwright.chromium.launch(**options)

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.playwright.stop()

    def test_desktop_verified_account_and_wallet(self):
        self.check_wallet(1280, 720)

    def test_mobile_verified_account_and_wallet(self):
        self.check_wallet(390, 844)

    def api(self, page, path):
        response = page.request.get(urljoin(page.url, path))
        self.assertEqual(response.status, 200)
        return response.json()

    def assert_balance(self, page, amount):
        expect(page.locator("#balanceValue")).to_have_text(re.compile(r"S/\s*" + re.escape(amount)), timeout=10000)
        self.assertEqual(Decimal(self.api(page, "/api/cuenta")["cuenta"]["saldo"]), Decimal(amount))

    def complete_code(self, page, delivery, since, channel, wrong_first=False):
        expect(page.locator("#verificationForm")).to_be_visible(timeout=10000)
        code = delivery.code_since(since, channel)
        expect(page.locator("#resendCode")).to_be_disabled()
        if wrong_first:
            wrong = "000000" if code != "000000" else "000001"
            page.locator("#verificationCode").fill(wrong)
            page.locator("#verificationSubmit").click()
            expect(page.locator("#verificationMessage")).not_to_be_empty(timeout=10000)
            expect(page.locator("#bankApp")).to_be_hidden()
            expect(page.locator("#verificationForm")).to_be_visible()
        page.locator("#verificationCode").fill(code)
        page.locator("#verificationSubmit").click()
        expect(page.locator("#authView")).to_be_hidden(timeout=10000)
        expect(page.locator("#bankApp")).to_be_visible()

    def register(self, page, delivery):
        page.locator("#showRegister").click()
        for name, value in {
            "registerName": PROFILE["nombre"], "registerEmail": PROFILE["correo"],
            "registerPhone": PROFILE["telefono"], "registerDni": PROFILE["dni"],
            "registerPassword": PASSWORD, "registerRepeat": PASSWORD,
        }.items():
            page.locator("#" + name).fill(value)
        page.locator("#registerChannel").select_option("correo")
        since = len(delivery.messages)
        page.locator("#registerSubmit").click()
        self.complete_code(page, delivery, since, "correo", wrong_first=True)

    def login(self, page, delivery, channel="sms"):
        page.locator("#loginId").fill(PROFILE["correo"])
        page.locator("#loginDni").fill(PROFILE["dni"])
        page.locator("#loginPassword").fill(PASSWORD)
        page.locator("#loginChannel").select_option(channel)
        since = len(delivery.messages)
        page.locator("#loginSubmit").click()
        self.complete_code(page, delivery, since, channel)

    def transfer(self, page, amount):
        page.locator("#beneficiary").fill("Destinatario de Prueba")
        page.locator("#cci").fill("99900000000000000001")
        page.locator("#transferAmount").fill(amount)
        page.locator("#concept").fill("Prueba de la aplicación")

    def check_wallet(self, width, height):
        with tempfile.TemporaryDirectory(prefix="ndr-ui-test-") as temporary, DeliveryStub() as delivery:
            data = Path(temporary) / "data"
            context = self.browser.new_context(viewport={"width": width, "height": height}, reduced_motion="reduce")
            errors = []
            try:
                with java_server(data, delivery) as base:
                    page = context.new_page()
                    page.on("pageerror", lambda error: errors.append(str(error)))
                    page.goto(base, wait_until="networkidle")
                    self.register(page, delivery)
                    self.assert_balance(page, "200.00")
                    self.assertEqual(page.evaluate("window.scrollY"), 0)
                    expect(page.locator("#connectionText")).to_have_text("Cuenta activa")
                    own = self.api(page, "/api/auth/sesion")["usuario"]["cci"]
                    own_formatted = " ".join(own[i:i + 4] for i in range(0, 20, 4))
                    self.assertFalse(own in page.locator("body").inner_text(), "El CCI propio se expuso sin pedirlo.")
                    for selector in ["#profileCciPreview", "#bankAccount"]:
                        expect(page.locator(selector)).to_contain_text("••••")
                    page.locator("#inicio [data-view='perfil']").first.click()
                    expect(page.locator("#profileCciFull")).to_contain_text("••••")
                    page.locator("#toggleCci").click()
                    expect(page.locator("#profileCciFull")).to_have_text(own_formatted)
                    page.locator("#toggleCci").click()
                    expect(page.locator("#profileCciFull")).to_contain_text("••••")
                    page.locator("#perfil [data-view='inicio']").click()
                    toggle = page.locator("#toggleBalance")
                    toggle.click()
                    expect(page.locator("#balanceValue")).to_have_text("••••••")
                    page.reload(wait_until="networkidle")
                    expect(page.locator("#balanceValue")).to_have_text("••••••")
                    page.locator("#toggleBalance").click()
                    self.assert_balance(page, "200.00")
                    screenshot_dir = os.environ.get("NDR_SCREENSHOT_DIR")
                    if screenshot_dir:
                        directory = Path(screenshot_dir)
                        directory.mkdir(parents=True, exist_ok=True)
                        label = "desktop" if width > 760 else "mobile"
                        page.screenshot(path=str(directory / f"ndr-dni-{label}.png"), full_page=True)
                    page.locator("#inicio [data-view='transferencias']").first.click()
                    expect(page.locator("#transferOwnCci")).to_contain_text("••••")
                    self.transfer(page, "25.50")
                    page.locator("#transferSubmit").click()
                    expect(page.locator("#confirmDialog")).to_be_visible()
                    expect(page.locator("#confirmAmount")).to_have_text("S/ 25.50")
                    page.locator("#cancelTransfer").click()
                    expect(page.locator("#confirmDialog")).to_be_hidden()
                    self.assertEqual(self.api(page, "/api/cuenta")["cuenta"]["saldo"], "200.00")
                    page.locator("#transferSubmit").click()
                    page.locator("#confirmTransfer").click()
                    expect(page.locator("#transferResult")).to_be_visible(timeout=10000)
                    expect(page.locator("#resultAmount")).to_have_text(re.compile(r"S/\s*25\.50"))
                    self.assertEqual(self.api(page, "/api/cuenta")["cuenta"]["saldo"], "174.50")
                    self.transfer(page, "1000.00")
                    page.locator("#transferSubmit").click()
                    page.locator("#confirmTransfer").click()
                    expect(page.locator("#transferMessage")).to_contain_text(re.compile("saldo", re.I), timeout=10000)
                    expect(page.locator("#transferResult")).to_be_hidden()
                    self.assertEqual(self.api(page, "/api/cuenta")["cuenta"]["saldo"], "174.50")
                    page.locator("#transferencias [data-view='inicio']").click()
                    self.assert_balance(page, "174.50")
                    page.locator("#inicio [data-view='historial']").click()
                    expect(page.locator("#movementRows")).to_contain_text("25.50")
                    self.assertEqual(len(self.api(page, "/api/movimientos")["movimientos"]), 1)
                    page.locator("#logoutButton").click()
                    expect(page.locator("#authView")).to_be_visible()
                    self.login(page, delivery, "sms")
                    self.assert_balance(page, "174.50")
                    page.locator("#logoutButton").click()
                    page.close()
                with java_server(data, delivery) as base:
                    page = context.new_page()
                    page.on("pageerror", lambda error: errors.append(str(error)))
                    page.goto(base, wait_until="networkidle")
                    self.login(page, delivery, "correo")
                    self.assert_balance(page, "174.50")
                    self.assertEqual(len(self.api(page, "/api/movimientos")["movimientos"]), 1)
                    self.assertEqual(errors, [])
            finally:
                context.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
