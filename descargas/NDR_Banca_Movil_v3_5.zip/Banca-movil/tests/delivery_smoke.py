#!/usr/bin/env python3
"""Prueba el transporte correo/SMS contra HTTP local, sin contactar servicios.

Ejecutar: python3 tests/delivery_smoke.py
Requiere JDK 17+. Las credenciales y destinos de esta prueba son ficticios;
los mensajes solo se capturan en memoria y nunca se imprimen.
"""

from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import base64
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import threading
import unittest
from urllib.parse import parse_qs


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src" / "main" / "java"
SID = "AC" + "0" * 32
TOKEN = "token-ficticio-de-prueba"
CODE = "618204"
NAME = 'Ana <script> & "NDR"'
HARNESS = r'''
import java.io.IOException;
public final class DeliveryCheck {
    public static void main(String[] args) {
        EnvioCodigos envio = new EnvioCodigos();
        if (args[0].equals("disponible")) {
            System.out.print(envio.disponible(args[1]));
            return;
        }
        try {
            envio.enviar(args[0], args[1], args[2], args[3]);
            System.out.print("ACEPTADO");
        } catch (IOException error) {
            System.out.print("ERROR: " + error.getMessage());
            System.exit(2);
        }
    }
}
'''


@contextmanager
def capture_server(status=200):
    received = []

    class Capture(BaseHTTPRequestHandler):
        def do_POST(self):
            size = int(self.headers.get("Content-Length", "0"))
            received.append({
                "path": self.path,
                "headers": dict(self.headers),
                "body": self.rfile.read(size).decode("utf-8"),
            })
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            if status == 302:
                self.send_header("Location", "/no-se-debe-visitar")
            self.end_headers()
            # A provider response must never be echoed to the application.
            self.wfile.write(b'{"message":"respuesta-proveedor-privada"}')

        def log_message(self, *_args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Capture)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{server.server_port}", received
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=3)


class DeliverySmoke(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        compiler = shutil.which("javac")
        if not compiler or not shutil.which("java"):
            raise RuntimeError("Estas pruebas necesitan JDK 17+ en PATH.")
        cls.temp = tempfile.TemporaryDirectory(prefix="ndr-delivery-test-")
        cls.addClassCleanup(cls.temp.cleanup)
        cls.compiled = Path(cls.temp.name)
        harness = cls.compiled / "DeliveryCheck.java"
        harness.write_text(HARNESS, encoding="utf-8")
        result = subprocess.run([
            compiler, "--release", "17", "-encoding", "UTF-8", "-d", str(cls.compiled),
            str(SOURCE / "EnvioCodigos.java"), str(SOURCE / "Configuracion.java"), str(harness),
        ], capture_output=True, text=True, timeout=30)
        if result.returncode:
            raise RuntimeError("No se pudo compilar la prueba del transporte: " + result.stderr)

    def environment(self, base=None):
        environment = os.environ.copy()
        for key in list(environment):
            if key.startswith(("NDR_EMAIL_", "NDR_SMS_")):
                del environment[key]
        if base:
            environment.update({
                "NDR_EMAIL_API_KEY": "clave-ficticia-de-prueba",
                "NDR_EMAIL_FROM": "NDR <noreply@example.invalid>",
                "NDR_EMAIL_API_URL": base + "/email",
                "NDR_SMS_ACCOUNT_SID": SID,
                "NDR_SMS_AUTH_TOKEN": TOKEN,
                "NDR_SMS_FROM": "+15005550006",
                "NDR_SMS_API_URL": base + "/sms",
                # Loopback must work even with an unreachable inherited proxy.
                "HTTP_PROXY": "http://127.0.0.1:1",
                "HTTPS_PROXY": "http://127.0.0.1:1",
                "NO_PROXY": "",
            })
        return environment

    def invoke(self, arguments, environment):
        return subprocess.run(
            ["java", "-cp", str(self.compiled), "DeliveryCheck", *arguments],
            cwd=self.compiled, env=environment, capture_output=True, text=True, timeout=25,
        )

    def send(self, channel, environment):
        destination = "persona@example.invalid" if channel == "correo" else "+51900000001"
        result = self.invoke([channel, destination, NAME, CODE], environment)
        self.assertNotIn(CODE, result.stdout + result.stderr)
        self.assertNotIn(TOKEN, result.stdout + result.stderr)
        return result

    def test_email_format_and_json_escaping(self):
        with capture_server() as (base, received):
            environment = self.environment(base)
            self.assertEqual(self.invoke(["disponible", "correo"], environment).stdout, "true")
            result = self.send("correo", environment)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "ACEPTADO")
        self.assertEqual(len(received), 1)
        request = received[0]
        self.assertEqual(request["path"], "/email")
        self.assertEqual(request["headers"]["Authorization"], "Bearer clave-ficticia-de-prueba")
        message = json.loads(request["body"])
        self.assertEqual(message["to"], ["persona@example.invalid"])
        self.assertIn(CODE, message["text"])
        self.assertIn(CODE, message["html"])
        self.assertIn("5 minutos", message["text"])
        self.assertIn("#0d4937", message["html"])
        self.assertNotIn("<script>", message["html"])
        self.assertIn("&lt;script&gt;", message["html"])

    def test_sms_form_and_authentication(self):
        with capture_server(status=201) as (base, received):
            environment = self.environment(base)
            self.assertEqual(self.invoke(["disponible", "sms"], environment).stdout, "true")
            result = self.send("sms", environment)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(len(received), 1)
        request = received[0]
        self.assertEqual(request["path"], "/sms")
        authorization = "Basic " + base64.b64encode(f"{SID}:{TOKEN}".encode()).decode()
        self.assertEqual(request["headers"]["Authorization"], authorization)
        form = parse_qs(request["body"])
        self.assertEqual(form["To"], ["+51900000001"])
        self.assertEqual(form["From"], ["+15005550006"])
        self.assertIn(CODE, form["Body"][0])
        self.assertIn("NDR", form["Body"][0])
        self.assertIn("5 minutos", form["Body"][0])

    def test_missing_configuration_does_not_send(self):
        environment = self.environment()
        for channel in ["correo", "sms", "desconocido"]:
            with self.subTest(channel=channel):
                self.assertEqual(self.invoke(["disponible", channel], environment).stdout, "false")
                self.assertEqual(self.send(channel, environment).returncode, 2)

    def test_insecure_external_overrides_are_rejected(self):
        environment = self.environment("http://example.invalid")
        for channel in ["correo", "sms"]:
            with self.subTest(channel=channel):
                self.assertEqual(self.invoke(["disponible", channel], environment).stdout, "false")
                self.assertEqual(self.send(channel, environment).returncode, 2)

    def test_provider_failure_does_not_expose_response(self):
        with capture_server(status=503) as (base, received):
            result = self.send("correo", self.environment(base))
        self.assertEqual(result.returncode, 2)
        self.assertEqual(len(received), 1)
        self.assertNotIn("respuesta-proveedor-privada", result.stdout + result.stderr)

    def test_redirects_are_not_followed(self):
        with capture_server(status=302) as (base, received):
            result = self.send("sms", self.environment(base))
        self.assertEqual(result.returncode, 2)
        self.assertEqual(len(received), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
