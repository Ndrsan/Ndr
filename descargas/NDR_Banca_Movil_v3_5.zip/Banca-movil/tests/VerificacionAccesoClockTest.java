import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;

/** Pruebas de caducidad reales con reloj controlado, sin reducir plazos de ejecución. */
public final class VerificacionAccesoClockTest {
    private static final class Reloj extends Clock {
        long ahora = 1_700_000_000_000L;
        void avanzar(long segundos) { ahora += segundos * 1000; }
        @Override public ZoneId getZone() { return ZoneOffset.UTC; }
        @Override public Clock withZone(ZoneId zona) { return this; }
        @Override public Instant instant() { return Instant.ofEpochMilli(ahora); }
        @Override public long millis() { return ahora; }
    }
    @FunctionalInterface private interface Accion { void ejecutar() throws Exception; }
    private static Usuarios.Falta fallo(int codigo, Accion accion) throws Exception {
        try { accion.ejecutar(); }
        catch (Usuarios.Falta e) {
            if (e.codigo != codigo) throw new AssertionError("Código de error inesperado: " + e.codigo);
            return e;
        }
        throw new AssertionError("La operación debía ser rechazada.");
    }
    private static void exigir(boolean condicion, String mensaje) {
        if (!condicion) throw new AssertionError(mensaje);
    }
    private static VerificacionAcceso.Inicio nuevo(Usuarios usuarios, VerificacionAcceso verificacion) throws Exception {
        return verificacion.registro(usuarios.prepararRegistro("Prueba Temporal", "reloj@example.invalid",
                "900000003", "53535353", "Clave-temporal-123"), "correo");
    }
    public static void main(String[] args) throws Exception {
        Path datos = Files.createTempDirectory("ndr-reloj-");
        try {
            Usuarios usuarios = new Usuarios(datos);
            Reloj reloj = new Reloj();
            VerificacionAcceso verificacion = new VerificacionAcceso(usuarios, new EnvioCodigos(), reloj);
            exigir(verificacion.disponible("correo"), "Configura el proveedor de correo de pruebas.");
            VerificacionAcceso.Inicio vencido = nuevo(usuarios, verificacion);
            exigir(vencido.verificacion().expiraEnSegundos() == 300, "Vigencia inicial incorrecta.");
            exigir(vencido.verificacion().reenviarEnSegundos() == 60, "Espera inicial incorrecta.");
            reloj.avanzar(301);
            fallo(410, () -> verificacion.confirmar(vencido.verificacion().id(), vencido.cookie(), "000000"));
            fallo(401, () -> verificacion.confirmar(vencido.verificacion().id(), vencido.cookie(), "000000"));

            VerificacionAcceso.Inicio reenvio = nuevo(usuarios, verificacion);
            fallo(429, () -> verificacion.reenviar(reenvio.verificacion().id(), reenvio.cookie()));
            reloj.avanzar(59);
            fallo(429, () -> verificacion.reenviar(reenvio.verificacion().id(), reenvio.cookie()));
            for (int i = 0; i < 3; i++) {
                reloj.avanzar(i == 0 ? 1 : 60);
                VerificacionAcceso.Info info = verificacion.reenviar(reenvio.verificacion().id(), reenvio.cookie());
                exigir(info.expiraEnSegundos() == 300 && info.reenviarEnSegundos() == 60,
                        "Un reenvío debe renovar vigencia y espera.");
            }
            reloj.avanzar(60);
            fallo(429, () -> verificacion.reenviar(reenvio.verificacion().id(), reenvio.cookie()));

            VerificacionAcceso.Inicio limitado = nuevo(usuarios, verificacion);
            for (int i = 0; i < 5; i++)
                fallo(401, () -> verificacion.confirmar(limitado.verificacion().id(), "cookie-incorrecta", "no-valido"));
            for (int i = 0; i < 4; i++) {
                Usuarios.Falta e = fallo(401, () -> verificacion.confirmar(limitado.verificacion().id(), limitado.cookie(), "no-valido"));
                exigir(!e.getMessage().contains("agotaron"), "Otra cookie no debe consumir intentos.");
            }
            Usuarios.Falta agotado = fallo(401, () -> verificacion.confirmar(limitado.verificacion().id(), limitado.cookie(), "no-valido"));
            exigir(agotado.getMessage().contains("agotaron"), "Debe invalidarse al quinto intento fallido.");
            fallo(401, () -> verificacion.reenviar(limitado.verificacion().id(), limitado.cookie()));
            exigir(!Files.exists(datos.resolve("usuarios.ndr")), "No debe persistir perfiles sin completar OTP.");
            System.out.println("OK: caducidad, cooldown, reenvíos limitados, intentos y cookie vinculada.");
        } finally {
            try (var archivos = Files.walk(datos)) {
                for (Path archivo : archivos.sorted(java.util.Comparator.reverseOrder()).toList()) Files.deleteIfExists(archivo);
            }
        }
    }
}
