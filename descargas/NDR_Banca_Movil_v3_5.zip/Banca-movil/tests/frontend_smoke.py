"""Pruebas de interfaz con API controlada dentro de Chromium.

Ejecutar: python3 tests/frontend_smoke.py
Requiere Playwright y Chromium; NDR_BROWSER_PATH permite elegir el navegador.
No usa cuentas ni envíos externos. Los códigos existen solo en estas pruebas.
"""

from decimal import Decimal
import json
import os
from pathlib import Path
import re
import shutil
import unittest
from urllib.parse import urlsplit

from playwright.sync_api import expect, sync_playwright

ROOT = Path(__file__).resolve().parents[1] / "src/main/resources"
ORIGIN = "http://127.0.0.1:18083"
PASSWORD = "Clave-de-prueba-123"
DNI = "12345678"
CODE = "642831"
USER = {"id": "usuario-1", "nombre": "Persona de Prueba", "correo": "prueba@example.test",
        "telefono": "+51900000001", "cci": "00200000000000000001", "dniEnmascarado": "••••5678",
        "contactosVerificados": True}


class FrontendSmoke(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.playwright = sync_playwright().start()
        options = {"headless": True, "args": ["--no-sandbox"]}
        executable = os.environ.get("NDR_BROWSER_PATH") or shutil.which("chromium")
        if executable:
            options["executable_path"] = executable
        cls.browser = cls.playwright.chromium.launch(**options)

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.playwright.stop()

    def setup_page(self, width=1280, height=720, storage_denied=False, configured=True):
        context = self.browser.new_context(viewport={"width": width, "height": height}, reduced_motion="reduce")
        self.addCleanup(context.close)
        if storage_denied:
            context.add_init_script("Object.defineProperty(window, 'localStorage', {get() { throw new DOMException('Denied', 'SecurityError'); }});")
        state = {"authenticated": False, "connected": True, "mode": "local", "user": USER.copy(),
                 "balance": Decimal("200.00"), "posts": [], "movements": [], "errors": [],
                 "held": [], "configured": configured, "pending": None, "code": CODE,
                 "cooldown": 60, "challenge_count": 0, "delivery_failure": False}

        def respond(route, status, body):
            route.fulfill(status=status, content_type="application/json", body=json.dumps(body))

        def verification():
            return {"id": "challenge-" + str(state["challenge_count"]),
                    "canal": state["pending"]["canal"],
                    "destino": "p***@example.test" if state["pending"]["canal"] == "correo" else "+51 ••••••001",
                    "expiraEnSegundos": 300, "reenviarEnSegundos": state["cooldown"],
                    "tipo": state["pending"]["tipo"]}

        def handle(route):
            request = route.request
            path = urlsplit(request.url).path
            if path.startswith("/api/"):
                data = request.post_data_json if request.method == "POST" else None
                if data is not None:
                    state["posts"].append((path, data))
                session = {"ok": True, "usuario": state["user"], "csrf": "csrf-solo-para-pruebas"}
                if path == "/api/auth/canales":
                    respond(route, 200, {"ok": True, "correo": state["configured"], "sms": state["configured"]})
                elif path == "/api/auth/sesion":
                    respond(route, 200 if state["authenticated"] else 401,
                            session if state["authenticated"] else {"ok": False, "mensaje": "Inicia sesión."})
                elif path in ["/api/auth/registro", "/api/auth/login"]:
                    if state["delivery_failure"] or not state["configured"]:
                        respond(route, 503, {"ok": False, "mensaje": "No se pudo enviar el código. Inténtalo después."})
                    else:
                        state["pending"] = {"tipo": "registro" if path.endswith("registro") else "login", "canal": data["canal"]}
                        state["challenge_count"] += 1
                        respond(route, 202, {"ok": True, "verificacion": verification()})
                elif path == "/api/auth/verificar":
                    if not state["pending"] or data["codigo"] != state["code"]:
                        respond(route, 401, {"ok": False, "mensaje": "El código no es correcto."})
                    else:
                        status = 201 if state["pending"]["tipo"] == "registro" else 200
                        state["pending"] = None
                        state["authenticated"] = True
                        respond(route, status, session)
                elif path == "/api/auth/reenviar":
                    state["code"] = "839427"
                    state["cooldown"] = 60
                    respond(route, 202, {"ok": True, "verificacion": verification()})
                elif path == "/api/auth/logout":
                    state["authenticated"] = False
                    respond(route, 200, {"ok": True})
                elif path == "/api/estado":
                    respond(route, 200, {"ok": True, "proveedor": "NDR", "modo": state["mode"],
                                        "conectado": state["connected"], "autenticado": state["connected"]})
                elif path == "/api/cuenta":
                    body = {"ok": True, "cuenta": {"numero": state["user"]["cci"], "moneda": "PEN",
                            "saldo": str(state["balance"]), "actualizadoEn": "2026-11-03T12:00:00Z"}}
                    if state.get("hold_account"):
                        state["held"].append((route, body))
                    else:
                        respond(route, 200, body)
                elif path == "/api/movimientos":
                    respond(route, 200, {"ok": True, "movimientos": state["movements"]})
                elif path == "/api/transferencias":
                    amount = Decimal(data["monto"])
                    if amount > state["balance"]:
                        respond(route, 422, {"ok": False, "mensaje": "Saldo insuficiente para esta transferencia."})
                    else:
                        state["balance"] -= amount
                        state["movements"].insert(0, {"id": "operacion-1", "fecha": "2026-11-03T12:00:00Z",
                            "descripcion": data["beneficiario"] + " · " + data["concepto"],
                            "monto": "-" + str(amount), "moneda": "PEN", "estado": "Registrada"})
                        respond(route, 202, {"ok": True, "transferencia": {"id": "operacion-1",
                            "estado": "Registrada", "referencia": "NDR-PRUEBA-1"}})
                else:
                    respond(route, 404, {"ok": False, "mensaje": "API no disponible en esta prueba."})
                return
            files = {"/": ("index.html", "text/html"), "/style.css": ("style.css", "text/css"),
                     "/app.js": ("app.js", "text/javascript"), "/assets/banca-movil.png": ("assets/banca-movil.png", "image/png")}
            if path in files:
                filename, mime = files[path]
                route.fulfill(status=200, content_type=mime, body=(ROOT / filename).read_bytes())
            else:
                route.fulfill(status=404, body="Not found")

        context.route(ORIGIN + "/**", handle)
        page = context.new_page()
        page.on("pageerror", lambda error: state["errors"].append(str(error)))
        page.goto(ORIGIN, wait_until="networkidle")
        return page, state

    def prepare_login(self, page, channel="correo"):
        page.locator("#loginId").fill(USER["correo"])
        page.locator("#loginDni").fill(DNI)
        page.locator("#loginPassword").fill(PASSWORD)
        page.locator("#loginChannel").select_option(channel)
        page.locator("#loginSubmit").click()
        expect(page.locator("#verificationForm")).to_be_visible()
        expect(page.locator("#bankApp")).to_be_hidden()

    def verify(self, page, state):
        page.locator("#verificationCode").fill(state["code"])
        page.locator("#verificationSubmit").click()
        expect(page.locator("#authView")).to_be_hidden()
        expect(page.locator("#bankApp")).to_be_visible()
        expect(page.locator("#toggleBalance")).to_be_enabled()

    def login(self, page, state, channel="correo"):
        self.prepare_login(page, channel)
        self.verify(page, state)

    def fill_transfer(self, page, amount="25.50"):
        if not page.locator("#inicio").is_visible():
            page.locator('[data-view="inicio"]:visible').first.click()
        page.locator('[data-view="transferencias"]').first.click()
        page.locator("#beneficiary").fill("Destino de Prueba")
        page.locator("#cci").fill("00200000000000000002")
        page.locator("#transferAmount").fill(amount)
        page.locator("#concept").fill("Prueba de operación")

    def test_registration_requires_dni_and_otp_before_opening_account(self):
        for width, height in [(1280, 720), (390, 844)]:
            with self.subTest(viewport=f"{width}x{height}"):
                page, state = self.setup_page(width, height)
                expect(page.locator("#loginForm")).to_be_visible()
                expect(page.locator("#registerForm")).to_be_hidden()
                page.locator("#showRegister").click()
                for id, value in {"registerName": USER["nombre"], "registerEmail": USER["correo"],
                    "registerPhone": "900000001", "registerDni": DNI,
                    "registerPassword": PASSWORD, "registerRepeat": PASSWORD}.items():
                    page.locator("#" + id).fill(value)
                page.locator("#registerChannel").select_option("correo")
                page.locator("#registerSubmit").click()
                expect(page.locator("#verificationForm")).to_be_visible()
                expect(page.locator("#registerForm")).to_be_hidden()
                expect(page.locator("#bankApp")).to_be_hidden()
                expect(page.locator("#verificationDest")).to_contain_text("p***@example.test")
                expect(page.locator("#resendCode")).to_be_disabled()
                self.assertFalse(state["authenticated"])
                registration = [data for path, data in state["posts"] if path.endswith("registro")][0]
                self.assertEqual(registration["dni"], DNI)
                self.assertEqual(registration["canal"], "correo")
                page.locator("#verificationCode").fill("000000")
                page.locator("#verificationSubmit").click()
                expect(page.locator("#verificationMessage")).to_contain_text("no es correcto")
                expect(page.locator("#bankApp")).to_be_hidden()
                self.verify(page, state)
                self.assertEqual(page.evaluate("window.scrollY"), 0)
                expect(page.locator("#balanceValue")).to_have_text("S/ 200.00")
                expect(page.locator("#profileDni")).to_have_text(USER["dniEnmascarado"])
                for id in ["profileCciPreview", "bankAccount", "transferOwnCci", "profileCciFull"]:
                    expect(page.locator("#" + id)).to_have_text(re.compile(r"••••.*0001"))
                page.locator('[data-view="perfil"]').first.click()
                page.locator("#toggleCci").click()
                expect(page.locator("#profileCciFull")).to_have_text("0020 0000 0000 0000 0001")
                expect(page.locator("#profileCciPreview")).to_have_text(re.compile(r"••••.*0001"))
                page.locator("#toggleCci").click()
                expect(page.locator("#profileCciFull")).to_have_text(re.compile(r"••••.*0001"))
                page.locator("#logoutButton").click()
                expect(page.locator("#loginForm")).to_be_visible()
                expect(page.locator("#balanceValue")).to_have_text("—")
                self.assertEqual(state["errors"], [])

    def test_sms_login_cancel_and_resend_follow_server_metadata(self):
        page, state = self.setup_page()
        self.prepare_login(page, "sms")
        expect(page.locator("#verificationDest")).to_contain_text("001")
        expect(page.locator("#resendCode")).to_be_disabled()
        page.locator("#cancelVerification").click()
        expect(page.locator("#verificationForm")).to_be_hidden()
        expect(page.locator("#loginForm")).to_be_visible()
        self.assertFalse(state["authenticated"])
        state["cooldown"] = 0
        self.prepare_login(page, "sms")
        expect(page.locator("#resendCode")).to_be_enabled()
        page.locator("#resendCode").click()
        expect(page.locator("#resendCode")).to_be_disabled()
        self.assertEqual(len([path for path, _ in state["posts"] if path.endswith("reenviar")]), 1)
        self.verify(page, state)
        self.assertEqual(state["errors"], [])

    def test_delivery_unconfigured_or_failed_never_claims_a_code_was_sent(self):
        page, state = self.setup_page(configured=False)
        expect(page.locator("#deliveryStatus")).to_contain_text("Verificación pendiente de configurar")
        expect(page.locator("#loginSubmit")).to_be_disabled()
        page.locator("#showRegister").click()
        expect(page.locator("#registerSubmit")).to_be_disabled()
        expect(page.locator("#verificationForm")).to_be_hidden()
        self.assertFalse(state["posts"])
        page2, state2 = self.setup_page()
        state2["delivery_failure"] = True
        page2.locator("#loginId").fill(USER["correo"])
        page2.locator("#loginDni").fill(DNI)
        page2.locator("#loginPassword").fill(PASSWORD)
        page2.locator("#loginSubmit").click()
        expect(page2.locator("#authMessage")).to_contain_text("No se pudo enviar")
        expect(page2.locator("#verificationForm")).to_be_hidden()
        expect(page2.locator("#bankApp")).to_be_hidden()
        self.assertFalse(state2["authenticated"])
        self.assertEqual(state["errors"] + state2["errors"], [])

    def test_wallet_cancel_transfer_receipt_and_insufficient_balance(self):
        for width, height in [(1280, 720), (390, 844)]:
            with self.subTest(viewport=f"{width}x{height}"):
                page, state = self.setup_page(width, height)
                self.login(page, state)
                page.locator("#toggleBalance").click()
                self.fill_transfer(page)
                page.locator("#transferSubmit").click()
                expect(page.locator("#confirmDialog")).to_be_visible()
                expect(page.locator("#confirmCci")).to_have_text("0020 0000 0000 0000 0002")
                page.locator("#cancelTransfer").click()
                self.assertEqual(state["balance"], Decimal("200.00"))
                self.assertFalse(any(p == "/api/transferencias" for p, _ in state["posts"]))
                page.locator("#transferSubmit").click()
                page.locator("#confirmTransfer").evaluate("e => { e.click(); e.click(); }")
                expect(page.locator("#transferResult")).to_be_visible()
                expect(page.locator("#resultAmount")).to_have_text("S/ 25.50")
                expect(page.locator("#resultState")).to_have_text("Registrada")
                expect(page.locator("#transferSubmit")).to_be_enabled()
                expect(page.locator("#balanceValue")).to_have_text("••••••")
                self.assertEqual(len([p for p, _ in state["posts"] if p == "/api/transferencias"]), 1)
                page.locator('[data-view="inicio"]').first.click()
                page.locator("#toggleBalance").click()
                expect(page.locator("#balanceValue")).to_have_text("S/ 174.50")
                page.locator('[data-view="historial"]').click()
                expect(page.locator("#movementRows")).to_contain_text("Destino de Prueba")
                self.fill_transfer(page, "175.00")
                page.locator("#transferSubmit").click()
                page.locator("#confirmTransfer").click()
                expect(page.locator("#transferMessage")).to_contain_text("Saldo insuficiente")
                expect(page.locator("#transferResult")).to_be_hidden()
                self.assertEqual(state["balance"], Decimal("174.50"))
                self.assertEqual(state["errors"], [])

    def test_balance_preference_scope_reload_and_storage_denied(self):
        for denied in [False, True]:
            with self.subTest(storage_denied=denied):
                page, state = self.setup_page(storage_denied=denied)
                self.login(page, state)
                page.locator("#toggleBalance").focus()
                page.keyboard.press("Enter")
                expect(page.locator("#balanceValue")).to_have_text("••••••")
                expect(page.locator("#balanceEye")).to_be_hidden()
                expect(page.locator("#balanceEyeOff")).to_be_visible()
                page.locator("#refreshAccount").click()
                expect(page.locator("#toggleBalance")).to_be_enabled()
                expect(page.locator("#balanceValue")).to_have_text("••••••")
                if not denied:
                    page.reload(wait_until="networkidle")
                    expect(page.locator("#balanceValue")).to_have_text("••••••")
                page.locator("#logoutButton").click()
                state["user"] = {**USER, "id": "usuario-2", "correo": "otra@example.test"}
                self.login(page, state)
                expect(page.locator("#balanceValue")).to_have_text("S/ 200.00")
                self.assertEqual(state["errors"], [])

    def test_late_account_response_does_not_restore_logged_out_data(self):
        page, state = self.setup_page()
        self.login(page, state)
        state["hold_account"] = True
        page.locator("#refreshAccount").click()
        page.wait_for_function("document.querySelector('#balanceValue').textContent === 'Consultando…'")
        page.locator("#logoutButton").click()
        expect(page.locator("#bankApp")).to_be_hidden()
        self.assertEqual(len(state["held"]), 1)
        route, body = state["held"].pop()
        route.fulfill(status=200, content_type="application/json", body=json.dumps(body))
        page.wait_for_load_state("networkidle")
        expect(page.locator("#balanceValue")).to_have_text("—")
        expect(page.locator("#profileName")).to_have_text("—")
        self.assertEqual(state["errors"], [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
