#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
command -v javac >/dev/null 2>&1 || { echo 'Necesitas JDK 17 o superior para compilar.' >&2; exit 1; }
rm -rf target/classes
mkdir -p target/classes dist
javac --release 17 -encoding UTF-8 -d target/classes src/main/java/*.java
cp -R src/main/resources/. target/classes/
jar --create --file target/banca-movil.jar --main-class Main -C target/classes .
mv -f target/banca-movil.jar dist/banca-movil.jar
echo 'Compilacion terminada: dist/banca-movil.jar'
