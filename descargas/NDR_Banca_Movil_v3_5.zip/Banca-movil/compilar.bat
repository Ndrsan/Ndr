@echo off
setlocal EnableExtensions
cd /d "%~dp0"
where javac >nul 2>nul
if errorlevel 1 (
 echo Necesitas JDK 17 o superior para compilar.
 pause
 exit /b 1
)
where jar >nul 2>nul
if errorlevel 1 (
 echo Falta la herramienta jar. Revisa la instalacion del JDK.
 pause
 exit /b 1
)
if exist "target\classes" rmdir /s /q "target\classes"
mkdir "target\classes"
if not exist "dist" mkdir "dist"
javac --release 17 -encoding UTF-8 -d "target\classes" src\main\java\*.java
if errorlevel 1 goto fallo
xcopy "src\main\resources\*" "target\classes\" /E /I /Y >nul
if errorlevel 1 goto fallo
jar --create --file "target\banca-movil.jar" --main-class Main -C "target\classes" .
if errorlevel 1 goto fallo
move /y "target\banca-movil.jar" "dist\banca-movil.jar" >nul
if errorlevel 1 goto fallo
echo Compilacion terminada: dist\banca-movil.jar
pause
exit /b 0
:fallo
echo No se pudo compilar. Si el servidor esta abierto, cierralo antes de recompilar.
pause
exit /b 1
