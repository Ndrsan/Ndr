"use strict";
const $ = (id) => document.getElementById(id);
let csrf = null;
let usuario = null;
let bancario = false;
let envioPendiente = null;
let envioPreparado = null;

async function api(ruta, opciones = {}) {
  let respuesta;
  try {
    respuesta = await fetch(ruta, {credentials:"same-origin", cache:"no-store", ...opciones});
  } catch {
    throw new Error("No se pudo conectar con NDR. Comprueba que iniciar.bat sigue abierto y vuelve a intentarlo.");
  }
  let datos;
  try { datos = await respuesta.json(); }
  catch { throw new Error("No se pudo interpretar la respuesta del servidor."); }
  if (!respuesta.ok || !datos.ok) {
    const error = new Error(datos.mensaje || "No fue posible completar la solicitud.");
    error.status = respuesta.status;
    throw error;
  }
  return datos;
}
function post(ruta, cuerpo, sesion = false) {
  const headers = {"Content-Type":"application/json", "X-NDR-Request":"1"};
  if (sesion) headers["X-NDR-CSRF"] = csrf || "";
  return api(ruta, {method:"POST", headers, body:JSON.stringify(cuerpo)});
}
function estadoMensaje(id, texto, ok = false) {
  const e = $(id);
  e.textContent = texto;
  e.classList.toggle("good", ok);
}
function formatoCci(cci) {
  if (!cci) return "—";
  return String(cci).replace(/\D/g, "").replace(/(.{4})/g, "$1 ").trim();
}
function aplicarDatosUsuario() {
  if (!usuario) return;
  const nombre = usuario.nombre || "bienvenido";
  $("firstName").textContent = nombre.split(/\s+/)[0];
  $("profileName").textContent = nombre;
  $("profileEmail").textContent = usuario.correo || "—";
  $("profilePhone").textContent = usuario.telefono || "—";
  $("profileCciFull").textContent = formatoCci(usuario.cci);
  $("profileCciPreview").textContent = formatoCci(usuario.cci);
  $("transferOwnCci").textContent = formatoCci(usuario.cci);
}
function modoRegistro(registro) {
  $("loginForm").hidden = registro;
  $("registerForm").hidden = !registro;
  $("showLogin").classList.toggle("active", !registro);
  $("showRegister").classList.toggle("active", registro);
  $("showLogin").setAttribute("aria-pressed", String(!registro));
  $("showRegister").setAttribute("aria-pressed", String(registro));
  $("authTitle").textContent = registro ? "Crear tu cuenta" : "Iniciar sesión";
  $("authSubtitle").textContent = registro ? "Crea tu perfil de acceso con correo, celular y un CCI propio." : "Ingresa con tu correo o número de celular.";
  estadoMensaje("authMessage", "");
}
$("showLogin").addEventListener("click", () => modoRegistro(false));
$("showRegister").addEventListener("click", () => modoRegistro(true));

async function entrar(datos) {
  if (!datos?.csrf || !datos?.usuario?.nombre) throw new Error("Respuesta de sesión incompleta. Intenta entrar de nuevo.");
  csrf = datos.csrf;
  usuario = datos.usuario;
  aplicarDatosUsuario();
  mostrarVista("inicio");
  $("bankApp").hidden = false;
  $("authView").hidden = true;
  await consultarBanco();
}
function salirDeVista() {
  csrf = null; usuario = null; bancario = false; envioPendiente = null; envioPreparado = null;
  $("bankApp").hidden = true;
  $("authView").hidden = false;
  $("loginForm").reset(); $("registerForm").reset();
  modoRegistro(false);
  $("sessionMessage").hidden = true;
}
$("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault(); $("loginSubmit").disabled = true;
  estadoMensaje("authMessage", "Verificando tus credenciales…");
  try {
    const d = await post("/api/auth/login", {identificador:$("loginId").value, password:$("loginPassword").value});
    $("loginPassword").value = "";
    await entrar(d);
    $("sessionMessage").hidden = true;
  } catch (err) { estadoMensaje("authMessage", err.message); }
  finally { $("loginSubmit").disabled = false; }
});
$("registerForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  if ($("registerPassword").value !== $("registerRepeat").value)
    return estadoMensaje("authMessage", "Las contraseñas no coinciden.");
  $("registerSubmit").disabled = true; estadoMensaje("authMessage", "Registrando tu perfil…");
  try {
    const d = await post("/api/auth/registro", {
      nombre:$("registerName").value, correo:$("registerEmail").value,
      telefono:$("registerPhone").value, password:$("registerPassword").value
    });
    const correo = $("registerEmail").value.trim();
    $("registerForm").reset();
    modoRegistro(false);
    $("loginId").value = correo;
    $("loginPassword").value = "";
    estadoMensaje("authMessage", d.mensaje || "Cuenta creada. Ahora inicia sesión.", true);
  } catch (err) { estadoMensaje("authMessage", err.message); }
  finally { $("registerSubmit").disabled = false; }
});
async function cerrarSesion() {
  try { await post("/api/auth/logout", {}, true); }
  catch { }
  salirDeVista();
}
$("logoutButton").addEventListener("click", cerrarSesion);
$("profileLogout").addEventListener("click", cerrarSesion);

function animarPantalla(pantalla) {
  pantalla.classList.remove("screen-animate");
  void pantalla.offsetWidth;
  pantalla.classList.add("screen-animate");
}
function mostrarVista(vista) {
  if (!usuario) return;
  document.querySelectorAll(".screen").forEach(e => {
    const activa = e.id === vista;
    e.classList.toggle("active", activa);
    if (activa) animarPantalla(e);
  });
  window.scrollTo({top:0, behavior:"smooth"});
  if (vista === "historial") cargarMovimientos();
}
document.querySelectorAll("[data-view]").forEach(b => b.addEventListener("click", () => mostrarVista(b.dataset.view)));
function deshabilitarBanco(nombre = "Entidad por vincular") {
  bancario = false;
  $("connectionPill").classList.remove("connected");
  $("connectionText").textContent = nombre;
  $("integrationStatus").textContent = nombre;
  $("transferSubmit").disabled = true;
  $("bankNotice").hidden = false;
  $("bankProvider").textContent = "Pendiente";
  $("bankAccount").textContent = usuario?.cci ? formatoCci(usuario.cci) : "Sin vincular";
  $("balanceValue").textContent = "No disponible";
  $("balanceNote").textContent = "Sin consulta de fondos bancarios";
  $("profileBank").textContent = "Pendiente";
}
async function consultarBanco() {
  deshabilitarBanco("Consultando entidad…");
  try {
    const d = await api("/api/estado");
    $("bankProvider").textContent = d.proveedor || "Sin entidad";
    if (!d.conectado) return deshabilitarBanco("Entidad por vincular");
    if (!d.autenticado) {
      deshabilitarBanco("Validación bancaria pendiente");
      $("bankProvider").textContent = d.proveedor;
      $("profileBank").textContent = "Por verificar con " + d.proveedor;
      return;
    }
    bancario = true;
    $("connectionPill").classList.add("connected");
    $("connectionText").textContent = "Banco verificado";
    $("integrationStatus").textContent = "Entidad verificada";
    $("bankNotice").hidden = true;
    $("profileBank").textContent = "Validada por la entidad";
    $("transferSubmit").disabled = Boolean(envioPendiente);
    await cargarCuenta();
  } catch (err) {
    if (err.status === 401) return salirDeVista();
    deshabilitarBanco("Entidad no disponible");
  }
}
async function cargarCuenta() {
  if (!bancario) return;
  try {
    const {cuenta} = await api("/api/cuenta");
    $("bankAccount").textContent = cuenta.numero || formatoCci(usuario?.cci) || "Sin datos";
    const saldo = Number(cuenta.saldo);
    $("balanceValue").textContent = Number.isFinite(saldo) ? new Intl.NumberFormat("es-PE", {style:"currency", currency:cuenta.moneda || "PEN"}).format(saldo) : "No disponible";
    $("balanceNote").textContent = cuenta.actualizadoEn ? "Verificado: " + cuenta.actualizadoEn : "Dato reportado por entidad";
  } catch (err) {
    $("bankAccount").textContent = formatoCci(usuario?.cci);
    $("balanceValue").textContent = "No disponible";
    $("balanceNote").textContent = err.message;
  }
}
$("refreshAccount").addEventListener("click", consultarBanco);
function celda(tr, valor) { const td = document.createElement("td"); td.textContent = valor; tr.append(td); }
function vacio(texto) {
  const tr = document.createElement("tr"); const td = document.createElement("td");
  td.colSpan = 4; td.className = "empty"; td.textContent = texto; tr.append(td);
  $("movementRows").replaceChildren(tr);
}
async function cargarMovimientos() {
  if (!bancario) { vacio("Sin información bancaria: vincula y verifica tu cuenta con la entidad."); return; }
  vacio("Consultando operaciones…");
  try {
    const {movimientos} = await api("/api/movimientos");
    $("movementRows").replaceChildren();
    if (!movimientos.length) return vacio("Tu entidad no reportó transferencias.");
    for (const mov of movimientos) {
      const tr = document.createElement("tr");
      for (const v of [mov.fecha || "—", mov.descripcion || "Transferencia", (mov.moneda || "PEN") + " " + (mov.monto || "—"), mov.estado || "Por consultar"]) celda(tr, v);
      $("movementRows").append(tr);
    }
    estadoMensaje("movementMessage", "");
  } catch (err) { vacio("No se pudo consultar el historial."); estadoMensaje("movementMessage", err.message); }
}
$("refreshMovements").addEventListener("click", cargarMovimientos);
function montoValido(t) {
  if (!/^\d{1,6}(\.\d{1,2})?$/.test(t)) return false;
  const n = Number(t); return Number.isFinite(n) && n > 0 && n <= 50000;
}
$("transferForm").addEventListener("submit", (e) => {
  e.preventDefault(); $("transferResult").hidden = true;
  if (!bancario) return estadoMensaje("transferMessage", "La entidad bancaria aún no está vinculada y autorizada.");
  if (envioPendiente) return estadoMensaje("transferMessage", "Hay una solicitud pendiente de aclarar con tu banco.");
  const datos = {beneficiario:$("beneficiary").value.trim(), cci:$("cci").value.trim(), monto:$("transferAmount").value.trim().replace(",", "."), concepto:$("concept").value.trim()};
  if (!/^[0-9]{20}$/.test(datos.cci)) return estadoMensaje("transferMessage", "El CCI debe tener 20 dígitos.");
  if (datos.beneficiario.length < 3 || datos.beneficiario.length > 100) return estadoMensaje("transferMessage", "Revisa el beneficiario.");
  if (!montoValido(datos.monto)) return estadoMensaje("transferMessage", "Introduce un monto de S/ 0.01 a S/ 50,000.00.");
  envioPreparado = {...datos, claveIdempotencia:crypto.randomUUID()};
  $("confirmBeneficiary").textContent = datos.beneficiario;
  $("confirmCci").textContent = formatoCci(datos.cci);
  $("confirmAmount").textContent = "S/ " + Number(datos.monto).toFixed(2);
  $("confirmDialog").showModal();
});
$("cancelTransfer").addEventListener("click", () => { $("confirmDialog").close(); envioPreparado = null; });
$("confirmDialog").addEventListener("close", () => { if (!envioPendiente) envioPreparado = null; });
$("confirmTransfer").addEventListener("click", async () => {
  if (!envioPreparado || !bancario || envioPendiente) return;
  envioPendiente = envioPreparado; envioPreparado = null;
  $("confirmDialog").close(); $("transferSubmit").disabled = true;
  estadoMensaje("transferMessage", "Solicitando autorización a tu entidad financiera…");
  try {
    const {transferencia} = await post("/api/transferencias", envioPendiente, true);
    $("transferResult").hidden = false;
    $("transferResultText").textContent = "Identificador: " + transferencia.id + " · Estado informado por el banco: " + transferencia.estado + (transferencia.referencia ? " · Referencia: " + transferencia.referencia : "") + ".";
    estadoMensaje("transferMessage", "La entidad respondió a la solicitud. Revisa su estado.", true);
    envioPendiente = null; $("transferForm").reset();
    await cargarCuenta();
  } catch (err) {
    estadoMensaje("transferMessage", err.message + (err.status >= 400 && err.status < 500 ? "" : " No vuelvas a enviar la operación sin verificar su estado."));
    if (err.status >= 400 && err.status < 500) envioPendiente = null;
  } finally { $("transferSubmit").disabled = !bancario || Boolean(envioPendiente); }
});

function activarTapAnimations() {
  document.addEventListener("click", (event) => {
    const boton = event.target.closest(".pressable, .tile, .btn, .auth-tab, .logout");
    if (!boton) return;
    boton.classList.remove("tap-pop");
    void boton.offsetWidth;
    boton.classList.add("tap-pop");
  });
}

(async function iniciar() {
  activarTapAnimations();
  try { const d = await api("/api/auth/sesion"); await entrar(d); }
  catch { salirDeVista(); }
})();

window.addEventListener("unhandledrejection", () => {
  if (!usuario) estadoMensaje("authMessage", "Hubo un error inesperado. La página permanece abierta; actualiza e inténtalo de nuevo.");
});
