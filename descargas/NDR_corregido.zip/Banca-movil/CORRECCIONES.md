# Correcciones de acceso de NDR 3.3

Esta entrega conserva los datos y el formato de perfiles de la versión 3.3.

- Los elementos con `hidden` ahora permanecen ocultos aunque sus clases usen
  `display: flex` o `display: grid`. Solo se muestra el formulario seleccionado;
  el acceso desaparece al iniciar sesión y vuelve al cerrarla.
- Registro e ingreso conservan la contraseña exacta, incluidos los espacios al
  principio o al final. Los demás campos mantienen su normalización habitual.
- Se incluye `target/banca-movil.jar` recompilado desde estas fuentes para Java 17+.

## Abrir en Windows

1. Cierra el servidor de la entrega anterior, sin borrar sus datos.
2. Extrae este ZIP completo en una carpeta nueva.
3. Ejecuta `iniciar.bat` y deja abierta su ventana.
4. Ejecuta `ABRIR_NDR.bat`.

Si tenías cuentas de una entrega anterior, conserva su directorio de datos y usa
`NDR_DATA_DIR` para seleccionarlo cuando corresponda. No elimines `usuarios.ndr`.
Las cuentas antiguas se guardaron con los espacios externos de la contraseña
recortados: para esas cuentas usa la contraseña sin esos espacios. Las cuentas
nuevas distinguen esos caracteres.

## Comprobaciones

Recompilar: `compilar.bat` (Windows) o `sh compilar.sh` (Linux/macOS), con JDK 17+.

- `python3 tests/backend_smoke.py`: cinco pruebas reales del JAR, con perfiles
  temporales: registro, duplicados, contraseña exacta, sesión, cierre de sesión,
  persistencia y operaciones bancarias deshabilitadas sin proveedor.
- `python3 tests/frontend_smoke.py`: prueba de interfaz con Playwright y Chromium,
  usando una API simulada solo en las pruebas, en escritorio y móvil. Requiere
  el paquete Python `playwright` y Chromium. `NDR_BROWSER_PATH` permite indicar
  el ejecutable del navegador. La aplicación no necesita estas herramientas.

También se verificó el flujo completo en Chromium contra el servidor Java real
en 1280x720 y 390x844: registro, ingreso, sesión tras recargar y cierre de sesión,
sin errores JavaScript. Compilación con destino Java 17; ejecución con Java 21 en
Linux. No se ejecutaron los lanzadores de Windows en este entorno.

No se reprodujo un cierre del proceso del navegador. Si ese es el síntoma que
persiste, hace falta el error concreto del navegador o de la ventana del servidor.
Las transferencias reales siguen dependiendo del proveedor bancario autorizado
ya previsto por el proyecto.
