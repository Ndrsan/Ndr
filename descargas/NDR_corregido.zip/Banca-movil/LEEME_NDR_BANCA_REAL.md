# NDR Banca Móvil · edición transferencias

## Corrección 3.2: cierre de navegador durante el registro

**El motivo exacto de un cierre del proceso Chrome/Edge en tu equipo no puede confirmarse solo con el proyecto.** No hay órdenes `window.close()` ni de terminación del navegador. Esta edición reduce posibles disparadores y evita abrir versiones previas:

- **Puerto exclusivo 18083**. La versión anterior en 8080 ya no se usa por accidente. `iniciar.bat` comprueba la versión concreta antes de aceptar que ya está en marcha.
- **Registro separado del inicio de sesión**. Al crear un perfil, NDR **no abre automáticamente el panel bancario**. Muestra una confirmación y cambia al formulario de inicio de sesión, con el correo rellenado. La API tampoco crea una sesión al registrarse.
- **ABRIR_NDR_NAVEGADOR_ESTABLE.bat** abre Chrome o Edge con perfil aislado sin extensiones y con la GPU desactivada. Si en modo normal Chrome se cierra pero aquí no, el problema puede estar relacionado con el navegador/perfil/extensiones/aceleración gráfica. Es una prueba diagnóstica, no una solución universal.
- **DIAGNOSTICAR_CIERRE.bat** busca únicamente fechas y nombres de los programas en eventos de fallo de Windows (no extrae contraseñas ni perfiles).

### Pasos obligatorios para utilizar esta entrega

1. Cierra las ventanas `iniciar.bat` **de versiones anteriores de NDR**. No es necesario cerrar Chrome completo.
2. Descomprime esta entrega en una **carpeta nueva**, no mezcles el ZIP con la versión antigua. Conserva `%LOCALAPPDATA%\NDR\datos` porque guarda los perfiles registrados anteriormente.
3. Abre `iniciar.bat` y mantenlo abierto; la dirección nueva es **http://127.0.0.1:18083/**.
4. Abre `ABRIR_NDR.bat` para usar el navegador habitual. Si se cierra, reinicia con `ABRIR_NDR_NAVEGADOR_ESTABLE.bat`, no con la versión antigua.
5. Regístrate. Debe aparecer **“Cuenta NDR creada correctamente”** sin abrir el panel bancario. Después inicia sesión.
6. Si el navegador completo se cierra incluso en modo aislado, ejecuta `DIAGNOSTICAR_CIERRE.bat`. Si Java se cerró, copia **solo el error** mostrado por `iniciar.bat` (no compartas correos, contraseñas o datos privados).

> Registrarte solo crea un perfil local. No verifica el correo/celular ni habilita transferencias. No expongas este servidor como una banca real de producción.

## Qué incluye este proyecto

Esta entrega está construida sobre el proyecto NDR compartido, con **Java 17 + HTML + CSS + JavaScript**, sin dependencias externas para ejecutarlo localmente.

- Pantalla inicial de **iniciar sesión** y **crear cuenta NDR**.
- Registro con **nombre, correo electrónico, celular peruano y contraseña**. Se puede ingresar posteriormente con correo **o** celular.
- Perfiles persistentes en `%LOCALAPPDATA%\NDR\datos\usuarios.ndr` en Windows por defecto (o en `data/usuarios.ndr` si ya existe ese archivo en la carpeta del proyecto), contraseñas protegidas con `PBKDF2WithHmacSHA256`, sal aleatoria y control básico de intentos de acceso.
- Sesión HTTP-only en cookie SameSite=Strict, token aleatorio y comprobación CSRF para operaciones modificadoras.
- Página principal, **transferencias CCI**, **historial de transferencias** y **mi perfil**.
- **Sin depósitos, retiros, fondos de demostración, generación de dinero ni movimientos inventados**.
- Integración preparada mediante el contrato Java `ProveedorFinanciero.java`; por defecto `ProveedorNoConectado.java` **impide** toda operación monetaria.

**Límite crítico:** esta entrega funciona como una aplicación NDR con usuarios reales registrados localmente, pero NO es todavía una plataforma bancaria certificada ni permite enviar dinero hasta implementar y auditar la API de una entidad financiera autorizada. Registrar un perfil NDR NO abre ni vincula una cuenta bancaria. Correo y teléfono se almacenan como datos declarados, **no verificados**; no se envían OTP ni mensajes de verificación inexistentes.

## Cómo utilizarla en Windows (versión corregida)

1. Descomprime el ZIP y entra a **`Banca-movil`**. **No ejecutes el ZIP sin extraerlo.**
2. Comprueba que tienes Java 17 o superior (`java -version`). Si vas a editar el código, usa `compilar.bat` con JDK 17+; el JAR actualizado ya está incluido.
3. Haz doble clic en **`iniciar.bat`** y **mantén abierta esa ventana**. No cierra el navegador, y muestra los fallos del servidor si los hubiera.
4. Cuando aparezca `NDR Banca Móvil`, haz doble clic en **`ABRIR_NDR.bat`** o escribe `http://127.0.0.1:18083/` en una pestaña normal de Chrome/Edge. No utilices el modo de aplicación o un acceso directo que cierre Chrome al salir.
5. Selecciona **Crear cuenta**, completa correo, celular y contraseña de 12 caracteres o más. Al registrarte verás una confirmación sin entrar al panel principal. Inicia sesión de forma explícita.
6. La sección de transferencias permanece bloqueada hasta existir una integración bancaria real y autorizada.

**Si Chrome se sigue cerrando por completo:** abre la misma dirección en Microsoft Edge. Si también cierra, guarda una captura o el texto de la ventana `iniciar.bat` y revisa si el proceso Java terminó. El código de NDR no incluye órdenes para cerrar el navegador. Un cierre del proceso de Chrome puede tener otra causa (extensión, instalación, controlador u otro programa); no se puede confirmar esa causa desde el código fuente.

**Datos de usuario:** en Windows los perfiles nuevos se guardan en `%LOCALAPPDATA%\NDR\datos\usuarios.ndr` para evitar fallos de escritura en Descargas u otras carpetas protegidas. **Si la carpeta `data/usuarios.ndr` de una instalación anterior está presente, se sigue utilizando esa carpeta**, para conservar las cuentas existentes. Si migras desde una versión anterior y deseas conservar tus perfiles, copia su carpeta `data` dentro de `Banca-movil` **antes de iniciar** esta nueva versión; evita mantener varias copias activas de la base de perfiles.

**Corrección de registro:** el formulario ya no tiene respaldo GET que pueda colocar contraseñas en la URL si JavaScript falla; los errores de persistencia muestran mensajes de registro y no de transferencia bancaria. Se añadió una comprobación de salud con versión (`/api/salud`) para detectar instancias de esta versión en el puerto 18083; las versiones antiguas en 8080 no interfieren.

Si usas Linux/macOS: `sh compilar.sh` y `sh iniciar.sh`.

**Importante:** mantener abierto el servidor al usar la aplicación. El archivo de cuentas se guarda en el directorio de datos indicado arriba; conserva esa ubicación si deseas mantener esos usuarios. No envíes ese archivo a terceras personas. Si cambias de computadora, necesitarás una migración protegida. Las sesiones activas se invalidan al reiniciar Java.

## Qué se requiere para transferir dinero REAL

1. **Elegir entidad autorizada** (banco o EEDE con facultades para las operaciones pretendidas). Acordar contractualmente la integración de transferencias a CCI y obtener la **documentación técnica oficial de la API de producción**, y las credenciales de producción en un entorno seguro.
2. Implementar el contrato `ProveedorFinanciero` mediante una clase que:
   - confirme el vínculo individual de cada persona de NDR con su **cliente bancario verificado (KYC)** sin confiar solo en correo, teléfono o `usuarioNdr`;
   - consulte saldos e historial **únicamente** desde el banco;
   - autentique, valide al beneficiario, aplique límites/controles AML y solicite una autorización reforzada específica para la operación;
   - emita la transferencia de acuerdo con la API bancaria real, con idempotencia **persistente**, validación de respuesta, verificación de estados y conciliación;
   - maneje webhooks firmados, reintentos seguros, operaciones inciertas, auditoría y errores sin duplicar transferencias.
3. Compilar esa clase y configurarla con la variable `NDR_PROVIDER_CLASS` que contenga su nombre de clase, p. ej. `BancoContratadoAdapter` (nombre *ilustrativo de clase*, no un servicio operativo). Las credenciales deben permanecer en infraestructura segura y **nunca** en el frontend, código fuente, ZIP o capturas.
4. Antes de producción: sustituir el almacén local de perfiles por una solución de identidad y base de datos aprobadas; **verificar correo y celular**, MFA/passkeys, recuperación de cuenta, detección de fraude, sesiones persistentes, límites distribuidos, auditoría de seguridad, copias de respaldo cifradas, pruebas de penetración, gestión de incidentes y privacidad. Revisar obligaciones y permisos aplicables con la entidad y asesoría jurídica.
5. Publicación: Java escucha deliberadamente solo en `127.0.0.1` y no debe exponerse de forma directa. Frente a una puerta de enlace HTTPS que gestione TLS, define `NDR_PUBLIC_ORIGIN=https://tu-dominio-autorizado` para comprobar el origen y activar cookies `Secure`. **Esto no convierte por sí solo el proyecto en seguro para producción.**

**No existe una API bancaria universal**: se requiere la especificación exacta de la entidad con la que tienes convenio. PayPal Checkout o Sandbox, por sí solos, no habilitan transferencias interbancarias CCI.

## API NDR

| Método | Ruta | Función | Requisitos |
|---|---|---|---|
| `GET` | `/api/salud` | Comprobar que el servidor está activo | Ninguno |
| `POST` | `/api/auth/registro` | Crear perfil NDR | Nombre, correo, celular, contraseña |
| `POST` | `/api/auth/login` | Iniciar sesión | Correo/celular + contraseña |
| `GET` | `/api/auth/sesion` | Consultar sesión | Cookie NDR |
| `POST` | `/api/auth/logout` | Cerrar sesión | Cookie + CSRF |
| `GET` | `/api/estado` | Estado de banco para usuario | Sesión |
| `GET` | `/api/cuenta` | Cuenta y saldo reportados por banco | Sesión + KYC bancario |
| `GET` | `/api/movimientos` | Historial de transferencias del banco | Sesión + KYC bancario |
| `POST` | `/api/transferencias` | Enviar solicitud autenticada al banco | Sesión + CSRF + KYC + contrato bancario |

No existe ninguna ruta `/api/depositos` ni `/api/retiros`.

## Seguridad y alcance

- El servidor local se restringe a loopback y no emite CORS abierto. No es un backend público listo para recibir usuarios o transacciones de terceros.
- Las sesiones viven en RAM y el registro de usuarios es un archivo local con **correo y celular legibles** (las contraseñas no lo están). Para producción, implementar base de datos, cifrado, controles de acceso y sistema de identidad auditados.
- No se han implementado envíos SMS/correo, enlaces bancarios reales, 2FA transaccional, ledger, conciliación ni APIs de un proveedor concreto; estas capacidades dependen del banco/servicios aprobados.
- Las respuestas de error 502 no afirman que la transferencia haya fallado definitivamente: cualquier operación incierta debe reconciliarse directamente con el banco antes de reintentar.
- Para comenzar a usar dinero real, conviene realizar una revisión externa del software, del cumplimiento normativo y del convenio que cubre las operaciones exactas ofrecidas.

Recursos de referencia: [SBS – tipos de autorización](https://www.sbs.gob.pe/autorizacion-de-nuevas-empresas/tipos-de-autorizacion) y [OWASP – gestión de sesiones](https://cheatsheetseries.owasp.org/cheatsheets/Session_Management_Cheat_Sheet).
