"""Regresión de visibilidad del acceso, sin Java ni servicios bancarios.

Ejecutar: python3 tests/frontend_smoke.py
Requiere Playwright para Python y Chromium. NDR_BROWSER_PATH permite elegir
el ejecutable; en su ausencia se usa Chromium del sistema o el de Playwright.
Las respuestas API son simuladas y solo existen dentro de cada prueba.
"""

import json
import os
from pathlib import Path
import shutil
import unittest
from urllib.parse import urlsplit

from playwright.sync_api import expect, sync_playwright


ROOT = Path(__file__).resolve().parents[1]
ORIGIN = "http://127.0.0.1:18083"
USER = {
    "nombre": "Persona de Prueba",
    "correo": "prueba@example.test",
    "telefono": "+51900000001",
    "cci": "00200000000000000001",
}
SESSION = {"ok": True, "usuario": USER, "csrf": "token-solo-para-pruebas"}


class FrontendSmoke(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.playwright = sync_playwright().start()
        executable = os.environ.get("NDR_BROWSER_PATH") or shutil.which("chromium")
        options = {"headless": True, "args": ["--no-sandbox"]}
        if executable:
            options["executable_path"] = executable
        cls.browser = cls.playwright.chromium.launch(**options)

    @classmethod
    def tearDownClass(cls):
        cls.browser.close()
        cls.playwright.stop()

    def test_registration_login_logout_visibility(self):
        for width, height in [(1280, 720), (390, 844)]:
            with self.subTest(viewport=f"{width}x{height}"):
                context = self.browser.new_context(
                    viewport={"width": width, "height": height},
                    reduced_motion="reduce",
                )
                try:
                    self.check_access_flow(context)
                finally:
                    context.close()

    def check_access_flow(self, context):
        state = {"authenticated": False, "connected": False, "posts": []}

        def respond(route, status, body):
            route.fulfill(status=status, content_type="application/json", body=json.dumps(body))

        def handle(route):
            request = route.request
            path = urlsplit(request.url).path
            if path.startswith("/api/"):
                if request.method == "POST":
                    state["posts"].append((path, request.post_data_json))
                if path == "/api/auth/sesion":
                    respond(route, 200 if state["authenticated"] else 401,
                            SESSION if state["authenticated"] else {"ok": False, "mensaje": "Inicia sesión."})
                elif path == "/api/auth/registro":
                    respond(route, 201, {"ok": True, "mensaje": "Cuenta NDR creada correctamente."})
                elif path == "/api/auth/login":
                    state["authenticated"] = True
                    respond(route, 200, SESSION)
                elif path == "/api/auth/logout":
                    state["authenticated"] = False
                    respond(route, 200, {"ok": True})
                elif path == "/api/estado":
                    respond(route, 200, {"ok": True, "proveedor": "Proveedor simulado de pruebas",
                                        "conectado": state["connected"], "autenticado": state["connected"]})
                elif path == "/api/cuenta":
                    respond(route, 200, {"ok": True, "cuenta": {"numero": "****0001", "moneda": "PEN", "saldo": "0.00"}})
                else:
                    respond(route, 404, {"ok": False, "mensaje": "API no simulada."})
                return
            files = {
                "/": ("index.html", "text/html"),
                "/style.css": ("style.css", "text/css"),
                "/app.js": ("app.js", "text/javascript"),
                "/assets/banca-movil.png": ("assets/banca-movil.png", "image/png"),
            }
            if path in files:
                filename, mime = files[path]
                route.fulfill(status=200, content_type=mime, body=(ROOT / filename).read_bytes())
            else:
                route.fulfill(status=404, body="Not found")

        context.route(ORIGIN + "/**", handle)
        page = context.new_page()
        errors = []
        page.on("pageerror", lambda error: errors.append(str(error)))
        page.goto(ORIGIN, wait_until="networkidle")

        expect(page.locator("#authView")).to_be_visible()
        expect(page.locator("#bankApp")).to_be_hidden()
        expect(page.locator("#loginForm")).to_be_visible()
        expect(page.locator("#registerForm")).to_be_hidden()

        page.locator("#showRegister").click()
        expect(page.locator("#loginForm")).to_be_hidden()
        expect(page.locator("#registerForm")).to_be_visible()
        page.locator("#showLogin").click()
        expect(page.locator("#loginForm")).to_be_visible()
        expect(page.locator("#registerForm")).to_be_hidden()
        page.locator("#showRegister").click()

        page.locator("#registerName").fill(USER["nombre"])
        page.locator("#registerEmail").fill(USER["correo"])
        page.locator("#registerPhone").fill("900000001")
        page.locator("#registerPassword").fill("Clave-de-prueba-123")
        page.locator("#registerRepeat").fill("Clave-de-prueba-123")
        page.locator("#registerSubmit").click()
        expect(page.locator("#authMessage")).to_have_text("Cuenta NDR creada correctamente.")
        expect(page.locator("#authView")).to_be_visible()
        expect(page.locator("#registerForm")).to_be_hidden()
        expect(page.locator("#loginForm")).to_be_visible()
        expect(page.locator("#loginId")).to_have_value(USER["correo"])

        page.locator("#loginPassword").fill("Clave-de-prueba-123")
        page.locator("#loginSubmit").click()
        expect(page.locator("#authView")).to_be_hidden()
        expect(page.locator("#bankApp")).to_be_visible()
        expect(page.locator("#connectionText")).to_have_text("Entidad por vincular")
        expect(page.locator("#bankNotice")).to_be_visible()
        expect(page.locator("#transferSubmit")).to_be_disabled()

        # Aun los elementos flex del panel deben respetar hidden al cambiar de estado.
        state["connected"] = True
        page.locator("#refreshAccount").click()
        expect(page.locator("#connectionText")).to_have_text("Banco verificado")
        expect(page.locator("#bankNotice")).to_be_hidden()

        page.locator("#logoutButton").click()
        expect(page.locator("#bankApp")).to_be_hidden()
        expect(page.locator("#authView")).to_be_visible()
        expect(page.locator("#loginForm")).to_be_visible()
        expect(page.locator("#registerForm")).to_be_hidden()
        expect(page.locator("#loginId")).to_have_value("")
        self.assertEqual([path for path, _ in state["posts"]], [
            "/api/auth/registro", "/api/auth/login", "/api/auth/logout",
        ])
        self.assertFalse(state["authenticated"])
        self.assertEqual(errors, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
