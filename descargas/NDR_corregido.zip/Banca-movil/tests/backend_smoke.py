#!/usr/bin/env python3
"""Integration checks against the rebuilt JAR using disposable local profiles.

Run after compilar.sh / compilar.bat:
    python3 tests/backend_smoke.py
Requires Python 3 and Java 17+. Does not contact a bank or external service.
"""

from contextlib import contextmanager
from http.cookiejar import CookieJar
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import tempfile
import time
import unittest
from urllib.error import HTTPError, URLError
from urllib.request import HTTPCookieProcessor, ProxyHandler, Request, build_opener


PROJECT = Path(__file__).resolve().parents[1]
JAR = PROJECT / "target" / "banca-movil.jar"
# Exactly twelve characters, including both significant boundary spaces.
PASSWORD = " abc1234567 "
PROFILE = {
    "nombre": "Prueba Local",
    "correo": "prueba@example.invalid",
    "telefono": "900000001",
    "password": PASSWORD,
}


class BackendSmoke(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not JAR.is_file():
            raise RuntimeError("Build target/banca-movil.jar before running these checks.")
        if not shutil.which("java"):
            raise RuntimeError("Java 17+ must be available in PATH.")

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="ndr-backend-test-")
        self.addCleanup(self.temp.cleanup)
        self.data_dir = Path(self.temp.name) / "data"
        self.cookies = CookieJar()
        # Only these local requests bypass the inherited external HTTP proxy.
        self.http = build_opener(ProxyHandler({}), HTTPCookieProcessor(self.cookies))
        self.base = None

    @contextmanager
    def server(self):
        with socket.socket() as available:
            available.bind(("127.0.0.1", 0))
            port = available.getsockname()[1]
        environment = os.environ.copy()
        environment["PORT"] = str(port)
        environment["NDR_DATA_DIR"] = str(self.data_dir)
        # Exercise the shipped local mode, regardless of caller integration settings.
        environment.pop("NDR_PROVIDER_CLASS", None)
        environment.pop("NDR_PUBLIC_ORIGIN", None)
        self.base = f"http://127.0.0.1:{port}"
        with tempfile.TemporaryFile(mode="w+b") as log:
            process = subprocess.Popen(
                ["java", "-jar", str(JAR)],
                cwd=PROJECT,
                env=environment,
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
            )
            try:
                deadline = time.monotonic() + 20
                while time.monotonic() < deadline:
                    if process.poll() is not None:
                        self.fail(f"Local server exited during startup ({process.returncode}).")
                    try:
                        status, response = self.request("/api/salud")
                        if status == 200 and response.get("servicio") == "NDR":
                            break
                    except (OSError, URLError):
                        pass
                    time.sleep(0.05)
                else:
                    self.fail("Local server did not become ready within 20 seconds.")
                yield
            finally:
                if process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait(timeout=5)

    def request(self, path, data=None, csrf=None):
        headers = {}
        if data is not None:
            headers.update({
                "Origin": self.base,
                "Content-Type": "application/json",
                "X-NDR-Request": "1",
            })
        if csrf is not None:
            headers["X-NDR-CSRF"] = csrf
        payload = None if data is None else json.dumps(data).encode("utf-8")
        request = Request(self.base + path, data=payload, headers=headers)
        try:
            response = self.http.open(request, timeout=5)
        except HTTPError as error:
            response = error
        with response:
            return response.status, json.load(response)

    def register(self):
        status, response = self.request("/api/auth/registro", PROFILE)
        self.assertEqual(status, 201)
        self.assertTrue(response["ok"])
        self.assertNotIn("csrf", response)

    def login(self, password=PASSWORD, identifier=PROFILE["correo"]):
        return self.request("/api/auth/login", {
            "identificador": identifier,
            "password": password,
        })

    def test_registration_stays_logged_out_and_rejects_duplicates(self):
        with self.server():
            self.register()
            self.assertEqual(self.request("/api/auth/sesion")[0], 401)
            self.assertEqual(self.request("/api/cuenta")[0], 401)
            self.assertFalse(any(c.name == "NDR_SESION" for c in self.cookies))
            self.assertEqual(self.request("/api/auth/registro", PROFILE)[0], 409)

    def test_login_preserves_exact_password_including_spaces(self):
        self.assertEqual(len(PASSWORD), 12)
        with self.server():
            self.register()
            self.assertEqual(self.login(password=PASSWORD.strip())[0], 401)
            self.assertEqual(self.login(password="wrong-password")[0], 401)
            status, session = self.login()
            self.assertEqual(status, 200)
            self.assertTrue(session["ok"])
            self.assertEqual(session["usuario"]["correo"], PROFILE["correo"])
            self.assertEqual(self.request("/api/auth/sesion")[0], 200)
            # The supported phone login uses the same literal credential.
            self.assertEqual(self.login(identifier="+51 900000001")[0], 200)

    def test_logout_invalidates_session(self):
        with self.server():
            self.register()
            status, session = self.login()
            self.assertEqual(status, 200)
            self.assertEqual(self.request("/api/auth/logout", {})[0], 403)
            self.assertEqual(self.request("/api/auth/sesion")[0], 200)
            self.assertEqual(self.request("/api/auth/logout", {}, session["csrf"])[0], 200)
            self.assertEqual(self.request("/api/auth/sesion")[0], 401)

    def test_profiles_persist_and_sessions_expire_on_restart(self):
        with self.server():
            self.register()
            status, first_session = self.login()
            self.assertEqual(status, 200)
            user_id = first_session["usuario"]["id"]
        self.assertTrue((self.data_dir / "usuarios.ndr").is_file())
        with self.server():
            self.assertEqual(self.request("/api/auth/sesion")[0], 401)
            status, session = self.login()
            self.assertEqual(status, 200)
            self.assertEqual(session["usuario"]["id"], user_id)
            self.assertEqual(self.request("/api/auth/registro", PROFILE)[0], 409)

    def test_unconnected_bank_remains_unavailable(self):
        with self.server():
            self.register()
            status, session = self.login()
            self.assertEqual(status, 200)
            status, bank = self.request("/api/estado")
            self.assertEqual(status, 200)
            self.assertFalse(bank["conectado"])
            self.assertFalse(bank["autenticado"])
            self.assertEqual(self.request("/api/cuenta")[0], 503)
            self.assertEqual(self.request("/api/movimientos")[0], 503)
            self.assertEqual(self.request("/api/transferencias", {}, session["csrf"])[0], 503)


if __name__ == "__main__":
    unittest.main(verbosity=2)
