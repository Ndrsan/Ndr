import java.math.BigDecimal;
import java.util.List;

/**
 * Contrato para integrar una entidad bancaria/EEDE REAL autorizada.
 * Ninguna transferencia puede efectuarse sin una implementación certificada.
 * La entidad debe resolver un vínculo propio, verificado, entre NDR ID y cliente bancario.
 */
public interface ProveedorFinanciero {
    record Identidad(String usuarioNdr, String correoNoVerificado, String telefonoNoVerificado) {}
    record Cuenta(String titular, String numeroEnmascarado, String moneda,
                  BigDecimal saldoDisponible, String actualizadoEn) {}
    record Transferencia(String identificador, String estado, String referenciaBancaria) {}
    record Movimiento(String identificador, String fecha, String monto, String moneda,
                      String estado, String descripcion) {}

    String nombre();
    boolean estaConfigurado();
    /** Exigir KYC, titularidad y autorización bancaria/segundo factor, jamás confiar solo en el registro NDR. */
    boolean clienteVerificado(Identidad cliente) throws Exception;
    Cuenta consultarCuenta(Identidad cliente) throws Exception;
    List<Movimiento> consultarTransferencias(Identidad cliente) throws Exception;
    /** Implementar idempotencia DURADERA en servidor y verificación de beneficiario + SCA con entidad. */
    Transferencia solicitarTransferencia(Identidad cliente, String cci, String beneficiario,
                                        BigDecimal montoPEN, String concepto, String claveIdempotencia) throws Exception;
}
